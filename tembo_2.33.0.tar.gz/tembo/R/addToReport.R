#' Add an object to the report
#'
#' Process Tembo recipes embedded in a DITA document and replace them with the generated content
#'
#' See also \url{https://confluencewikiprod.intra.infineon.com/display/TEM}
#'
#' \emph{Copyright (c) 2016 Infineon Technologies} 
#' @param theObject Object to be added to the report
#' @examples
#' tembo::addToReport(plot)
#' @family dita
#' @author Kunze Matthias (IFAG ATV PTP MSF DM), \email{matthias.kunze2@@infineon.com}
#' @export
addToReport <- function(theObject, env = parent.frame()) {
  
  filename=paste0(uuid::UUIDgenerate(), ".png")
  #is this function still in use???
  currentTemboPlot$save(file.path(env$outputFolder, filename))
  #ggplot2::ggsave(file.path(env$outputFolder, filename))
  
  # Add generated content
  imageNode<-XML::newXMLNode("image", parent = XML::xmlParent(env$recipeNode), attrs = c(href=filename));
}
