#' Apply Tembo R Template
#'
#' Parametrizes a Tembo R Template and returns the result
#'
#' \emph{Copyright (c) 2017 Infineon Technologies} 
#' @param templateName Name of the Template to be used
#' @param params Named list with parameters of the template
#' @param mode Mode, in which the template shall be applied, possible values are: DisplayName, UIMeta, RCode
#' @param templateLocation Storage location, from where the template shall get loaded
#' @examples
#' tembo::applyRTemplate('xyPlot', params = list(x="theXData", y="theYData"))
#' tembo::applyRTemplate('waveplot', params = list(title="My Title", table=list(c("V_VCC","",""), c("V_TXD","",""))))
#' @author Kunze Matthias (IFAG ATV PTP MSF DM), \email{matthias.kunze2@@infineon.com}
#' @export
applyRTemplate <- function(templateName, params = list(), mode="RCode", templateLocation="//MUCSDV034.infineon.com/Tembo/rcodes", 
                           paramNodes=list(), cacheMode="disabled") {
  
  # Parametrize input xml
  if (length(paramNodes)) {
    # paramNodes is given
    xml<-'<values>'
    for (paramNode in paramNodes) {
      xml<-paste0(xml, XML::toString.XMLNode(paramNode))
    }
    xml<-paste0(xml, '</values>')
  } else {
    # old style
    xml<-'<values>'
    for (paramName in names(params)) {
      if (is.list(params[[paramName]])) {
        tab<-params[[paramName]]
        for (i in 1:length(tab)) {
          xml<-sprintf('%s<param><name>%s</name><row>', xml, paramName)
          for (j in 1:length(tab[[i]])) {
            xml<-sprintf('%s<column>%s</column>', xml, tab[[i]][[j]])
          }
          xml<-sprintf('%s</row></param>', xml)
        }
      }
      else {
        xml<-sprintf('%s<param><name>%s</name><value>%s</value></param>', xml, paramName, params[[paramName]])
      }
    }
    xml<-paste0(xml, '</values>')
  }
  doc <- xml2::read_xml(xml)
  
  # Load xslt and set mode
  style <- xml2::read_xml(paste0(templateLocation, '/', templateName, '.xsl'))
  xml2::xml_set_text(xml2::xml_find_first(style, 'xsl:param[@name="mode"]'), mode)
  
  # Set chache mode
  xml2::xml_set_text(xml2::xml_find_first(style, 'xsl:param[@name="cacheMode"]'), cacheMode)
  
  # Do transformation
  result <- xslt::xml_xslt(doc, style)
  
  return(result)  
}