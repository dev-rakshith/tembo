############################################################################################
#' Define a colour palette based on a data frame 
#' 
#' colourValueDf is a data.frame with columns for colour and value.
#' The goal of this function is to define colour values for specific values, and allow 
#' interpolating between those defined colours in a deterministic manner.
#' 
#' 
#' \emph{Copyright (c) 2019 Infineon Technologies}
#' @author Helena Schmidt, \email{schmidt.external9@infineon.com}
#' @examples
#' colourData <- data.frame(colour=c('cornflowerblue', 'greenyellow', 'firebrick'),
#'                          value=c(-43,25,150),
#'                          stringsAsFactors=FALSE)
#' temboColourFunc <- defineDiscreteColourPalette(colourData)
#' myColours <- temboColourFunc(c(-20,25,120,150))
#' scales::show_col(myColours)
#' @export
defineDiscreteColourPalette <- function(colourValueDf){
  "colourValueDf is a data.frame with columns for colour and value like data.frame(colour=c('cornflowerblue', 'greenyellow', 'firebrick'),value=c(-43,25,150),stringsAsFactors=FALSE)"
  if(!all(c("value","colour") %in% names(colourValueDf)) | !is.data.frame(colourValueDf) ){
    stop("colourValueDf must have a value column and a colour column and it must be a data.frame")
  }
  if(!is.character(colourValueDf$colour)){
    colourValueDf$colour <- as.character(colourValuedDf$colour)
  }
  if(!all(colourValueDf$colour %in% colours())){
    notColourNames <- colourValueDf$colour[!colourValueDf$colour %in% colours()]
    isColourCode <- grepl("^#[0-9a-fA-F]{6}($|[0-9a-zA-Z]{2}$)",notColourNames) #match #RGB or #RGBA
    if(!all(isColourCode)){
      stop(paste0(paste0(notColourNames[!isColourCode],collapse=",")," is/are invalid colour names"))
    }
  }
  function(values){
    tmpCols <- base::merge(data.frame(value=values, orig_row=1:length(values),stringsAsFactors = FALSE),colourValueDf, by="value", all = TRUE,sort=TRUE)
    if(!any(is.na(tmpCols$colour))){
      #subset(tmpCols, value %in% values)
      tmpCols <- subset(tmpCols, value %in% values)
    }else{
      if(any(is.na(tmpCols$colour))){
        if(is.numeric(colourValueDf$value) & (is.numeric(values) | !any(is.na(as.numeric(as.character(values)))))){
          if(!is.numeric(values)){
            values <- as.numeric(as.character(values))
            tmpCols$value <- as.numeric(as.character(tmpCols$value))
          }
          #create groups to interpolate between them:
        	if(is.na(tmpCols$colour[1])){
        		tmpCols$colour[1] <- "gray1"
        	}
        	if(is.na(tmpCols$colour[nrow(tmpCols)])){
        		tmpCols$colour[nrow(tmpCols)] <- "gray70"
        	}
        	nas <- which(is.na(tmpCols$colour))
          if(length(nas)==1){
            tmpCols$colour[nas] <- interpolateColour(tmpCols[(nas-1):(nas+1),])
          } else if(length(nas)>1) {
            #try to find groups
            dnas <- c(1,diff(nas))-1
            dnas[dnas > 0] <- 1
            cmnas <- cumsum(dnas)
            #loop over groups
            for(i in 0:max(cmnas)){
              thisGroup <- nas[which(cmnas == i)]
              tmpCols$colour[thisGroup] <- interpolateColour(tmpCols[(min(thisGroup)-1):(max(thisGroup)+1),])
            }
          }
        } else {
          #in case the values are not numeric, don't interpolate NAs. just invent colours:
        	nas <- which(is.na(tmpCols$colour))
          tmpCols$colour[nas] <- temboDiscretePalette(nas)
        }
      }
      tmpCols <- subset(tmpCols, value %in% values)
    }
    #sort back to original sorting:
    tmpCols <- tmpCols[order(tmpCols$orig_row),]
    return(tmpCols$colour)
  }
}

############################################################################################
#' Tembo default discrete colour palette
#' 
#' The function returns a discrete colour palette as result with the same length as values.
#' In eight or less colors are requested, a colourblind friendly palette is used:
#' http://www.cookbook-r.com/Graphs/Colors_(ggplot2)/#a-colorblind-friendly-palette
#' 
#' \emph{Copyright (c) 2019 Infineon Technologies}
#' @author Helena Schmidt, \email{schmidt.external9@infineon.com}
#' @examples
#' scales::show_col(temboDiscretePalette(rep(1,8)))
#' 
#' @export
temboDiscretePalette <- function(values, colourOffset=0){
  if( length(values) == 0){
    return(c())
  }
  if( length(values) > 8) {
    colourPalette <- scales::hue_pal()(length(values)+colourOffset)[(1+colourOffset):(length(values)+colourOffset)]
  } else {
    cbPalette <- c("#999999", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")
    colourPalette <- cbPalette[(1+colourOffset):(length(values)+colourOffset)]
  }
  return(colourPalette)
}



interpolateColour <- function(colDf){
  valueList <- seq(from=min(colDf$value),to=max(colDf$value), length.out=10)
  cols <- colorRampPalette(c(colDf$colour[1], colDf$colour[nrow(colDf)]))(10)
  #print(cols[sapply(colDf$value[2:(nrow(colDf)-1)], function(x){which(valueList >= x)[1]})])
  cols[sapply(colDf$value[2:(nrow(colDf)-1)], function(x){which(valueList >= x)[1]})]
}




############################################################################################
#' Define a colour palette based on a data frame 
#' 
#' colors is a vector containing color names or color codes.
#' It defines the order of the colors that should be used for plotting.
#' 
#' 
#' \emph{Copyright (c) 2019 Infineon Technologies}
#' @author Helena Schmidt, \email{schmidt.external9@infineon.com}
#' @examples
#' temboColourFunc <- defineDiscreteColourPaletteByOrder(c('cornflowerblue', 'greenyellow', 'firebrick'))
#' myColours <- temboColourFunc(c(-20,25,120,150))
#' scales::show_col(myColours)
#' @export
defineDiscreteColourPaletteByOrder <- function(colors){
  if(!is.vector(colors) ){
    stop("colours must be an ordered vector of colour names")
  }
  if(!is.character(colors)){
    colors <- as.character(colors)
  }
	validateColourNames(colors)
  function(values){
    if(length(values)==0){
      return(c())
    }
    if(length(values)<=length(colors)){
      tmpColours <- colors[1:length(values)]
    } else {
      tmpColours <- c(colors, temboDiscretePalette(values[(length(colors)+1):length(values)]))
    }
    return(tmpColours)
  }
}

validateColourNames <- function(colors){
	if(!all(colors %in% colours())){
		notColourNames <- colors[!colors %in% colours()]
		isColourCode <- grepl("^#[0-9a-fA-F]{6}($|[0-9a-zA-Z]{2}$)",notColourNames) #match #RGB or #RGBA
		if(!all(isColourCode)){
			stop(paste0(paste0(notColourNames[!isColourCode],collapse=",")," is/are invalid colour names"))
		}
	}
}

makeColours <- function(tmpColours, colourOffset=0){
	colors <- as.numeric(as.factor(tmpColours[,2]))
	if(length(colors)==0){
	  return(NULL)
	}
	colors <- temboDiscretePalette(1:max(colors), colourOffset=colourOffset)[colors]
	if(existsFunction("currentTemboDiscretePalette")){
		if(!all(is.na(as.numeric(as.character(tmpColours[,2]))))){
			colors <- currentTemboDiscretePalette(as.numeric(as.character(tmpColours[,2])))
		} else {
			colors <- currentTemboDiscretePalette(as.character(tmpColours[,2]))
		}
	}
	validateColourNames(colors)
	names(colors) <- tmpColours[,1]
	return(colors)
}
	