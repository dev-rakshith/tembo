############################################################################################
#' Upload Artifact(s) to R&D Data Lake
#' 
#' \emph{Copyright (c) 2021 Infineon Technologies}
#' @family data analysis engine
#' @author Thomas Michenthaler (IFAT DC ATV PTP TD VI TDS), \email{thomas.michenthaler@infineon.com}
#' @export uploadArtifacts
#' @param datalakeUrl string containing the URL to the R&D Data Lake
#' @param project string containing the project to which the file(s) shall be uploaded
#' @param files string containing the path(s) to the file(s) that shall be uploaded to Data Lake
#' @param bearerToken string containing the bearer token to authenticate on the R&D Data Lake
#' @param user sting containing the user name that is used for basic authentication on R&D Data Lake
#' @param password sting containing the password that is used for basic authentication on R&D Data Lake
#' @param deleteAfterUpload bool to define, if the file(s) shall be deleted after upload is done
uploadArtifacts<-function(datalakeUrl, project, files, bearerToken=NA, user=NA, password=NA, deleteAfterUpload=TRUE, verbose=FALSE) {
  
  tryCatch({
    
    # resolve user credentials
    cred=list(bearerToken=bearerToken, user=user, password=password)
    if (is.na(bearerToken) && is.na(user) && is.na(password)) cred<-getDataLakeAuthentication()
    
    if (verbose) {
      if (!is.na(cred$bearerToken)) cat("using token authentication...\n")
      else cat("using basic authentication...\n")
    }
    
    # prepare requests
    reqList<-c()
    if (!is.na(bearerToken)) {
      # token authentication
      for (file in files) {
        req<-crul::HttpRequest$new(url=paste0(datalakeUrl, "/projects/", project, "/artifacts/"),
                                   headers=crul::set_headers(Authorization=paste("Bearer", cred$bearerToken)))$post(body=list(metadata="", rawDataFile=crul::upload(file)))
        reqList<-c(reqList, req)
      }
    } else {
      # basic authentication
      for (file in files) {
        req<-crul::HttpRequest$new(url=paste0(datalakeUrl, "/projects/", project, "/artifacts/"),
                                   auth=crul::auth(cred$user, cred$password, "basic"))$post(body=list(metadata="", rawDataFile=crul::upload(file)))
        reqList<-c(reqList, req)
      }
    }
    
    # upload files to Data Lake
    response<-processHttpRequests(reqList, verbose=verbose)
    
    # delete file after successful upload
    if (deleteAfterUpload) file.remove(unique(files))
    
    if (any(sapply(response, function(x) x$status_code > 299))) {
      respFailed<-response[sapply(response, function(x) x$status_code > 299)]
      if (verbose) cat(sapply(respFailed, function(x) paste0(x$status_code, " ", x$request$payload$fields$rawDataFile$path)), sep="\n")
      stop(paste0("Failed to upload ", length(respFailed), " of ", length(files), " files: ", paste0(unique(sapply(respFailed, function(x) x$response_headers$status)), collapse=", ")))
    }
    
    content<-sapply(response, function(x) jsonlite::fromJSON(rawToChar(x$content)))
    content<-setNames(content, sapply(content, function(x) x$rawDataFile$fileName))
    artifactUrls<-lapply(content, function(x) paste0(datalakeUrl, "/projects/", project, "/artifacts/", x$artifactID))
    if (verbose) cat(paste0("Successfully uploaded ", length(files), " files to project '", project, "' on '", datalakeUrl, "'.\n"))
    
    return(artifactUrls)
    
  }, error=function(e) {
    stop(e$message)
  })
}

############################################################################################
#' Download Artifact(s) from R&D Data Lake by URL
#' 
#' \emph{Copyright (c) 2021 Infineon Technologies}
#' @family data analysis engine
#' @author Thomas Michenthaler (IFAT DC ATV PTP TD VI TDS), \email{thomas.michenthaler@infineon.com}
#' @export getArtifactsByUrl
#' @param artifactUrls array containing the URL(s) to the file(s) stored in R&D Data Lake
#' @param tempFolder string containing the path to the folder where the downloaded file(s) shall be stored
#' @param overwrite bool to define, if file to be downloaded shall be overwritten
#' @param bearerToken string containing the bearer token to authenticate on the R&D Data Lake
#' @param user sting containing the user name that is used for basic authentication on R&D Data Lake
#' @param password sting containing the password that is used for basic authentication on R&D Data Lake
getArtifactsByUrl<-function(artifactUrls, tempFolder=NA, overwrite=FALSE, bearerToken=NA, user=NA, password=NA, verbose=FALSE) {
  if (length(artifactUrls) == 0) {
    return()
  }

  tryCatch({
    
    # if not defined, set temp folder
    if (is.na(tempFolder)) tempFolder<-gsub("\\\\", "/", tempdir())
    
    # exclude artifacts that already exist
    if (!overwrite) {
      artifactUrls<-artifactUrls[!file.exists(paste0(tempFolder, "/", basename(artifactUrls), ".rds"))]
    }
    
    if (length(artifactUrls) == 0) {
      if (verbose) cat("All artifacts already exist, no files downloaded.\n")
      return()
    }
    
    # resolve user credentials
    cred=list(bearerToken=bearerToken, user=user, password=password)
    if (is.na(bearerToken) && is.na(user) && is.na(password)) cred<-getDataLakeAuthentication()
    
    if (verbose) {
      if (!is.na(cred$bearerToken)) cat("using token authentication...\n")
      else cat("using basic authentication...\n")
    }
    
    tempFileLocations<-paste0(tempFolder, "/", basename(artifactUrls), ".rds")
    
    # prepare requests
    reqList<-c()
    if (!is.na(cred$bearerToken)) {
      # token authentication
      for (i in 1:length(artifactUrls)) {
        req<-crul::HttpRequest$new(url=artifactUrls[i],
                                   headers=crul::set_headers(Authorization=paste("Bearer", cred$bearerToken)))$get(disk=tempFileLocations[i])
        reqList<-c(reqList, req)
      }
    } else {
      # basic authentication
      for (i in 1:length(artifactUrls)) {
        req<-crul::HttpRequest$new(url=artifactUrls[i],
                                   auth=crul::auth(cred$user, cred$password, "basic"))$get(disk=tempFileLocations[i])
        reqList<-c(reqList, req)
      }
    }
    
    # download files from Data Lake
    response<-processHttpRequests(reqList, verbose=verbose)
    
    if (any(sapply(response, function(x) x$status_code > 299))) {
      # remove generated files and show error msg
      file.remove(tempFileLocations)
      respFailed<-response[sapply(response, function(x) x$status_code > 299)]
      if (verbose) cat(sapply(respFailed, function(x) paste0(x$status_code, " ", x$request$url)), sep="\n")
      stop(paste0("Failed to download ", length(respFailed), " of ", length(artifactUrls), " files: ", paste0(unique(sapply(respFailed, function(x) x$response_headers$status)), collapse=", ")))
    }
    
    if (verbose) cat(paste0("Successfully downloaded ", length(artifactUrls), " files from '", datalakeUrl, "' to '", tempFolder, "'.\n"))
    
    
    
    
    return(tempFileLocations)
    
  }, error=function(e) {
    stop(e$message)
  })
}

############################################################################################
#' Download Artifact(s) from R&D Data Lake by ID
#' 
#' \emph{Copyright (c) 2021 Infineon Technologies}
#' @family data analysis engine
#' @author Thomas Michenthaler (IFAT DC ATV PTP TD VI TDS), \email{thomas.michenthaler@infineon.com}
#' @export getArtifactsByID
#' @param datalakeUrl string containing the URL to the R&D Data Lake
#' @param project string containing the project from which the file(s) shall be downloaded
#' @param artifactIDs list containing the artifact ID(s) of the file(s) that shall be downloaded
#' @param tempFolder string containing the path to the folder where the downloaded file(s) shall be stored
#' @param overwrite bool to define, if a file to be downloaded shall be overwritten
#' @param bearerToken string containing the bearer token to authenticate on the R&D Data Lake
#' @param user sting containing the user name that is used for basic authentication on R&D Data Lake
#' @param password sting containing the password that is used for basic authentication on R&D Data Lake
getArtifactsByID<-function(datalakeUrl, project, artifactIDs, tempFolder, overwrite, bearerToken=NA, user=NA, password=NA, verbose=FALSE) {
  
  tryCatch({
    
    artifactUrls<-paste0(datalakeUrl, "/projects/", project, "/artifacts/", artifactIDs)
    getArtifactByUrl(artifactUrls, tempFolder, overwrite, bearerToken, user, password, verbose)
    
  }, error=function(e) {
    stop(e$message)
  })
}

############################################################################################
#' Delete Artifact(s) from R&D Data Lake by URL
#' 
#' \emph{Copyright (c) 2021 Infineon Technologies}
#' @family data analysis engine
#' @author Thomas Michenthaler (IFAT DC ATV PTP TD VI TDS), \email{thomas.michenthaler@infineon.com}
#' @export deleteArtifactsByUrl
#' @param artifactUrls array containing the URL(s) to the file(s) stored in R&D Data Lake
#' @param bearerToken string containing the bearer token to authenticate on the R&D Data Lake
#' @param user sting containing the user name that is used for basic authentication on R&D Data Lake
#' @param password sting containing the password that is used for basic authentication on R&D Data Lake
deleteArtifactsByUrl<-function(artifactUrls, bearerToken=NA, user=NA, password=NA, verbose=FALSE) {
  
  tryCatch({
    
    # resolve user credentials
    cred=list(bearerToken=bearerToken, user=user, password=password)
    if (is.na(bearerToken) && is.na(user) && is.na(password)) cred<-getDataLakeAuthentication()
    
    if (verbose) {
      if (!is.na(cred$bearerToken)) cat("using token authentication...\n")
      else cat("using basic authentication...\n")
    }
    
    # prepare requests
    reqList<-c()
    if (!is.na(bearerToken)) {
      # token authentication
      for (i in 1:length(artifactUrls)) {
        req<-crul::HttpRequest$new(url=artifactUrls[i],
                                   headers=crul::set_headers(Authorization=paste("Bearer", cred$bearerToken)))$delete()
        reqList<-c(reqList, req)
      }
    } else {
      # basic authentication
      for (i in 1:length(artifactUrls)) {
        req<-crul::HttpRequest$new(url=artifactUrls[i],
                                   auth=crul::auth(cred$user, cred$password, "basic"))$delete()
        reqList<-c(reqList, req)
      }
    }
    
    # delete files from Data Lake
    response<-processHttpRequests(reqList, verbose=verbose)
    
    if (any(sapply(response, function(x) x$status_code > 299))) {
      respFailed<-response[sapply(response, function(x) x$status_code > 299)]
      if (verbose) cat(sapply(respFailed, function(x) paste0(x$status_code, " ", x$url)), sep="\n")
      stop(paste0("Failed to delete ", length(respFailed), " of ", length(files), " files: ", paste0(unique(sapply(respFailed, function(x) x$response_headers$status)), collapse=", ")))
    }
    
    if (verbose) cat(paste0("Successfully deleted ", length(artifactUrls), " files from '", datalakeUrl, "'.\n"))
    
  }, error=function(e) {
    stop(e$message)
  })
}

############################################################################################
#' Delete Artifact(s) from R&D Data Lake by ID
#' 
#' \emph{Copyright (c) 2021 Infineon Technologies}
#' @family data analysis engine
#' @author Thomas Michenthaler (IFAT DC ATV PTP TD VI TDS), \email{thomas.michenthaler@infineon.com}
#' @export deleteArtifactsByID
#' @param datalakeUrl string containing the URL to the R&D Data Lake
#' @param project string containing the project from which the file(s) shall be deleted
#' @param artifactIDs list containing the artifact ID(s) of the file(s) that shall be downloaded
#' @param bearerToken string containing the bearer token to authenticate on the R&D Data Lake
#' @param user sting containing the user name that is used for basic authentication on R&D Data Lake
#' @param password sting containing the password that is used for basic authentication on R&D Data Lake
deleteArtifactsByID<-function(datalakeUrl, project, artifactIDs, bearerToken=NA, user=NA, password=NA, verbose=FALSE) {
  
  tryCatch({
    
    artifactUrls<-paste0(datalakeUrl, "/projects/", project, "/artifacts/", artifactIDs)
    deleteArtifactByUrl(artifactUrls, bearerToken, user, password, verbose)
    
  }, error=function(e) {
    stop(e$message)
  })
}

############################################################################################
#' Process HTTP requests asynchronously in chunks
#' 
#' \emph{Copyright (c) 2021 Infineon Technologies}
#' @family data analysis engine
#' @author Thomas Michenthaler (IFAT DC ATV PTP TD VI TDS), \email{thomas.michenthaler@infineon.com}
#' @export processHttpRequests
#' @param httpReqList array of HTTP requests
#' @param chunkSize value to define the chunk size
processHttpRequests<-function(httpReqList, chunkSize=100, verbose=FALSE) {
  
  tryCatch({
    
    # split req list into chunks
    chunks<-split(httpReqList, ceiling(seq_along(httpReqList) / chunkSize))
    chunkresponses<-c()
    for (chunk in chunks) {
      # prepare async client
      out<-crul::AsyncVaried$new(.list=chunk)
      # send asynchronous requests and collect responses
      response<-out$request()
      chunkresponses<-c(chunkresponses, response)
      
      if (any(sapply(response, function(x) x$status_code > 299))) break
      
      if (verbose) cat(paste0("Successfully processed HTTP chunk (size=", length(chunk), ").\n"))
    }
    
    return(chunkresponses)
    
  }, error=function(e) {
    stop(paste0("Error while processing asynchronous HTTP requests (chunkSize=", chunkSize, ").\n", e$message))
  })
}

############################################################################################
#' Get User Credentials based on the Operating System
#' 
#' \emph{Copyright (c) 2021 Infineon Technologies}
#' @family tembo data analysis
#' @author Thomas Michenthaler (IFAT DC ATV PTP TD VI TDS), \email{thomas.michenthaler@infineon.com}
#' @return list containing the user credentials
getDataLakeAuthentication<-function() {
  
  tryCatch({
    
    cred<-list(bearerToken=NA, user=NA, password=NA)
    
    if (.Platform$OS.type == "windows") {
      cred$user<-Sys.info()[["user"]]
      cred$password<-tembo::getPassword()[1]
    } else if (.Platform$OS.type == "unix") {
      
      # check permissions of the json file containing the authentication information (must be 600)
      rddl<-paste0(paste0("/home/", Sys.info()[["user"]], "/Tembo/.rddlauth.json"))
      if (!file.exists(rddl)) stop("No Data Lake authentication file found.")
      if (as.character(file.mode(rddl)) != "600") stop("Please set authentication file to owner read/write-only.")
      
      # get user credentials
      if (jsonlite::validate(readChar(rddl, file.info(rddl)$size))) {
        rddlCred<-jsonlite::read_json(rddl)
        if (!is.null(rddlCred$access_token)) cred$bearerToken<-rddlCred$access_token
        # in case you want to use basic auth:
        if (!is.null(rddlCred$user)) cred$user<-rddlCred$user
        if (!is.null(rddlCred$password)) cred$password<-rddlCred$password
      }
    }
    
    return(cred)
    
  }, error=function(e) {
    stop(paste0("No valid Data Lake authentication found for ", .Platform$OS.type, " OS.\n", e$message))
  })
}