#' Deploy Tembo report template
#'
#' Deploys a local Tembo report template on the Tembo Server
#'
#' \emph{Copyright (c) 2020 Infineon Technologies} 
#' @param templateDirectory Directory containing a local Tembo report template version
#' @param templateName Name under which the report template is stored
#' @param templateDescription Description to give users some information about the given report template
#' @examples 
#' tembo::deployReportTemplate(workdir, templateName="myTemplate", templateDescription="This template is used to...")
#' @author Kunze Matthias (IFAG ATV PTP MSF DM), \email{matthias.kunze2@@infineon.com}
#' @export
deployReportTemplate <- function(templateDirectory, templateName=NA, templateDescription=NA) {
  
  #######################################################
  # Get template information
  #######################################################
  if (!file.exists(file.path(templateDirectory, 'templateInfo.r'))) {
    stop(templateDirectory, " is not a valid Tembo report template folder.")
  }
  source(file.path(templateDirectory, 'templateInfo.r'))

  #######################################################
  # Set name if defined, otherwise use from 
  # templateInfo.r
  #######################################################
  if (!is.na(templateName)) name<-templateName
  
  #######################################################
  # Put together template
  #######################################################
  templateSource<-""
  
  if (file.exists(file.path(templateDirectory, "startup.r"))) {
    startupCode<-readChar(file.path(templateDirectory, "startup.r"), file.info(file.path(templateDirectory, "startup.r"))$size)
    startupCode<-htmltools::htmlEscape(startupCode)
    startupCode<-stringr::str_replace_all(startupCode, '\\r?\\n', '<br/>')
    startupCode<-stringr::str_replace_all(startupCode, '(<br/>)?(<br/>)?(<br/>)?(<br/>)?(<br/>)?(<br/>)?(<br/>)$', '')
    templateSource<-paste0(templateSource, '<div data-type="code-report-startup">', startupCode, '</div>\n')
  }
  
  code<-readChar(file.path(templateDirectory, "code.r"), file.info(file.path(templateDirectory, "code.r"))$size)
  code<-htmltools::htmlEscape(code)
  code<-stringr::str_replace_all(code, '\\r?\\n', '<br/>')
  code<-stringr::str_replace_all(code, '.*# \\[REPORT_TEMPLATE_START\\]<br/>', '')
  code<-stringr::str_replace_all(code, '(<br/>)?(<br/>)?(<br/>)?(<br/>)?(<br/>)?(<br/>)?(<br/>)?# \\[REPORT_TEMPLATE_STOP\\].*', '')
  templateSource<-paste0(templateSource, '<div data-type="code">', code, '</div>')
  
  #######################################################
  # Update report template on server
  #######################################################
  body<-list()
  body$Name<-name
  body$Content<-templateSource
  if (!is.na(templateDescription)) body$Description<-templateDescription
  body$IsActive<-TRUE
  response<-httr::PUT(paste0(serverBaseURL, paste0("/api/ReportTemplate/", template_id)),
                      body = jsonlite::toJSON(body, auto_unbox = TRUE, pretty = TRUE),
                      httr::content_type("application/json"), httr::authenticate("", "", "ntlm"),
                      httr::config(ssl_verifypeer=0L))
  
  if (response$status_code>299) stop(paste0('Report template could not be updated\n\nHttp response:\n', httr::content(response, type = "text")))
}