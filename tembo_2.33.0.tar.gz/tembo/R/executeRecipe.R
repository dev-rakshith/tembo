#' Executes a Tembo Recipe
#'
#' Creates R code from a Tembo Recipe and executes it
#'
#' \emph{Copyright (c) 2018 Infineon Technologies} 
#' @param recipeID List of Ids of the recipes to be executed
#' @param user User name
#' @param password User password
#' @param templateLocation Storage location, from where the template shall get loaded
#' @param outFolder Folder where output data woill be stored
#' @param temboServer URL of the Tembo server where recipes will be fetched
#' @examples 
#' tembo::executeRecipe(recipeID='71ACEDA4-8456-4EC3-8609-C970F0812989', user='kunzm', password='****', templateLocation='/home/kunzm/Tembo/r/templates', outFolder='/home/kunzm/Tembo/work/')
#' @author Kunze Matthias (IFAG ATV PTP MSF DM), \email{matthias.kunze2@@infineon.com}
#' @export
executeRecipe <- function(recipeID, user, password, templateLocation, outFolder, temboServer="https://tembo.intra.infineon.com", 
                          createB64=FALSE, statisticsFolder="", useCaching=TRUE, saveRCode=FALSE, saveMetaData=FALSE) {
  
  # Create graphics device for scheduler mode
  png("NUL")
  
  # The Jupyter R Kernel operates in the global environment,
  # so make sure that each recipe is executed in the global environment

  copyEnv <- function(targetEnv, sourceEnv){
    for(varName in ls(sourceEnv)) {
      assign(varName, sourceEnv[[varName]], envir = targetEnv)
    }
  }
  copyChangesInEnv <- function(targetEnv, sourceEnv){
    sourceEnvVars <- ls(sourceEnv)
    for(varName in ls(targetEnv)) {
      if(varName %in% sourceEnvVars) {
        assign(varName, sourceEnv[[varName]], envir = targetEnv)
      }
    }
  }
  clearEnv <- function(envToClear){
      varNames <- ls(envToClear)
      varNames <- varNames[!grepl("copyEnv",varNames)]
      varNames <- varNames[!grepl("clearEnv",varNames)]
      varNames <- varNames[!grepl("tmpEnv",varNames)]
      varNames <- varNames[!grepl("TEMBO_INTERNAL_DATA_CACHE",varNames)]
      rm(list=varNames, envir=envToClear)
      gc()
  }
  assign("TEMBO_INTERNAL_DATA_CACHE", list(), envir = globalenv())  
  TEMBO_INTERNAL_DATA_CACHE$firstCall<<-TRUE
  tmpEnv <- rlang::new_environment(parent=rlang::empty_env())
  copyEnv(tmpEnv,.GlobalEnv)
  # Iterate over the recipe IDs
  tryCatch({
  for (thisRecipeID in recipeID) {
    copyChangesInEnv(tmpEnv,.GlobalEnv)
    clearEnv(.GlobalEnv)
    copyEnv(.GlobalEnv,tmpEnv)
    assign("TEMBO_INTERNAL", list(), envir = globalenv())
    TEMBO_INTERNAL$doProfiling<<-statisticsFolder!=""
    TEMBO_INTERNAL$schedulerMode<<-TRUE
    TEMBO_INTERNAL$recipeID<<-thisRecipeID
    TEMBO_INTERNAL$outFolder<<-outFolder
    TEMBO_INTERNAL$processingStartTime <- paste0(lubridate::format_ISO8601(lubridate::with_tz(Sys.time(),tzone = "UTC")),"Z")
    
    if (TEMBO_INTERNAL$doProfiling){
      TEMBO_INTERNAL$stats$hostname<<-Sys.info()[["nodename"]]
      TEMBO_INTERNAL$stats$user<<-Sys.info()[["user"]]
    }
  
    #########################################################
    # Set cache mode, this will control the bahavior of 
    # data loading templates via xsl parameter in the 
    # xsl transformation
    #########################################################
    if(exists("useCaching", envir=globalenv())){
      # Overwrite the caching of this function if useCaching is set in the global environtment
      useCaching <- globalenv()$useCaching
    }
    if (!useCaching) {
      cacheMode<-"disabled"
    } else if (useCaching & TEMBO_INTERNAL_DATA_CACHE$firstCall) {
      cacheMode<-"initialize"
    } else {
      cacheMode<-"use"
    }
    
    ###########################################################
    # Transform recipe to R code
    ###########################################################
    transformedRecipe<-transformRecipe(recipeID=thisRecipeID, user=user, password=password, 
                                   templateLocation=templateLocation, temboServer=temboServer, 
                                   doProfiling = TEMBO_INTERNAL$doProfiling,
                                   cacheMode = cacheMode)
    recipe <- transformedRecipe$stepCode
    TEMBO_INTERNAL_DATA_CACHE$firstCall<<-FALSE
    
    ###########################################################
    # Settings for the recipe
    ###########################################################
    assign("TEMBO_INTERNAL_ElasticUserName", user, envir = globalenv())
    assign("TEMBO_INTERNAL_ElasticUserPassword", password, envir = globalenv())
    assign("currentResults", data.frame(), envir = globalenv())
    assign("currentResultsType", 'overview', envir = globalenv())
    if (exists("currentTableHtml", envir=globalenv())) rm(currentTableHtml, envir=globalenv())
    assign("originalFieldNames", list(), envir = globalenv())
    assign("displayedNumberOfDigits", 4, envir = globalenv())

    ###########################################################
    # Remove plotting commands in script, they seem to cause
    # "cannot open file 'Rplots.pdf'" errors during execution
    # Todo: nicer solution inside templates
    ###########################################################
    recipe<-gsub('print\\(currentPlot\\)', '# print(currentPlot)', recipe, perl = TRUE)
    recipe<-gsub('if\\s*\\(exists\\(\'currentPlot\'\\)\\)\\s*currentPlot', '# if (exists(\'currentPlot\')) currentPlot', recipe, perl = TRUE)
    recipe<-gsub('\\s*currentTemboPlot\\$show\\s*\\(\\s*\\)', '# currentTemboPlot$show()', recipe, perl = TRUE)
    #assign("recipe", recipe, envir=globalenv())

    ###########################################################
    # Execute recipe
    ###########################################################
    if(Encoding(recipe)=="unknown") {
      Encoding(recipe) <- "UTF-8"
    }
    out<-evaluate::try_capture_stack(parse(text=recipe), env = globalenv())
    
    ###########################################################
    # Create result folder
    ###########################################################
    dir.create(file.path(outFolder, thisRecipeID), recursive = TRUE, showWarnings = FALSE)
  
    ###########################################################
    # Remove all files in folder
    ###########################################################
    do.call(file.remove, list(list.files(file.path(outFolder, thisRecipeID), full.names = TRUE)))
    
    ###########################################################
    # Store results
    ###########################################################
    if (is(out, "error")) {
    	###########################################################
      # Store error in DB
      ###########################################################
      body=list()
      body$Reason<-htmltools::htmlEscape(out$message)
      body$RootCause<-''
      body$Stack<-paste(htmltools::htmlEscape(out$calls), collapse = '\n\n')
      response<-httr::POST(paste0(temboServer, '/api/recipe/AddRecipeError?recipeId=', thisRecipeID),
                           body=jsonlite::toJSON(body, auto_unbox = TRUE),
                           httr::content_type("application/json"),
                           httr::authenticate("", "", "ntlm"), httr::config(ssl_verifypeer=0L))
      tableWhere <- gregexpr("currentTableHtml *<-",recipe)
      plotWhere <- gregexpr("currentTemboPlot\\$show", recipe)
      if(max(plotWhere[[1]]) > max(tableWhere[[1]])){
        filename <-file.path(outFolder, thisRecipeID, 'result.png')
        tryCatch({
          render_error_into_png(out)$save(filename=filename)
        }, error = function(e) {
          # if rendering the errormessage into the png fails, copy a default error message
          file.copy(system.file("","error.png",package="tembo"), filename)
        })
      } else {
        ###########################################################
        # Store error in HTML file
        ###########################################################
        do.call(file.remove, list(list.files(file.path(outFolder, thisRecipeID), full.names = TRUE)))
        fileConn<-file(file.path(outFolder, thisRecipeID, 'result.html'))
        message<-paste0('Error\n<hr/>\n', htmltools::htmlEscape(out$message), '\n\nStack:\n<hr/>\n', paste(htmltools::htmlEscape(out$calls), collapse = '\n\n'))
        message<-gsub('\\n', '<br/>', message)
        writeLines(message, fileConn)
        close(fileConn)
      }
    } else if (exists("currentTableHtml")) {
    	###########################################################    	
      # Store html result
      ###########################################################
      fileConn<-file(file.path(outFolder, thisRecipeID, 'result.html'))
      writeLines(currentTableHtml, fileConn)
      close(fileConn)
      
    } else if (exists("currentTemboPlot")) { 
    	###########################################################
      # Store plot result
      ###########################################################
      filename <-file.path(outFolder, thisRecipeID, 'result.png')
      tryCatch({
    	  currentTemboPlot$save(filename=filename)
      }, error = function(e) {
        tryCatch({
          render_error_into_png(out)$save(filename=filename)
        }, error = function(e) {
          # if rendering the errormessage into the png fails, copy a default error message
          file.copy(system.file("","error.png",package="tembo"), filename)
        })
      })

      if (createB64) {
        fileConn<-file(file.path(outFolder, thisRecipeID, 'result.b64'))
        writeLines(RCurl::base64Encode(readBin(filename, "raw", file.info(filename)[1, "size"]), "txt"), fileConn)
        close(fileConn)
      }
      
    } else {
    	###########################################################
    	# No results? Generate empty html file
    	###########################################################
    	file.create(file.path(outFolder, thisRecipeID, 'result.html'))      
      
    }
    
    ###########################################################
    # Write profiling information
    ###########################################################
    if (TEMBO_INTERNAL$doProfiling) {
      dir.create(file.path(statisticsFolder, thisRecipeID), recursive = TRUE, showWarnings = FALSE)
      fileConn<-file(file.path(statisticsFolder, thisRecipeID, 'stats.json'))
      writeLines(jsonlite::toJSON(TEMBO_INTERNAL$stats, auto_unbox = TRUE, pretty = TRUE), fileConn)
      close(fileConn)    
    }
    
    ###########################################################
    # Save R code
    ###########################################################
    if (saveRCode) {
    	dir.create(file.path(outFolder, thisRecipeID), recursive = TRUE, showWarnings = FALSE)
    	fileConn<-file(file.path(outFolder, thisRecipeID, 'recipe.R'))
    	writeLines(recipe, fileConn)
    	close(fileConn)        
    }
    TEMBO_INTERNAL$processingEndTime <- paste0(lubridate::format_ISO8601(lubridate::with_tz(Sys.time(),tzone = "UTC")),"Z") 
    if (saveMetaData) {
      jsonlite::write_json(
      list(
        "RecipeId" = thisRecipeID,
        "ReportId" = transformedRecipe$reportId,
        "ProjectName" = "",
        "QueueName" = transformedRecipe$queueName,
        "ProcessingStartTime" = TEMBO_INTERNAL$processingStartTime,
        "ProcessingEndTime" = TEMBO_INTERNAL$processingEndTime
      ),
      path = file.path(outFolder, thisRecipeID, 'metadata.json'),
      auto_unbox = TRUE,
      null='null'
      )
    }
  }
  },
  finally = {
    clearEnv(.GlobalEnv)
    copyEnv(.GlobalEnv,tmpEnv)
  }
  )
}


render_error_into_png <- function(out) {
  body<-data.frame(Reason = paste("Error: ", out$message), Stack=paste("Stack:\n", paste(out$calls, collapse = '\n\n')))
  plotObject <- tembo::temboPlot$new(plotName="Text")
  plotObject$addData(body)
  plotObject$plot[[1]] <- ggplot2::ggplot(body)
  plotObject$addToPlot( ggplot2::geom_text(ggplot2::aes(0,10,label=Reason), size=4) )
  plotObject$addToPlot( ggplot2::geom_text(ggplot2::aes(0,5,label=Stack), size=2) )
  plotObject$addToPlot( ggplot2::theme(
    panel.background = ggplot2::element_blank(),
    panel.border = ggplot2::element_rect(colour="black", fill=NA),
    axis.text.x = ggplot2::element_blank(),
    axis.ticks.x = ggplot2::element_blank(),
    axis.text.y = ggplot2::element_blank(),
    axis.ticks.y = ggplot2::element_blank(),
  ) )
  plotObject$addToPlot( ggplot2::ylab("") )
  plotObject$addToPlot( ggplot2::xlab("") )
  plotObject$addToPlot( ggplot2::scale_y_continuous(limits=c(0,11)) )
  
  return(plotObject)
}
