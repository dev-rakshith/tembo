#===============================================================================================
#' This function is used in R templates, to:
#'
#' 1) show ggplot2 axes in engineering notation, e.g.:
#'    currentPlot <- currentPlot + ggplot2::scale_x_continuous(labels = tembo::format_si(digits=2)
#'
#' 2) generate your individual format-function, e.g.:
#'    num2eng <- tembo::format_si(digits=3)
#'    ==> num2eng(0.000123456789) => 123.457u
#'    num2eng <- tembo::format_si(digits=1)
#'    ==> num2eng(c(0.000123456789, 0.000987654321)) => [123.5u, 987.7u]
#'
#'
#' @author Thomas Michenthaler (IFAT DC ATV PTP MSF VI), \email{thomas.michenthaler@infineon.com}
#' @export
format_si <- function(..., digits = 1, unit="", scale=NULL, isPlotting = TRUE, removeUnitString = FALSE) {
  return(function(x) {
  	base10 <- c(1e-24, 1e-21, 1e-18, 1e-15, 1e-12,
  							1e-9,  1e-6,  1e-3,  1e0,   1e3,
  							1e6,   1e9,   1e12,  1e15,  1e18,
  							1e21,  1e24)
  	symbol <- c("y",   "z",   "a",   "f",   "p",
  							"n",   "u",   "m",   "",   "k",
  							"M",   "G",   "T",   "P",   "E",
  							"Z",   "Y")
  	if(all(is.na(x))){
  		#if the numbers are NA, dont do formatting
  		return(paste0(x))
  	}
  	if(!is.null(scale)){
  	  if(is.na(scale)){
  	    scale <- NULL
  	  }
  	}
  	if(is.null(scale)){
  		# get 'base10' array indices according to numeric values in 'x'
  		i <- findInterval(abs(x), base10)
  		# don't show a prefix for '0' or very small/high values (>1e24 | <1e-24)
  		i <- ifelse(i == 0, which(base10 == 1e0), i)
  	} else {
  		if(length(which(scale==seq(-24,24,3)))==0){
  			stop("invalid scale:", scale)
  		}
  		i <- rep(which(10^scale*base10==1)[1], length(x))	
  	}
    # return values of 'x' in engineering notation
    loopCounter <- 0
    returnValues <- paste0(format(round(x / base10[i], digits), trim = TRUE, scientific = FALSE), symbol[i], unit)
    if( isPlotting ){
    	#increase number of digits, if information axis values would not have enough information
    	while(length(returnValues) != length(unique(returnValues)) & loopCounter < 5) {
    		digits <- digits + 1
    		returnValues <- paste0(format(round(x / base10[i], digits), trim = TRUE, scientific = FALSE), symbol[i], unit)
    		loopCounter <- loopCounter + 1    	
    	}
      #probe if additional information is necessary(for example a 0.7 that should be a 0.75:
      digits <- digits + 1
      newReturnValues <- paste0(format(round(x / base10[i], digits), trim = TRUE, scientific = FALSE), symbol[i], unit)
      if(!all(grepl("0$",newReturnValues)) & length(newReturnValues)>1){
        returnValues <- newReturnValues
      }
    }
    if ( removeUnitString ){
    	returnValues <- gsub("([-0-9\\.]+).*", "\\1", returnValues)
    }
    return(returnValues)
  })
}


guess_scale <- function(myValues){
  "Guess the scale based on values"
  if(is.numeric(myValues)){
    possibleScales <- seq(-24,24,3)
    guessValues <- c(min(myValues,na.rm=T),
                     max(myValues,na.rm=T), 
                     median(myValues,na.rm=T)
    )
    foundIntervals <- findInterval(abs(guessValues), 10^possibleScales)
    if(sum(foundIntervals==0)>0){
      foundIntervals <- foundIntervals[foundIntervals!=0]
      if(length(foundIntervals)==0){
        foundIntervals <- 9
      } else if(length(foundIntervals) == 2){
        foundIntervals <- c(foundIntervals,min(foundIntervals))
      }
    }
    newScale <- possibleScales[median(foundIntervals)]
    return(-newScale)
  }
  return(NULL)
}

guess_unit_scale <- function(unitString){
  "Guess the unit and the scale based on a provided unitstring"
  base10 <- c(-24, -21, -18, -15, -12,
              -9,  -6,  -6,  -3,  0,   3,
              6,   9,   12,  15,  18,
              21,  24)
  symbol <- c("y",   "z",   "a",   "f",   "p",
              "n",   "u", "µ",   "m",   "",   "k",
              "M",   "G",   "T",   "P",   "E",
              "Z",   "Y")
  multiLetterUnits <- c("mol", "cd", "rad", "sr", "Hz",
                        "Pa", "Wb", "lm", "lx",
                        "Bq", "Gy", "Sv", "kat",
                        "eV")
  if(nchar(unitString)==1 || unitString %in% multiLetterUnits){
    return(data.frame(unit=unitString,scale=0))
  } else {
    firstChar <- gsub("^(.).*", "\\1", unitString)
    furtherChars <- gsub("^.", "", unitString)
    if(firstChar %in% symbol) {
      return(data.frame(
        unit=furtherChars,
        scale= -base10[which(firstChar == symbol)]
      ))
    } else {
      return(data.frame(unit=unitString,scale=0))
    }
  }
}
