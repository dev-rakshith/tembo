
temboURL <- "https://unix-tembo.vih.infineon.com"

#' Set the URL of the fsdb server
#'
#' This functions sets an internal variable pointing to the fsdb server
#'
#' \emph{Copyright (c) 2018 Infineon Technologies}
#' @param url character
#' @return NULL
#' @examples
#' setFsdbUrl("https://example.org")
#' @author Helena Schmidt \email{schmidt.externel9@@infineon.com}
#' @export
setFsdbUrl <- function(url){
  temboURL <<- url
}

#' Load Fsdb index from fsdb file
#'
#'
#' \emph{Copyright (c) 2019 Infineon Technologies}
#' @param fsdbFileName character
#' @param fsdbIndex data.frame it can attach the new index to the given index and loads only the new index im the index of the file is not loaded to fsdbIndex
#' @return fsdbIndex
#' @examples
#' temboURL <- "https://example.org"
#' @author Helena Schmidt \email{schmidt.externel9@@infineon.com}
#' @export
getFsdbIndexFromFile <- function(fsdbFileName, fsdbIndex=NULL){
	doReadFileIndex <- TRUE
	if(!is.null(fsdbIndex)){
		if(fsdbFileName %in% fsdbIndex$filename){
			doReadFileIndex <- FALSE
		}
	}
	if(doReadFileIndex){
		Sys.setenv(QUERY_STRING=paste0('filename=',gsub("\\\\", "/", fsdbFileName)))
		if(file.exists(fsdbFileName)){
			tryCatch({
				executablePath <- system.file("inst", "fsdbLoadIndex.exe", package="tembo")
				if(executablePath == ""){
					executablePath <- system.file("fsdbLoadIndex.exe", package="tembo")
					if(executablePath == ""){
						stop("The tembo Package was not installed properly")
					}
				}
				jsonData <- system2(executablePath, stdout = TRUE, stderr = FALSE)
				tmpFsdbIndex <- loadIndexFromJson(jsonData)
				tmpFsdbIndex$filename <- fsdbFileName
			},
			error = function(e){stop(paste0("file ", fsdbFileName, " could not be loaded with error ", e))})
		}

		if(exists("tmpFsdbIndex")){
		  tmpFsdbIndex$isOnFsdbServer <- FALSE
			if(!is.null(fsdbIndex)){
				fsdbIndex <- rbind(fsdbIndex,tmpFsdbIndex)
			} else {
				fsdbIndex <- tmpFsdbIndex
			}    
		}
		Sys.setenv(QUERY_STRING="")
	}
	return(fsdbIndex)
}


getFsdbIndexFromServer <- function(fsdbFileName, fsdbIndex=NULL){
  doReadFileIndex <- TRUE
  if(!is.null(fsdbIndex)){
    if(fsdbFileName %in% fsdbIndex$filename){
      doReadFileIndex <- FALSE
    }
  }
  if(doReadFileIndex){
    httr::set_config(httr::config(ssl_verifypeer=0L))
    tmpFsdbIndex<-httr::GET(paste0(temboURL,"/cgi-bin/fsdbGetIndex.cgi?filename=",fsdbFileName))
    if(is.na(httr::content(tmpFsdbIndex, "text"))){
      stop(paste("File", fsdbFileName, "could not be loaded. Is it spelled wrongly or does not even exist?"))
    }
    
    tmpFsdbIndex <- loadIndexFromJson(httr::content(tmpFsdbIndex, "text"))

    tmpFsdbIndex$filename <- fsdbFileName
    tmpFsdbIndex$isOnFsdbServer <- TRUE
    if(!is.null(fsdbIndex)){
      fsdbIndex <- rbind(fsdbIndex,tmpFsdbIndex)
    } else {
      fsdbIndex <- tmpFsdbIndex
    }    
  }
  return(fsdbIndex)
}

#' Load data from the fsdb server
#'
#' Loads the data from an fsdb file on the server with the index number given in signalIndex
#' 
#'
#' \emph{Copyright (c) 2018 Infineon Technologies}
#' @param fsdbFileName File path of the fsdb file
#' @param signalIndex Index number of the signal in the file as an integer
#' @return NULL
#' @examples
#' loadFSDBData("/path/to/file.fsdb",fsdbIndex)
#' @author Helena Schmidt \email{schmidt.externel9@@infineon.com}
#' @export
loadFSDBDataFromServer <- function(fsdbFileName, signalIndex){
	#stop(signalIndex)
	fsdbURI <- paste0(temboURL, "/cgi-bin/fsdbGetSignal.cgi?filename=", fsdbFileName, "&index=", signalIndex)
	#stop(fsdbURI)
  signalRequest<-httr::GET(fsdbURI)
  if(is.na(httr::content(signalRequest, "text"))){
    stop(paste("File", fsdbFileName, "could not be loaded. Is it spelled wrongly or does not even exist?"))
  }
  
  signal <- loadDataFromJson(httr::content(signalRequest, "text"))
  return(signal)
}


#' Load data from the fsdb file
#'
#' Loads the data from an fsdb file on a fileokane with the index number given in signalIndex
#' 
#'
#' \emph{Copyright (c) 2018 Infineon Technologies}
#' @param fsdbFileName File path of the fsdb file
#' @param signalIndex Index number of the signal in the file as an integer
#' @return NULL
#' @examples
#' loadFSDBDataFromFile("/path/to/file.fsdb",fsdbIndex)
#' @author Helena Schmidt \email{schmidt.externel9@@infineon.com}
#' @export
loadFSDBDataFromFile <- function(fsdbFileName, signalIndex){

	Sys.setenv(QUERY_STRING=paste0('filename=',gsub("\\\\", "/", fsdbFileName),"&","index=",signalIndex))
	if(file.exists(fsdbFileName)){
		tryCatch({
			executablePath <- system.file("inst", "fsdbLoadSignal.exe", package="tembo")
			if(executablePath == ""){
				executablePath <- system.file("fsdbLoadSignal.exe", package="tembo")
				if(executablePath == ""){
					stop("The tembo Package was not installed properly")
				}
			}
			jsonData <- system2(executablePath, stdout = TRUE, stderr = FALSE)
			signal <- loadDataFromJson(jsonData)
		},
		error = function(e){stop(paste0("file ", fsdbFileName, " could not be loaded with error ", e))})
	}
	Sys.setenv(QUERY_STRING="")
	return(signal)
}


loadIndexFromJson <- function(jsonIndex){
	err<-tryCatch({
		tmpFsdbIndex<-jsonlite::fromJSON(gsub("\\n", "", paste0(jsonIndex,collapse="")))
		NA
	},
	error=function(e){
		split<-gsub("\"", "", unlist(regmatches(jsonIndex, gregexpr("\"(.*?)\"", jsonIndex))))
		paste0("Error reading file (FSDB version: ", split[which(split == "version") + 1], ")")
	})
	if (!is.na(err)) {
		stop(err)
	}
	
	tmpFsdbIndex$signals$scope<-lapply(tmpFsdbIndex$signals$scope, function(x) paste(x, collapse = "."))
	tmpFsdbIndex<-data.frame(tmpFsdbIndex$signals)
	return(tmpFsdbIndex)
}

loadDataFromJson <- function(jsonData){
	err<-tryCatch({
		signal<-jsonlite::fromJSON(gsub("\\n", "", paste0(jsonData,collapse="")))
		NA
	},
	error=function(e){
		split<-gsub("\"", "", unlist(regmatches(jsonData, gregexpr("\"(.*?)\"", jsonData))))
		paste0("Error reading file (FSDB version: ", split[which(split == "version") + 1], ")")
	})

	if (!is.na(err)) {
		stop(err)
	}
	scale <- 1
	if(grepl('as?$',signal$scale_unit)[1]){
		scale <- 1e-18
	} else if(grepl('fs?$',signal$scale_unit)[1]){
		scale <- 1e-15
	} else if(grepl('ps?$',signal$scale_unit)[1]){
		scale <- 1e-12
	} else if(grepl('ns?$',signal$scale_unit)[1]){
		scale <- 1e-9
	} else if(grepl('us?$',signal$scale_unit)[1]){
		scale <- 1e-6
	} else if(grepl('ms?$',signal$scale_unit)[1]){
		scale <- 1e-3
	}
	signal$signal$t<-signal$signal$t*scale
	return(signal)
}