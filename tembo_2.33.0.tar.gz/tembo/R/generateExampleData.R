#' Create a tembo test data
#'
#'
#' \emph{Copyright (c) 2018 Infineon Technologies}
#' @return List of dat and currentLimits
#' @examples
#' tmp <- generateTestData()
#' dat <- tmp[[1]]
#' currentLimits <- tmp[[2]]
#' @family tembo test data
#' @author Helena Schmidt \email{schmidt.externel9@@infineon.com}
#' @export
generateTestData <- function(){
  set.seed(12345)
  dat <- data.frame(IVS_28V = c(rnorm(1000),rnorm(1000)+1,rnorm(1000)+2,rnorm(1000)+0.2,rnorm(1000)+1.2,rnorm(1000)+2.2),
                    product_variant = c(rep("200mm",3000),rep("300mm",3000)),
                    cond_tambient = c(rep(-40,1000),rep(25,1000),rep(150,1000),rep(-40,1000),rep(25,1000),rep(150,1000)),
  									stringsAsFactors = FALSE)
  
  currentLimits <- data.frame(name = rep("IVS_28V",12), limit_type = c(rep("spec",6),rep("test",6)), 
                              min = rnorm(12,sd=4)-15, max = rnorm(12,sd=4) + 15, cond_tambient = rep(c(-40,25,150),4), 
                              product_variant = c(rep("200mm",3),rep("300mm",3),rep("200mm",3),rep("300mm",3)),
  														stringsAsFactors = FALSE)
  return(list(dat,currentLimits))
}

#' Create a tembo test data
#'
#'
#' \emph{Copyright (c) 2018 Infineon Technologies}
#' @return List of dat and currentLimits
#' @examples
#' tmp <- generateTestTwoVariableData()
#' dat <- tmp[[1]]
#' currentLimits <- tmp[[2]]
#' @family tembo test data
#' @author Helena Schmidt \email{schmidt.externel9@@infineon.com}
#' @export
generateTestTwoVariableData <- function(){
  set.seed(12345)
  dat <- data.frame(IVS_28V = c(rnorm(1000),rnorm(1000)+1,rnorm(1000)+2,rnorm(1000)+0.2,rnorm(1000)+1.2,rnorm(1000)+2.2),
                    product_variant = c(rep("200mm",3000),rep("300mm",3000)),
                    cond_tambient = c(rep(-40,1000),rep(25,1000),rep(150,1000),rep(-40,1000),rep(25,1000),rep(150,1000)),
  									stringsAsFactors = FALSE)
  
  dat$IVS_30V = c(rnorm(1000)*0.2,rnorm(1000)*0.2+2,rnorm(1000)*0.2+3,rnorm(1000)*0.2+1.2,rnorm(1000)*0.2+2.2,rnorm(1000)*0.3+3.2)
  
  currentLimits <- data.frame(name = rep("IVS_28V",12), limit_type = c(rep("spec",6),rep("test",6)), 
                              min = rnorm(12,sd=4)-15, max = rnorm(12,sd=4) + 15, cond_tambient = rep(c(-40,25,150),4), 
                              product_variant = c(rep("200mm",3),rep("300mm",3),rep("200mm",3),rep("300mm",3)),
  														stringsAsFactors = FALSE)
  currentLimits <- rbind(currentLimits,
                         data.frame(name = rep("IVS_30V",12), limit_type = c(rep("spec",6),rep("test",6)), 
                                    min = rnorm(12,sd=4)-15, max = rnorm(12,sd=4) + 15, cond_tambient = rep(c(-40,25,150),4), 
                                    product_variant = c(rep("200mm",3),rep("300mm",3),rep("200mm",3),rep("300mm",3)),
                         					  stringsAsFactors = FALSE)
  )
  return(list(dat,currentLimits))
}

#' Create a tembo test data
#'
#'
#' \emph{Copyright (c) 2018 Infineon Technologies}
#' @return List of dat and currentLimits
#' @examples
#' tmp <- generateTestDataWithNAs()
#' dat <- tmp[[1]]
#' currentLimits <- tmp[[2]]
#' @family tembo test data
#' @author Helena Schmidt \email{schmidt.externel9@@infineon.com}
#' @export
generateTestDataWithNAs <- function(){
  tmp <- generateTestData()
  dat <- tmp[[1]]
  currentLimits <- tmp[[2]]
  dat <- rbind(dat, dat[1:1000,])
  dat$product_variant <- as.character(dat$product_variant)
  dat$product_variant[6001:7000] <- "250mm"
  dat$cond_tambient[6001:7000] <- NA
  return(list(dat,currentLimits))
}


#' Create a tembo test data
#'
#'
#' \emph{Copyright (c) 2018 Infineon Technologies}
#' @return List of dat and currentLimits
#' @examples
#' dat <- generateWaveformData()
#' @family tembo test data
#' @author Helena Schmidt \email{schmidt.externel9@@infineon.com}
#' @export
generateWaveformData <- function(){
  #########################
  #### Dummy FSDB Data ####
  #########################
  
  set.seed(12345)
  # VIN1
  u1 <- c(rep(0,10),rep(5,100),rep(0,100)) + rnorm(210)*0.05
  u2 <- c(rep(0,10),rep(5,100),rep(0,100)) + rnorm(210)*0.05
  
  # VOUT1
  y1 <- rep(0,210) + rnorm(210)*0.05
  y1[seq(11,110)] <- 5*(1-exp(-seq(100)/10)) + y1[seq(11,110)]
  y1[seq(111,210)] <- 5*exp(-seq(100)/10) + y1[seq(111,210)]
  #plot(y1)
  
  #VOUT2
  y2 <- rep(0,210) + rnorm(210)*0.05
  y2[seq(11,110)] <- 5*(1-exp(-seq(100)/15)) + y2[seq(11,110)]
  y2[seq(111,210)] <- 5*(exp(-seq(100)/15)) + y2[seq(111,210)]
  #plot(y2)
  
  VIN1 <- list(y=u1*10,t=seq(210)/105)
  VIN2 <- list(y=u2,t=(seq(210)/105+0.1)%%2)
  VOUT1 <- list(y=y1*8,t = seq(210)/105)
  VOUT2 <- list(y = y2,t = (seq(210)/105+0.1)%%2)
  
  dat <- data.frame(dummy = 1)
  dat$VIN1 <- list(VIN1)
  dat$VIN2 <- list(VIN2)
  dat$VOUT1 <- list(VOUT1)
  dat$VOUT2 <- list(VOUT2)
  return(dat)
}
