#' Create a tembo line plot with reduced data to plot
#'
#' This function behaves exactly like geom_line(), except that it reduces the data to
#' a maximum and minimum per tembo pixel (840 pixel)
#'
#' \emph{Copyright (c) 2021 Infineon Technologies}
#' @param data data frame
#' @param geom "line"
#' 
#' @return Returns a ggplot2 graph object
#' @examples
#' ggplot(data) + aes(x,y) + geom_line_reduced()

#' @family tembo plots
#' @author Helena Schmidt \email{schmidt.externel9@@infineon.com}
#' @export
geom_line_reduced <- function(mapping = NULL, data = NULL, stat = "identity",
                              position = "identity", na.rm = FALSE, orientation = NA,
                              show.legend = NA, inherit.aes = TRUE, ...) {
  layer(
    data = data,
    mapping = mapping,
    stat = stat,
    geom = GeomLineReduced,
    position = position,
    show.legend = show.legend,
    inherit.aes = inherit.aes,
    params = list(
      na.rm = na.rm,
      orientation = orientation,
      ...
    )
  )
}

GeomLineReduced <- ggproto("GeomLineReduced", GeomPath,
                           setup_params = function(data, params) {
                             params$flipped_aes <- has_flipped_aes(data, params, ambiguous = TRUE)
                             params
                           },
                           
                           extra_params = c("orientation"),
                           
                           setup_data = function(data, params) {
                             require(dplyr)
                             data$flipped_aes <- params$flipped_aes
                             data <- flip_data(data, params$flipped_aes)
                             if(nrow(data) > 1000){
                               data <- data %>% 
                                 filter(
                                   !is.na(x)
                                 ) %>%
                                 mutate(
                                   bin = cut(x, breaks = 840)
                                 ) %>% 
                                 group_by(bin, PANEL, group, colour, flipped_aes) %>%
                                 summarise(
                                   x = median(x),
                                   y1 = min(y,na.rm=TRUE),
                                   y2 = max(y,na.rm=TRUE)
                                 ) %>%
                                 tidyr::pivot_longer(
                                   cols = starts_with("y"),
                                   names_to = "foo",
                                   values_to = "y"
                                 ) %>%
                                 select(-foo) %>%
                                 ungroup() %>%
                                 select(-bin) %>%
                                 mutate(y = if_else(is.infinite(y), NA_real_, y))
                             }
                             data <- data[order(data$PANEL, data$group, data$x), ]
                             flip_data(data, params$flipped_aes)
                           }
)
