############################################################################################
#' Get Tembo password from a keyring
#' 
#' This function is used to fetch Tembo Password from Windows Credential Manager or
#' corresponding password managers on other operating systems.
#' 
#' If you want to use tembo in RStudio, you need the keyring and getPass packages installed.
#' getPassword() tries to fetch the password from the configured keyring (or the default),
#' if no Tembo password is stored, the user is asked to provide the password. Then it is 
#' stored in the credential store and fetched the next time getPassword() is called.
#' If you want to use a different keyring, you can create one with:
#' keyring::keyring_create("tembo")
#' You will be asked a password to lock the keyring with it. Then you can configure R to use the
#' created keyring:
#' options(keyring_keyring = "tembo")
#' If you want to lock the keyring before closing your R session, you can now call:
#' keyring::keyring_lock("tembo")
#' If the keyring is locked, running getPassword() will result in asking you about the keyring password
#' 
#' Note: There is a known issue that keyring might be incompatible with use of devtools::load_all()
#'  on windows: https://github.com/r-lib/keyring/issues/73
#' 
#' \emph{Copyright (c) 2018 Infineon Technologies}
#' @author Michenthaler Thomas (IFAT DC ATV PTP MSF VI), \email{thomas.michenthaler@infineon.com}
#' @seealso \code{\link{deletePassword()}}
#' @seealso \code{\link{updatePassword()}}
#' @export
getPassword <- function() {
  
	if (Sys.info()['sysname'] == "Windows"){
	  #try powershell cmdlet only on windows		
	  try({
		  script<-"$cred=Get-StoredCredential -Target Tembo;
		  if (-not [string]::IsNullOrEmpty($cred)) {
		  $encryptedPW = $cred.Password[0];
		  $bstr = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($encryptedPW);
		  [System.Runtime.InteropServices.Marshal]::PtrToStringAuto($bstr);}"
		  
		  pw<-system2("powershell.exe", script, stdout=T)
		  
		  if (length(pw) != 0 & is.null(attr(pw,"status"))) {
		    return(pw)
		  }
	  })
	}
  # passwordfile in the Unix home
  filepath <- paste0("/home/", Sys.info()[["user"]], "/Tembo/.pass")
  if(Sys.info()['sysname'] == "Linux" & file.exists(filepath))  {
    pw <- gsub("\\n", "",
         readChar(filepath, file.info(filepath))
    )[1]
  } else {
    if('keyring' %in% .packages(all.available = TRUE)){
      if(keyring::has_keyring_support()){
        tryCatch({
          pw <-keyring::key_get("Tembo", Sys.info()[["user"]])
          attr(pw, "fromKeyring") <- TRUE
        }, error = function(e) {
          pw <- getPass::getPass("Password for Tembo:")
          attr(pw, "fromKeyring") <- TRUE
          #not sure if good idea, because it could be necessary to change im password is wrong
          keyring::key_set_with_value("Tembo", Sys.info()[["user"]],password=pw)
        })
        return(pw)
    }}
    pw <- getPass::getPass("Password for Tembo:")
    attr(pw, "justAsked") <- TRUE
  }
	return(pw)
}


############################################################################################
#' Delete the Tembo password from a keyring
#' 
#' This function is used to delete the Tembo Password from Windows Credential Manager or
#' corresponding password managers on other operating systems.
#' 
#' \emph{Copyright (c) 2019 Infineon Technologies}
#' @author Helena Schmidt \email{schmidt.externel9@@infineon.com}
#' @seealso \code{\link{getPassword()}}
#' @seealso \code{\link{updatePassword()}}
#' @export
deletePassword <- function() {
	if(keyring::has_keyring_support()){
		tryCatch({
			keyring::key_delete("Tembo", Sys.info()[["user"]])
			print("Key deleted")
		})
	}
}
	
	
############################################################################################
#' Update Tembo Password in a keyring
#' 
#' This function is used to update Tembo Password in Windows Credential Manager or
#' corresponding password managers on other operating systems.
#' 
#' \emph{Copyright (c) 2019 Infineon Technologies}
#' @author Helena Schmidt \email{schmidt.externel9@@infineon.com}
#' @seealso \code{\link{getPassword()}}
#' @seealso \code{\link{deletePassword()}}
#' @export
updatePassword <- function() {
	if(keyring::has_keyring_support()){
	  pw <- getPass::getPass("Password for Tembo:")
	  if(is.character(pw)){
	  	if(nchar(pw)>0){
	  		keyring::key_set_with_value("Tembo", Sys.info()[["user"]],password=pw)
	  		print("Password updated")
	  	}
	  }
	}
}
