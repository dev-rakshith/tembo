#===================================================================================================
#' Tembo Template Processor
#'
#' Get recipe content as XML via Rest API, using recipe ID
#'
#' \emph{Copyright (c) 2017 Infineon Technologies}
#' @param pageId Confluence page ID of root page
#' @return XML content of requested recipe
#' @examples
#' getRecipeXmlContent("ede449803e9a4e8097fa9464daf688d5")
#' @family Report templates
#' @author Thomas Michenthaler (IFAT DC ATV PTP MSF VI), \email{thomas.michenthaler@infineon.com}
#' @export
#---------------------------------------------------------------------------------------------------
getRecipeXmlContent<-function(recipeID)
{
  ret<-httr::GET(paste0("https://tembo-dev.intra.infineon.com/tembo_dev/api/recipe/GetRecipe?recipeId=", recipeID), httr::authenticate("", "", "gssnegotiate"), httr::config(ssl_verifypeer=0L))
  json<-jsonlite::fromJSON(toString(ret))
  
  return(XML::xmlParse(json$Recipe))
}
