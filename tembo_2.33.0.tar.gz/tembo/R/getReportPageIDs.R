#===================================================================================================
#' Tembo Template Processor
#'
#' Get a list of Confluence page IDs consisting of the parent ID and IDs of all underlying Confluence pages (children, grandchildren, etc.)
#'
#' \emph{Copyright (c) 2017 Infineon Technologies}
#' @param pageId Confluence page ID of root page
#' @return list of IDs
#' @examples
#' getAllReportPageIDs("12345678")
#' @family Report templates
#' @author Thomas Michenthaler (IFAT DC ATV PTP MSF VI), \email{thomas.michenthaler@infineon.com}
#' @export
#---------------------------------------------------------------------------------------------------
getReportPageIDs<-function(pageId)
{
  reportPageIDs<<-c(reportPageIDs, pageId)
  
  # get response from Confluence Rest API about its children
  ret<-httr::GET(paste0("https://confluencewikiprod.intra.infineon.com/rest/api/content/", pageId, "/child/page"), httr::authenticate("", ""), httr::config(ssl_verifypeer=0L))
  # parse to JSON
  json<-jsonlite::fromJSON(toString(ret))
  # get list of child-page IDs
  pageIdChildren<-json$results$id
  
  if(!is.null(pageIdChildren))
  {
    for(i in 1:length(pageIdChildren))
    {
      getReportPageIDs(pageIdChildren[i])
    }
  }
}