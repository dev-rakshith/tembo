#===============================================================================================
#' This function calculates guard banded limits, based on the Code provided by 
#' Giarda Katia (IFAG ATV BP D PD PRSE) <Katia.Giarda@infineon.com>
#' 
#' The function uses the tembo data format as input
#'
#' @author Helena Schmidt, \email{schmidt.external9@infineon.com}
#' @export
calculateGuardBandedLimits <- function(dat, currentLimits, param)
{
  # only one limit is needed as reference
  currentLimit <- subset(currentLimits, name==param)[1,]
  tmp <- transformDataToGbMatrix(dat, param)
  vgtMatrix <- tmp[[1]]
  myMatrix <- tmp[[2]]
  corrected_matrix <- correctForTesterOffset(myMatrix, vgtMatrix)
  #Fitting clusters does not work with NAs in the matrix
  #myMatrix <- myMatrix[complete.cases(myMatrix),]
  clusters<-clusterGbData(corrected_matrix)
  SD<-calculateGbStats(clusters,corrected_matrix)

  newLimits<-calculateNewGbLimits(SD,corrected_matrix,currentLimit)
  return(list(
    limits=newLimits,
    clusters=clusters
    ))
}


#===============================================================================================
#' This function calculates outlier that might result in wrong guard banded limits,
#' based on the Code provided by 
#' Lukas Sommeregger (IFAT DC ATV CQS ACM) <Lukas.Sommeregger@infineon.com>
#' 
#' The function uses the tembo data format as input
#'
#' @author Helena Schmidt, \email{schmidt.external9@infineon.com}
#' @export
findGbOutlier <- function(dat, param)
{
  # only one limit is needed as reference
  tmp <- transformDataToGbMatrix(dat, param)
  vgtMatrix <- tmp[[1]]
  myMatrix <- tmp[[2]]
  corrected_matrix <- correctForTesterOffset(myMatrix, vgtMatrix)
  clusters<-clusterGbData(corrected_matrix)
  outlier<-c()
  #Fitting clusters does not work with NAs in the matrix
  for(cluster in clusters){
    an<-gbAngles(cluster)
    #simple outlier detection, WIP
    #outlier as in atypical behaviour compared to the rest of data
    
    for(l in 1:ncol(an)){ #try all slopes, .99999 and .00001 are sensitivity parameters: less decimals mean more outliers
      ul<-qnorm(.999999,median(gbAngles(corrected_matrix)[,l]),mad(gbAngles(corrected_matrix)[,l])) #get robust behaviour
      ll<-qnorm(.000001,median(gbAngles(corrected_matrix)[,l]),mad(gbAngles(corrected_matrix)[,l])) #upper and lower bounds
      
      #rows where we have unusual (outlier) behaviour in slopes:
      outlnew<-which(an[,l]>ul|an[,l]<ll,arr.ind = TRUE) #i.e. 
      outlier<-c(outlier,outlnew) #indices of outlier slopes
    }
  }
  outlier<-unique(outlier)#remove duplicates 
  return(outlier)
}


clusterGbData<-function(C)
{
  ###CLUSTER data
  if(nrow(C)==1){
    return(list('1'=C))
  }
  
  library(mclust)
  c.gmm <- mclust::Mclust(C)#an or C - das ist die Frage!

  nclust <- length(unique(c.gmm$classification)) #catch if less clusters than initialized
  #ugly but for testing:
  
  clusters <- list() #initialize list of clusters
  
  for(c in 1:nclust){ #foreach cluster:
    cl <- c() #initialize
    js <- c()
    for (j in 1:dim(C)[1]){ #go over all
      if (c.gmm$classification[j]==c){ #add to cluster
        cl=rbind(cl,C[j,])
        js <- c(js,j)
      }
    }
    rownames(cl) <- js
    clusters[[paste(c)]]=cl
  }
  return(clusters)
}

gb_cumdepvar <- function(C,errorsd=0)
{ #gets a matrix and an vector for error sds (columnwise), returns vector with variances for sum of matrix (colwise)
  res <- c()
  
  cov <- cov(C) #if normal: covariance 

  if(errorsd!=0){ #substract errors (single?)
    #make correction matrix - variance in slopes due to measurement error - see paper
    corr <- diag(2*errorsd^2,nrow(cov),ncol(cov)) #set diagonal to 2*error
    diag(corr[-nrow(corr),-1]) <- -errorsd^2 #make super- and subdiagonal equal to -error
    diag(corr[-1,-ncol(corr)]) <- -errorsd^2
    cov <- cov-corr
  }
  
  for (i in 1:ncol(C)){
    r <- c(rep(1,i),rep(0,ncol(C)-i)) #generate vector of the form (1,1,...,1,0,0,...0) to sum over all covariances in the top left corner of the cov. matrix
    out <- t(r)%*%cov%*%r #via matrix multiplication
    res <- c(res,out)
  }
  res[res<0]=0 #catch possible negative variance?
  return(res)
}

calculateGbStats<-function(clusters,C)
{
  SD <- NULL
  
  SD$pro<-c() #probabilities

  SD$means.an<-c()
  SD$sds.an<-c()

  nclust<-length(clusters)
  for(cluster_id in 1:nclust){ #model all clusters
    #forall clusters
    
    cluster<-clusters[[cluster_id]]
    
    an<-gbAngles(cluster)
    #head(cluster)
    
    times <- as.integer(colnames(cluster))
    #get times as colnames
    jumps <- as.numeric(diff(times) )
    #get differences between times
    
    if (length(jumps)==1) #Katia
    {
      angledJumps <- an*jumps[1]
    }else
    {
      angledJumps <- an%*%diag(jumps)  #get angles etc.
    }
    
    #multiply slope times distance =difference between points
    if(!is.null(ncol(angledJumps)))
    {
      mea <- colMeans(angledJumps)
      mean.an <-cumsum(mea) #.an are for calculating test limits; only changes are relevant
    }else{
      mea <- angledJumps
      mean.an <- cumsum(mea) #.an are for calculating test limits; only changes are relevant
    }
    
    error <- 0
    if(dim(cluster)[1]!=1){
      sd.an <- sqrt(gb_cumdepvar(angledJumps,error))
      sd.an[is.nan(sd.an)] <- 0 #set nan to zero; nan produced by sd too small
    } else{ #if only one group member, impose variance from whole sample
      anC<-gbAngles(C)
      sd.an <- sqrt(gb_cumdepvar(anC%*%diag(jumps),error))
      sd.an[is.nan(sd.an)] <- 0 #set nan to zero; nan produced by sd too small
    }
    SD$means.an <- rbind(SD$means.an,mean.an)
    
    SD$sds.an <- rbind(SD$sds.an,sd.an)
    SD$pro <- cbind(SD$pro,nrow(cluster)/nrow(C))
  }

  colnames(SD$means.an) <- times[-1]
  colnames(SD$sds.an) <- times[-1]
  
  return(SD)
}


calculateNewGbLimits<-function(SD,C,currentLimit)
{
  
  times<-as.integer(colnames(C))  #Katia
  #calculate new limits
  meanu <- currentLimit$max-SD$means.an
  meanl <- currentLimit$min-SD$means.an
  
  result_upper_limit <- currentLimit$max
  result_lower_limit <- currentLimit$min
  q <- 1/1000000 
  
  for (i in 1:(length(times)-1)){
    ru <- 1
    rl <- 1
    
    iter <- 0
    while (iter<100){ #if calc doesn't work:
      tmp_lower_limit <- KScorrect::qmixnorm(
        1-q,
        mean=meanl[,i],
        sd=SD$sds.an[,i],
        pro=SD$pro,
        expand=1*rl
        )
      if(!is.na(tmp_lower_limit)){#set to okay  
        break
      } else{ #if error, 
        rl <- rl*7/8 #change expand param in .025 steps
      } #repeat till it works
      iter <- iter+1
    }
    
    
    if(is.na(tmp_lower_limit)){
      return(NULL)
      #if it did not converge (iter==100)
    } 
    if(tmp_lower_limit>result_lower_limit){
      result_lower_limit <- tmp_lower_limit
      #if calculated the limit is tighter, use that one
    }
    
    iter <- 0
    while (iter<100){
      tmp_upper_limit <- KScorrect::qmixnorm(
        q,
        mean=meanu[,i],
        sd=SD$sds.an[,i],
        pro=SD$pro,
        expand=1*ru
        )
      if(!is.na(tmp_upper_limit)){
        break
      } else {
        ru <- ru*7/8 #change expand param in .025 steps
      }
      iter <- iter+1
    }
    if(is.na(tmp_upper_limit)) { 
      #if it did not converge (iter==100)
      return(NULL)
    } 
    if(tmp_upper_limit<result_upper_limit){
      #if calculated the limit is tighter, use that one
      result_upper_limit <- tmp_upper_limit
    }
  }
  
  #currentLimit
  if(!is.null(currentLimit$limit_type)){
    currentLimit$limit_type <- paste0(currentLimit$limit_type,"_guardbanded")
    currentLimit$limit_type <- gsub("^_", "", currentLimit$limit_type)
  } else {
    currentLimit$limit_type <- "guardbanded"
  }
  currentLimit$min <- result_lower_limit
  currentLimit$lower_limit <- result_lower_limit
  currentLimit$max <- result_upper_limit
  currentLimit$upper_limit <- result_upper_limit
  return(currentLimit)
}

gbAngles <- function(C)
{ #gets angles from point X_t^i to the point X_t+1^i
  differences <- function(C){
    X <- C[,2:ncol(C),drop=FALSE]-C[,1:(ncol(C)-1),drop=FALSE]
    return(X)
  }
  if(dim(C)[1]!=1){
    B <- C
    B[is.na(B)] <- 0 #set nas to 0 for calculation
    #wenns kein vektor ist:
    A <- differences(B) #get  differences of X_t, X_t+1
    b <- as.integer(colnames(A)) #get times as colnames
    d <- c(b[1],diff(b)) #calculate timejumps, add first "jump" 
    for (i in 1:nrow(A))
    {
      A[i,] <- A[i,]/d #divide differences by timejumps
    }
    A[is.na(C[,-1])] <- NA  
    return(A)
  }
  else{
    A <- differences(C) #get  differences of X_t, X_t+1
    b <- as.integer(colnames(A)) #get times as colnames
    d <- c(b[1],diff(b)) #calculate timejumps, add first "jump" 
    return(A/d)
  }
}

correctForTesterOffset<-function(dataMatrix,vgtMatrix)
{
  if(is.null(vgtMatrix)){
    vgtMatrix <- data.frame()
  }
  if (nrow(vgtMatrix)<1) {
    C<-dataMatrix
  } else {
    if(ncol(dataMatrix)==ncol(vgtMatrix)) {
      baseline<-robustbase::colMedians(vgtMatrix, na.rm=TRUE, hasNA=TRUE) #baseline of unstressed parts (can you do it like that?) / possibly rather median or something
      baseline<-baseline-baseline[1] #center the baseline to only view differences to start
      C<-dataMatrix #generate output matrix
      
      for (i in 1:nrow(C)){#forall rows
        C[i,]=C[i,]-baseline #subtract the baseline behaviour of unstressed units
      }
    } else {
      C<-dataMatrix
    }
  }
  if(length(unique(as.vector(C)))<5) 
  {
    stop("Data is discrete (less than 5 unique values). Guardbanding is not possible for this data set")
  }
  C <- na.omit(C)#get rid of na
  return(C)
}

#===============================================================================================
#' This function transforms the tembo data format to 
#' matrices of the test data and the vgt data.
#' 
#' 
#' The function uses the tembo data format as input.
#' Make sure you have at least loaded test_insertion.
#' Also chip_id and cond_tambient can be necessary to
#' make sure, your data is transformed correctly
#' 
#' transformDataToGbMatrix(dat, "OSC_")
#' vgtMatrix <- tmp[[1]]
#' testMatrix <- tmp[[2]]
#' 
#' @author Helena Schmidt, \email{schmidt.external9@infineon.com}
#' @export
transformDataToGbMatrix <- function(dat, param){
  # filter data for vgt and non-vgt
  if(!"stress_type" %in% colnames(dat)){
    if("test_insertion" %in% colnames(dat)) {
      dat <- dat %>% dplyr::rename(stress_type=test_insertion)
    } else{
      stop("Make sure to load stress_type metadata when using this function")
    }
  }
  vgt <- subset(dat, grepl("VGT$", stress_type))
  tmp_dat <- subset(dat, !grepl("VGT$", stress_type))
  # convert test_insertion to time values:
  tmp_dat$stress_type <- gsub("INITIAL", "0",tmp_dat$stress_type)
  tmp_dat$tmp_time <- as.numeric(gsub("[^0-9]","",tmp_dat$stress_type))
  timevar <- "tmp_time"
  
  wideDat <- tmp_dat %>%
    dplyr::select(-stress_type) %>%
    tidyr::pivot_wider(
      names_from = timevar,
      names_sort = TRUE,
      values_from = param,
      values_fn = first
    )
  
  times <- which(colnames(wideDat) %in% as.character(unique(tmp_dat$tmp_time)))
  myMatrix <- as.matrix(wideDat[,times])
  
  if(nrow(vgt) > 0){
    # convert stress_type to time values:
    vgt$stress_type <- gsub("INITIAL_VGT", "0",vgt$stress_type)
    vgt$tmp_time <- as.numeric(gsub("[^0-9]","",vgt$stress_type))
    wideVGT <- vgt %>%
      dplyr::select(-stress_type) %>%
      tidyr::pivot_wider(
        names_from = timevar,
        names_sort = TRUE,
        values_from = param,
        values_fn = first
      )
    times <- which(colnames(wideVGT) %in% as.character(unique(vgt$tmp_time)))
    vgtMatrix <- as.matrix(wideVGT[,times])
    vgtMatrix <- na.omit(vgtMatrix) # NAs in vgt means most likely the loaded vgt data is faulty
  } else {
    vgtMatrix <- as.matrix(data.frame())
  }
  return(list(vgtMatrix,myMatrix))
}


#===============================================================================================
#' This function calculates outlier int he VGT data,
#' outlier in VGT data can result in wrong guard bands
#' based on the Code provided by 
#' Lukas Sommeregger (IFAT DC ATV CQS ACM) <Lukas.Sommeregger@infineon.com>
#' 
#' The function uses the tembo data format as input
#'
#' @author Helena Schmidt, \email{schmidt.external9@infineon.com}
#' @export
findVgtOutlier <- function(dat, param)
{
  # only one limit is needed as reference
  tmp <- transformDataToGbMatrix(dat, param)
  vgtMatrix <- tmp[[1]]
  outlierVGT=c()
    #VGT outlier detection, WIP
    anVgt=gbAngles(vgtMatrix)
    for(i in 1:ncol(anVgt)){ #check all slopes (at all times)
      
      #if one part has different behaviour than others in one slope, it is considered an outlier.
      #.96 and .04 are sensitivity parameters: more decimals means more severe outliers
      # should be symmetric, i.e. sum to 1.
      ul=qnorm(.96,mean = (gbAngles(vgtMatrix)[,i]),sd(gbAngles(vgtMatrix)[,i])) #get slopes which differ from others by 96%
      ll=qnorm(.04,mean(gbAngles(vgtMatrix)[,i]),sd(gbAngles(vgtMatrix)[,i]))
      
      #rows where we have unusual (outlier) behaviour in slopes:
      outlierNew <- which(anVgt[,i]>ul|anVgt[,i]<ll,arr.ind = TRUE)
      outlierVGT<-c(outlierVGT,outlierNew)
    }
    outlierVGT <- unique(outlierVGT)
    return(outlierVGT)
}
