#' Identify traces
#'
#'
#' \emph{Copyright (c) 2019 Infineon Technologies}
#' @return Returns a ggplot2 graph object
#' @examples
#' ### create a tembo plot object:
#' identifyTraces(200,300,currentTemboPlot)
#' @family tembo plots
#' @author Helena Schmidt \email{schmidt.externel9@@infineon.com}
#' @export identifyTraces
identifyTraces <- function(x,y,temboPlotObject,pixelD=30){
  if(temboPlotObject$plotType %in% c("matrixplot", "spiderchart", "boxplot", "histogram", "wafermap", "xyplot-boxplot-overlay")){
    return("Traces not applicable")
  } else if(temboPlotObject$plotType=="waveplot") {
    #calculate traces of waveform directly from data
    axisValues <- temboPlotObject$convertPixelToAxis(x-pixelD/2,y-pixelD/2,pixelD,pixelD, xml=FALSE)
    myData <- subset(temboPlotObject$.plotData, facet==axisValues$facetNo)
    myData <- subset(myData, y >= axisValues$ymin & y <= axisValues$ymax &
                       t >= axisValues$xmin & t <= axisValues$xmax)
    if(nrow(myData)> 0){
      return(unique(myData$Signals))
    }
    return("")
  } else if(temboPlotObject$plotType=="cumulative_freq") {
    myTraces <- data.frame()
    for(i in split(temboPlotObject$.plotData,
                   temboPlotObject$.plotData$groups)){
      if(nrow(i) < 1){
        next
      }
      ecdf_result <- ecdf_ifx(data.frame(x=i[[temboPlotObject$.internalMapping$x]]))
      myX <- temboPlotObject$convertXToPixel(ecdf_result$x)
      myY <- temboPlotObject$convertYToPixel(ecdf_result$y)
      distances <- sqrt((x - myX)^2 + (y - myY)^2)
      nearest_point <- which.min(distances)
      yout <- approx(myX,myY, xout = x, ties = "ordered")
      new_distance <- abs(y - yout$y)
      if((!is.na(new_distance)) & new_distance < distances[nearest_point]){
        myTraces <- rbind(myTraces,
                          data.frame(distance=new_distance,
                                     name = unique(i$groups)
                          ))
      } else {
        myTraces <- rbind(myTraces,
                          data.frame(distance=distances[nearest_point],
                                     name = unique(i$groups)
                          ))
      }
    }
    limits <- temboPlotObject$.internalMapping$tmpLimits
    myTraces <- rbind(myTraces,
                      data.frame(distance = abs(x - temboPlotObject$convertXToPixel(limits$limitValue)),
                                 name = limits$limitColShow
    ))
    
    myTraces <- subset(myTraces, distance < pixelD/2)
    if(nrow(myTraces)==0){
      return(c())
    } else {
      return(as.character(myTraces$name[order(myTraces$dist)]))
    }

  }
  if(is.null(temboPlotObject$.internalMapping$tracesGenerationProcess) & is.null(temboPlotObject$.internalMapping$tracesTmpFiles)){
    return(c("Traces not applicable"))
  }
  if(is.null(temboPlotObject$.internalMapping$tracesTmpFiles)) {
    #temboPlotObject$.internalMapping$tracesGenerationProcess$wait(timeout=10)
    files <- c()
    returnMessage <- ""
    tryCatch({
      rp <<- temboPlotObject$.internalMapping$tracesGenerationProcess
      files <- rp$get_result()
    },
      error = function(e){
        if(grepl(": Still alive", paste(e))){
          returnMessage <<- c("Traces are not yet calculated")
        } else {
          returnMessage <<- c(paste("An error occured during traces identification:",paste(e)))
        }
      }
    )
    if(returnMessage!=""){
      return(returnMessage)
    }
    temboPlotObject$.internalMapping$tracesTmpFiles <- files
  } else {
    files <- temboPlotObject$.internalMapping$tracesTmpFiles
  }
  if(files[1] == "Traces not applicable"){
    return(files[1])
  }
  dists <- sapply(files, function(tmp) getDistanceOfTrace(x,y,tmp))
  tmpVec <- temboPlotObject$.internalMapping$tmpVec
  if(is.null(tmpVec)){
    if(!is.null(temboPlotObject$.internalMapping$colourMapping)){
      tmpVec <- list(names = names(temboPlotObject$.internalMapping$colourMapping),
                     colours = unname(temboPlotObject$.internalMapping$colourMapping))
      tmpVec$printNames <- tmpVec$names
    } else {
      return(c("Traces not applicable"))
    }
  }
  myDf <- data.frame(dist=as.vector(dists)[1:length(tmpVec$names)], name=tmpVec$printNames, stringsAsFactors = FALSE)
  myTraces <- subset(myDf, dist < Inf)
  if(nrow(myTraces)==0){
    return(c())
  } else {
    return(myTraces$name[order(myTraces$dist)])
  }
}


getDistanceOfTrace <- function(x,y,pngfile, pixelD =30){
  x <- round(x)
  y <- round(y)
  #print(pngfile)
  png <- png::readPNG(pngfile)
  pixels <- (-round(pixelD/2):round(pixelD/2))
  if(x+max(pixels) > ncol(png)){
    x <- x-max(pixels)
  }
  if(y+max(pixels) > nrow(png)){
    y <- y-max(pixels)
  }
  if(x+min(pixels) <= 0){
    x <- x-min(pixels) + 1
  }
  if(y+min(pixels) <= 0){
    y <- y-min(pixels) + 1
  }
  returnValues <- c(Inf, Inf, Inf)
  for(i in 1:3){
    px <- which(png[y+pixels,x+pixels,i]!=1) 
    if(length(px)>0){
      xs <- px %% length(pixels) - round(pixelD/2)
      ys <- round(px / length(pixels)) - round(pixelD/2)
      returnValues[i] <- min(sqrt(xs^2+ys^2))
    }
  }
  return(returnValues)
}

#' Create Trace Images
#'
#'
#' \emph{Copyright (c) 2019 Infineon Technologies}
#' @return list of image files
#' @examples
#' ### create a tembo plot object:
#' createTraceImages(currentTemboPlot)
#' @family tembo plots
#' @author Helena Schmidt \email{schmidt.externel9@@infineon.com}
#' @export createTraceImages
createTraceImages <- function(myPlot, tmpFolder) {
  #myPlot <- temboPlotObject$copy()
  myPlot$addToPlot(ggplot2::theme(panel.background = ggplot2::element_blank()))
  tmpVec <- myPlot$.internalMapping$tmpVec
  if(is.null(tmpVec)){
    if(!is.null(myPlot$.internalMapping$colourMapping)){
      tmpVec <- list(names = names(myPlot$.internalMapping$colourMapping),
                     colours = unname(myPlot$.internalMapping$colourMapping))
      tmpVec$printNames <- tmpVec$names
    } else {
      return(c("Traces not applicable"))
    }
  }
  files <- c()
  for(i in 1:ceiling(length(tmpVec$names)/3)){
    tmpVec$colours <- rep("#FFFFFF00",length(tmpVec$names))
    tmpVec$colours[3*i-2] <- "#00FFFF33"
    if(length(tmpVec$colours)>=(3*i-1)){
      tmpVec$colours[3*i-1] <- "#FF00FF33"
    }
    if(length(tmpVec$colours)>=(3*i)){
      tmpVec$colours[3*i] <- "#FFFF0033"
    }
    colourNamedList <- setNames( as.character(tmpVec$colours), as.character(tmpVec$names))
    myPlot$addToPlot(ggplot2::scale_colour_manual(name = myPlot$.internalMapping$grouping,
                                                  values = colourNamedList,
                                                  breaks = tmpVec$names,
                                                  labels = tmpVec$printNames))
    for(layer_i in 1:length(myPlot$plot[[1]]$layers)){
      # this may also be a good ansatz to colour different traces in other plots
      #print(class(myPlot$plot[[1]]$layers[[layer_i]]$geom))
      if(any(c("GeomLabel", "GeomSegment", "GeomAbline") %in% class(myPlot$plot[[1]]$layers[[layer_i]]$geom))){
        myPlot$plot[[1]]$layers[[layer_i]]$aes_params$colour <- "#FFFFFF00"
      }
    }
    myPlot$show(showOnJupyter=FALSE)
    filename <- tempfile(tmpdir=tmpFolder, fileext=".png")
    file.copy(myPlot$.filename, filename)
    files <- c(files, filename)
  }
  files
}
