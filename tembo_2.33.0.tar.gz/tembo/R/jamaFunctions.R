############################################################################################
#' Fetch single Jama data-item
#' with consideration of the specified baseline ID
#' 
#' \emph{Copyright (c) 2020 Infineon Technologies}
#' @author Thomas Michenthaler (IFAT DC ATV PTP MSF PDM VER), \email{thomas.michenthaler@infineon.com}
#' @export
getJamaItem <- function(itemId, baselineId=NA) {
  if (is.na(baselineId) || baselineId == "") {
    response<-httr::GET(paste0("https://rqmprod.intra.infineon.com/rest/latest/items/", itemId),
                        httr::config(ssl_verifypeer=0L),
                        httr::authenticate(Sys.info()["user"], tembo::getPassword()),
                        httr::add_headers(Accept="application/json"))
  } else {
    response<-httr::GET(paste0("https://rqmprod.intra.infineon.com/rest/latest/baselines/", baselineId, "/versioneditems/", itemId),
                        httr::config(ssl_verifypeer=0L),
                        httr::authenticate(Sys.info()["user"], tembo::getPassword()),
                        httr::add_headers(Accept="application/json"))
  }
  
  # Check for errors 
  if (httr::http_error(response)) { stop(httr::http_status(response)$message) }
  
  return(httr::content(response)$data)
}

############################################################################################
#' Fetch Jama version number of the specified item ID
#' with consideration of the specified baseline ID
#' 
#' \emph{Copyright (c) 2020 Infineon Technologies}
#' @author Thomas Michenthaler (IFAT DC ATV PTP MSF PDM VER), \email{thomas.michenthaler@infineon.com}
#' @export
getJamaItemVersion<- function(itemId, baselineId=NA) {
  if (is.na(baselineId) || baselineId == "") {
    return(getJamaBulkItems(paste0("https://rqmprod.intra.infineon.com/rest/latest/items/", itemId, "/versions"))[[1]]$versionNumber)
  } else {
    return(getJamaItem(itemId, baselineId)$version)
  }
}

############################################################################################
#' Fetch all Jama child data-items of the specified item ID
#' with consideration of the specified baseline ID.
#' If 'recursive' is set to 'TRUE', the function will provide all child items recursively
#' 
#' \emph{Copyright (c) 2020 Infineon Technologies}
#' @author Thomas Michenthaler (IFAT DC ATV PTP MSF PDM VER), \email{thomas.michenthaler@infineon.com}
#' @export
getJamaChildren <- function(itemId, baselineId=NA, recursive=FALSE) {
  
  if (is.na(baselineId) || baselineId == "") {
    if (recursive) {
      containerItem<-getJamaItem(itemId)
      sequenceNo<-containerItem$location$sequence
      allItems<-getJamaBulkItems(paste0("https://rqmprod.intra.infineon.com/rest/latest/abstractitems?project=", containerItem$project, "&contains=%22sequence%3A", sequenceNo, "%22"))
      
      return(allItems[sapply(allItems, function(x) !is.null(x$location) && startsWith(x$location$sequence, sequenceNo))])
    } else {
      return(getJamaBulkItems(paste0("https://rqmprod.intra.infineon.com/rest/latest/items/", itemId, "/children")))
    }
  } else {
    allChildData<-getJamaBulkItems(paste0("https://rqmprod.intra.infineon.com/rest/latest/baselines/", baselineId, "/versioneditems"))
    
    if (recursive) {
      return(allChildData)
    } else {
      return(allChildData[unlist(sapply(allChildData, function(x) x$baselineLocation$parent$item == itemId))])
    }
  }
}

############################################################################################
#' Fetch all upstream-related Jama data-items of the specified item ID
#' with consideration of the specified baseline ID
#' 
#' \emph{Copyright (c) 2020 Infineon Technologies}
#' @author Thomas Michenthaler (IFAT DC ATV PTP MSF PDM VER), \email{thomas.michenthaler@infineon.com}
#' @export
getJamaUpstreamrelatedItems <- function(itemId, baselineId=NA) {
  if (is.na(baselineId) || baselineId == "") {
    return(getJamaBulkItems(paste0("https://rqmprod.intra.infineon.com/rest/latest/items/", itemId, "/upstreamrelated")))
  } else {
    return(getJamaBaselinerelatedItems(itemId, baselineId, 15))
  }
}

############################################################################################
#' Fetch all downstream-related Jama data-items of the specified item ID
#' with consideration of the specified baseline ID
#' 
#' \emph{Copyright (c) 2020 Infineon Technologies}
#' @author Thomas Michenthaler (IFAT DC ATV PTP MSF PDM VER), \email{thomas.michenthaler@infineon.com}
#' @export
getJamaDownstreamrelatedItems <- function(itemId, baselineId=NA) {
  if (is.na(baselineId) || baselineId == "") {
    return(getJamaBulkItems(paste0("https://rqmprod.intra.infineon.com/rest/latest/items/", itemId, "/downstreamrelated")))
  } else {
    return(getJamaBaselinerelatedItems(itemId, baselineId, 13))
  }
}

############################################################################################
#' Fetch all Jama data-items in bulks of max. 50 items, using the specified URL
#' 
#' \emph{Copyright (c) 2020 Infineon Technologies}
#' @author Thomas Michenthaler (IFAT DC ATV PTP MSF PDM VER), \email{thomas.michenthaler@infineon.com}
#' @export
getJamaBulkItems <- function(requestUrl, content="data") {
  startAt<-0
  maxResults<-50
  resultData<-c()
  sep<-ifelse(grepl("\\?", requestUrl), "&", "?")
  
  repeat {
    response<-httr::GET(paste0(requestUrl, sep, "startAt=", startAt, "&maxResults=", maxResults),
                        httr::config(ssl_verifypeer=0L),
                        httr::authenticate(Sys.info()["user"], tembo::getPassword()),
                        httr::add_headers(Accept="application/json"))
    
    # Check for errors
    if (httr::http_error(response)) { stop(httr::http_status(response)$message) }
    
    # concatenate result content
    result <- httr::content(response)
    resultData<-c(resultData, result[[content]])
    
    if (startAt + result$meta$pageInfo$resultCount >= result$meta$pageInfo$totalResults) { break }
    
    startAt<-startAt + maxResults
  }
  
  return(resultData)
}

############################################################################################
#' Fetch all versioned relationship Jama items of the specified item- and baseline ID
#' depending on the specified relationship type (15:=upstream, 13:=downstream)
#' 
#' \emph{Copyright (c) 2020 Infineon Technologies}
#' @author Thomas Michenthaler (IFAT DC ATV PTP MSF PDM VER), \email{thomas.michenthaler@infineon.com}
#' @export
getJamaBaselinerelatedItems <- function(itemId, baselineId, relationshipType) {
  if (relationshipType == 15) {
    versionedItems<-getJamaBulkItems(paste0("https://rqmprod.intra.infineon.com/rest/latest/baselines/", baselineId, "/versioneditems/", itemId, "/versionedrelationships?include=data.fromItem"), content="linked")$version
  } else if (relationshipType == 13) {
    versionedItems<-getJamaBulkItems(paste0("https://rqmprod.intra.infineon.com/rest/latest/baselines/", baselineId, "/versioneditems/", itemId, "/versionedrelationships?include=data.toItem"), content="linked")$version
  }
  
  # get data of related items
  resultData<-list()
  for(relatedVersion in versionedItems[unlist(sapply(versionedItems, function(x) x[[1]]$versionedItem[[1]] != itemId))]) {
    tryCatch({
      resultData<-c(resultData, list(getJamaItem(relatedVersion[[1]]$versionedItem[[1]], baselineId)))
    }, error=function(e) {
      # MK 20-08-07: Jama API's versioneditems returns also items, which are not part of the baseline. 
      # This leads to 404 errors, when this items are fetched in the context of the baseline
      # In order not to stop item fetching this errors are ignorred
      # https://jiradc.intra.infineon.com/browse/TEMBO-8032
      #stop(paste0(e$message, " ==> ID:", relatedVersion[[1]]$versionedItem[[1]], "\n"))
    })
  }
  
  # return only data of current relationship type
  return(resultData)
}