#' List installed R packages
#'
#' Lists the installed R packages and its Verisons
#'
#' \emph{Copyright (c) 2021 Infineon Technologies} 
#' @param pattern Regex to filter the packages names
#' @examples 
#' tembo::listRPackages(pattern="gg") # list packages with a name containing gg
#' tembo::listRPackages() #List all installed packages
#' @author Helena Schmidt, \email{schmidt.external9@@infineon.com}
#' @export
listRPackages <- function(pattern=NULL) {
  packages <- as.data.frame(installed.packages()[ , c(1, 3:4)])
  packages <- packages[is.na(packages$Priority), 1:2, drop = FALSE]
  rownames(packages) <- NULL
  if(!is.null(pattern)) {
    packages <- packages %>% dplyr::filter(grepl(pattern,Package))
  }
  return(packages)
}

