############################################################################################
#' Eff class
#' 
#' \emph{Copyright (c) 2019 Infineon Technologies}
#' @export eff
#' @export eff.read
#' @exportClass eff 

#Author: T. Bucksch (thorsten.bucksch@infineon.com)
#Author: K. Giarda  (katia.giarda@infineon.com)
eff <- setClass(
  # Set the name for the class
  "eff",
  
  # Define the slots
  slots = c(
    filename="character",
    data = "list",
    tab = "list",
    lsl = "character",
    usl = "character",
    tnr = "character",
    tnam = "character",
    unit = "character",
    agg = "character",
    lslstr = "character",
    uslstr = "character",
    tnrstr = "character",
    tnamstr = "character",
    aggstr ="character",
    unitstr = "character",
    skipstr = "character",
    colnames = "character",
    EnumHeader= "list"
  )
  
)
## define the constructor
## Note that we don't give an argument to the ctor
## to init the private field
setMethod (
  "initialize",
## setup of signatures for the different eff & tsf file types
    signature  = "eff",
  definition = function (.Object) {
    .Object@lslstr <- "<LIMIT:SPEC:LOWER_VALUE>"
    .Object@uslstr <- "<LIMIT:SPEC:UPPER_VALUE>"
    .Object@tnrstr <- "<+ParameterNumber>"
    .Object@tnamstr <- "<+ParameterName>"
    .Object@aggstr <- ""
    .Object@skipstr = "05_Die"
    .Object@unitstr = "<PARATTR:UNIT>"
    
    .Object@EnumHeader=list(
      EFF = data.frame(
        lslstr = "<LIMIT:SPEC:LOWER_VALUE>",
        uslstr = "<LIMIT:SPEC:UPPER_VALUE>",
        tnrstr = "<+ParameterNumber>",
        tnamstr = "<+ParameterName>",
        aggstr = "",
        skipstr = "05_Die",
        unitstr = "<PARATTR:UNIT>",
        stringsAsFactors=FALSE),
      EFFTOSTAT = data.frame(
        lslstr = "<LSL>",
        uslstr = "<USL>",
        tnrstr = "<+EFF:1.00>",
        tnamstr = "<+PName>",
        aggstr = "",
        skipstr = "05_Die",
        unitstr = "<Unit>",
        stringsAsFactors=FALSE),
      
      EFFLot = data.frame(
        lslstr = "<LIMIT:SPEC:LOWER_VALUE>",
        uslstr = "<LIMIT:SPEC:UPPER_VALUE>",
        tnrstr = "<+ParameterNumber>",
        tnamstr = "<+ParameterName>",
        aggstr = "<+AggregateType>",
        skipstr = "20_Lot",
        unitstr = "<PARATTR:UNIT>",
        stringsAsFactors=FALSE),
      
      TSF = data.frame(
        lslstr = "%LSL",
        uslstr = "%HSL",
        tnrstr = "%TestNr",
        tnamstr = "%TestName",
        aggstr = "",
        skipstr = " ;",
        unitstr = "%Unit",
        stringsAsFactors=FALSE)
     
    )
    
    return (.Object)
  }
)


setGeneric(
  name = "eff.read",
  def = function(theObject, filename, mergetnum, withtnr)
  {
    standardGeneric("eff.read")
  }
)
setMethod(
  f = "eff.read",
  signature = "eff",
  definition = function(theObject,
                        filename,
                        mergetnum = TRUE,
                        withtnr = TRUE)
  {
# switch off warnings
    options(datatable.fread.input.cmd.message=FALSE)
    if (missing(withtnr)) withtnr = T
    if (missing(mergetnum)) mergetnum = T
# Check file existing    
    if (file.exists(filename)) {
      theObject@filename = filename
# in case of a zipped file the unzip command is piped into the filename      
      if (tools::file_ext(filename)=="zip") {
        filename <- paste0("unzip -p ",filename)
      }
      theObject@filename = filename
# estimation of file type      
      filetype <- "unknown"
      tryCatch({
        res = try(as.character(
          fread(
            filename,
            header = FALSE,
            skip = "<+ParameterName>",
            nrows = 0,
            sep = ";",
            data.table = FALSE,
            verbose = FALSE,
            showProgress = FALSE,
            stringsAsFactors = F
          )
        ))
        if (class(res) != "try-error") filetype = "EFF"
      }, error = function(e) {
        mergetnum = F
      }, finally = cat("Reading \n "))
      tryCatch({
        res = try(as.character(
          fread(
            filename,
            header = FALSE,
            skip = "<+PName>",
            nrows = 0,
            sep = ";",
            data.table = FALSE,
            verbose = FALSE,
            showProgress = FALSE,
            stringsAsFactors = F
          )
        ))
        if (class(res) != "try-error") filetype = "EFFTOSTAT"
      }, error = function(e) {
        mergetnum = F
      }, finally = cat("Reading \n"))
      tryCatch({
        res = try(as.character(
          fread(
            filename,
            header = FALSE,
            skip = "%TestName",
            nrows = 0,
            sep = ";",
            data.table = FALSE,
            verbose = FALSE,
            showProgress = FALSE,
            stringsAsFactors = F
          )
        ))
        if (class(res) != "try-error") filetype = "TSF"
      }, error = function(e) {
        mergetnum = F
      }, finally = cat("Reading \n "))
      cat ("Filetype = ",filetype,"\n")
# end of file type estimation

# set signature based on the detected file type
      theObject <- eff.setHeaders(theObject,filetype)      
# read file header information
# read test name      
      tryCatch({
        theObject@tnam = try(as.character(
          fread(
            filename,
            header = FALSE,
            skip = theObject@tnamstr,
            nrows = 1,
            sep = ";",
            data.table = FALSE,
            verbose = FALSE,
            stringsAsFactors = F
          )
        ))
      }, error = function(e) {
        theObject@tnam = NULL
        mergetnum = F
      }, finally = cat("Reading "))
# read test number
      
      tryCatch({
        theObject@tnr = try(as.character(
          fread(
            filename,
            header = FALSE,
            skip = theObject@tnrstr,
            nrows = 1,
            sep = ";",
            data.table = FALSE,
            verbose = FALSE,
            stringsAsFactors = F
          ))

         
        )
        
      }, error = function(e) {
        theObject@tnr = NULL
        mergetnum = F
      }, finally = cat("TNR "))
# read aggregation
      
      if (nchar(theObject@aggstr)>2) {
        
        tryCatch({
          theObject@agg = try(as.character(
            fread(
              filename,
              header = FALSE,
              skip = theObject@aggstr,
              nrows = 1,
              sep = ";",
              data.table = FALSE,
              verbose = FALSE,
              stringsAsFactors = F
            )
          ))
          theObject@tnr=paste0(theObject@tnr, "_",theObject@agg)
        }, error = function(e) {
          theObject@agg = ""
          mergetnum = F
        }, finally = cat(" "))
      } else {
        theObject@agg = ""
      }
# read lower limit      
      tryCatch({
        theObject@lsl = try(as.character(
          fread(
            filename,
            header = FALSE,
            skip = theObject@lslstr,
            nrows = 1,
            sep = ";",
            data.table = FALSE,
            verbose = FALSE,
            stringsAsFactors = F
          )
        ))
      },
      error = function(e) {
        theObject@lsl = NULL
      }, finally = cat(" "))
#read uppler limit
      tryCatch({
        theObject@usl = try(as.character(
          fread(
            filename,
            header = FALSE,
            skip = theObject@uslstr,
            nrows = 1,
            sep = ";",
            data.table = FALSE,
            verbose = FALSE,
            stringsAsFactors = F
          )
        ))
      }, error = function(e) {
        theObject@usl = NULL
      }, finally =  cat("USL "))
# read unit
      tryCatch({
        theObject@unit = try(as.character(
          fread(
            filename,
            header = FALSE,
            skip = theObject@unitstr,
            nrows = 1,
            sep = ";",
            data.table = FALSE,
            verbose = FALSE,
            stringsAsFactors = F
          )
        ))
      }, error = function(e) {
        theObject@usl = NULL
      }, finally =  cat("Unit "))
      if (class(theObject@colnames) == "try-error")
        # checks if read was successful
      {
        cat("\n SKIP FILE: header not found. \n")								# Error Message
        next																	# skips loop for this file
      }
# read file payload       
      tryCatch({
        theObject@data = try(fread(
          filename,
          header = FALSE,
          skip = theObject@skipstr,
          sep = ";",
          data.table = FALSE,
          verbose = FALSE,
          stringsAsFactors = F
        ))
      }, error = function(e) {
        theObject@tnr = NULL
        mergetnum = F
        cat("Cannot read ", filename, "\n")
      }, finally = cat(filename, "\n"))
      theObject@colnames<-theObject@tnam
      if (mergetnum) {
        theObject@colnames[(theObject@tnr!="NA")&(theObject@tnr!="*")]<-paste0(theObject@tnam[(theObject@tnr!="NA")&(theObject@tnr!="*")],
                                                                               "___",theObject@tnr[(theObject@tnr!="NA")&(theObject@tnr!="*")]) 
      }
      theObject@colnames[theObject@tnam=="NA"]<-theObject@tnr[theObject@tnam=="NA"] 
      names(theObject@data) <-
        toupper(theObject@colnames)														# define column headers
      
    } else {
      cat("Cannot find file ", filename, "\n")
    }
   
    if (!is.null(theObject@data)) {
      
       if (length(theObject@tnr) == 0) {
         theObject@tnr <- rep(0, length(names(theObject@data)))
      } else {
        theObject@tnr <-as.character(theObject@tnr)
      }
      
      if (length(theObject@tnam) == 0)
        theObject@tnam <- rep("", length(names(theObject@data)))
      
      if (length(theObject@lsl) == 0)
        theObject@lsl <- rep(0, length(names(theObject@data)))
     
      if (length(theObject@usl) == 0)
        theObject@usl <- rep(0, length(names(theObject@data)))
     
      cat("Read ",theObject@filename)
      cat(" / Count testnumbers:",length(theObject@tnr))
      cat(" testnames:",length(theObject@tnam))
      cat(" dim data:",dim(theObject@data))
      cat(" lsl:",length(theObject@lsl))
      cat(" usl:",length(theObject@usl))
      cat("\n")
      theObject@tab <-
        data.frame(
          tnr = theObject@tnr,
          tnam = theObject@tnam,
          colnam = names(theObject@data),
          lsl = theObject@lsl,
          usl = theObject@usl
        )
    }
    
    return(theObject)
  }
)
setGeneric(
  name = "eff.chipid",
  def = function(theObject, cols)
  {
    standardGeneric("eff.chipid")
  }
)
setMethod(
  f = "eff.chipid",
  signature = "eff",
  definition = function(theObject, cols) {
    theObject@data$chipid <-
      do.call(paste, c(theObject@data[cols], sep = "_"))
    return(theObject)
  }
)
setGeneric(
  name = "eff.chipidAuto",
  def = function(theObject)
  {
    standardGeneric("eff.chipidAuto")
  }
)
setMethod(
  f = "eff.chipidAuto",
  signature = "eff",
  definition = function(theObject) {
    colIdLot<-grep("Lot",theObject@tnam)
    colIdX<-grep("^X$",theObject@tnam,perl=T)
    colIdY<-grep("^Y$",theObject@tnam,perl=T)
    colIdWf<-grep("WAFERNR",theObject@tnam)
    theObject@data$chipid <-
      do.call(paste, c(theObject@data[c(colIdLot,colIdWf,colIdX,colIdY)], sep = "_"))
    return(theObject)
  }
)

setGeneric(
  name = "eff.chipidTE",
  def = function(theObject, cols)
  {
    standardGeneric("eff.chipidTE")
  }
)
setMethod(
  f = "eff.chipidTE",
  signature = "eff",
  definition = function(theObject, cols) {
    if (length(cols) != 4) {
      theObject@data$chipid <-
        do.call(paste, c(theObject@data[cols], sep = "_"))
    } else {
      theObject@data$chipid <-
        do.call(
          paste0,
          list(
            "LotID=",
            theObject@data[, cols[1]],
            ", WafNr=",
            theObject@data[, cols[2]],
            ", X=",
            theObject@data[, cols[3]],
            ", Y=",
            theObject@data[, cols[4]]
          )
        )
    }
    return(theObject)
  }
)

setGeneric(
  name = "eff.getHeadersType",
  def = function(theObject)
  {
    standardGeneric("eff.getHeadersType")
  }
)
setMethod(
  f = "eff.getHeadersType",
  signature = "eff",
  definition = function(theObject) {
   
    return(theObject@EnumHeader)
  }
)

setGeneric(
  name = "eff.setHeaders",
  def = function(theObject, enum)
  {
    standardGeneric("eff.setHeaders")
  }
)
setMethod(
  f = "eff.setHeaders",
  signature = "eff",
  definition = function(theObject, enum) {
    theObject@lslstr <- theObject@EnumHeader[[enum]]$lslstr
    theObject@uslstr <- theObject@EnumHeader[[enum]]$uslstr
    theObject@tnrstr <- theObject@EnumHeader[[enum]]$tnrstr
    theObject@tnamstr<- theObject@EnumHeader[[enum]]$tnamstr
    theObject@aggstr <- theObject@EnumHeader[[enum]]$aggstr
    theObject@skipstr<- theObject@EnumHeader[[enum]]$skipstr
    theObject@unitstr<- theObject@EnumHeader[[enum]]$unitstr
    return(theObject)
  }
)

setGeneric(
  name = "eff.setCustomHeaders",
  def = function(theObject, df)
  {
    standardGeneric("eff.setCustomHeaders")
  }
)
setMethod(
  f = "eff.setCustomHeaders",
  signature = "eff",
  definition = function(theObject,df) {
    theObject@lslstr <- df$lslstr
    theObject@uslstr <- df$uslstr
    theObject@tnrstr <- df$tnrstr
    theObject@tnamstr <- df$tnamstr
    theObject@skipstr <- df$skipstr
    theObject@unitstr <- df$unitstr
    return(theObject)
  }
)

setGeneric(
  name = "eff.getData",
  def = function(theObject, TN_Tnr)
  {
    standardGeneric("eff.getData")
  }
)
setMethod(
  f = "eff.getData",
  signature = "eff",
  definition = function(theObject,TN_Tnr) {
    data<-NULL
    data$x=NULL
    data$col=-1
    colX=which(theObject@tnam==TN_Tnr)
    if (length(colX)==0)
    {
      colX=which(theObject@tnr==TN_Tnr)
      if (length(colX)==0)
      {
        cat(" Test not found! \n")
        return(data)
      }
      
    }
    x=theObject@data[,colX]
    data$x=x
    data$colX=colX
    return(data)
    
  }
)

setGeneric(
  name = "eff.getTestNameNumber",
  def = function(theObject, TN_Tnr)
  {
    standardGeneric("eff.getTestNameNumber")
  }
)
setMethod(
  f = "eff.getTestNameNumber",
  signature = "eff",
  definition = function(theObject,TN_Tnr) {
    x<-NULL
    colX=which(theObject@tnam==TN_Tnr)
    if (length(colX)==0)
    {
      colX=which(theObject@tnr==TN_Tnr)
      if (length(colX)==0)
      {
        cat(" Test not found! \n")
        
      }else{
        x=theObject@tnam[colX]
      }
      
    }else{
        x=theObject@tnr[colX]
    }
    
    return(x)
    
  }
)



setGeneric(
  name = "eff.ecdf",
  def = function(theObject, TN_Tnr, GrBy=NULL)
  {
    standardGeneric("eff.ecdf")
  }
)
setMethod(
  f = "eff.ecdf",
  signature = "eff",
  definition = function(theObject,TN_Tnr, GrBy=NULL) {
    colX=which(theObject@tnam==TN_Tnr)
    if (length(colX)==0)
    {
      colX=which(theObject@tnr==TN_Tnr)
      if (length(colX)==0)
      {
        cat(" Test not found! \n")
        return()
      }
      
    }
    if (!is.null(GrBy))
    {
      colGr=which(theObject@tnam==GrBy)
      GrBy<-theObject@data[,colGr]
    }else
    {
      GrBy<-rep(1, nrow(theObject@data))
    }
   
    df1<-data.frame(x=theObject@data[,colX], col=GrBy)
    #print(head(df1))
    df1<-df1[complete.cases(df1),]
    p=ggplot(data=df1,
             aes_string(x=colnames(df1)[1], 
                        colour=colnames(df1)[2])) +
      stat_ecdf(geom = "point") +
      scale_y_continuous(trans=scales::probability_trans("norm"),
                         breaks=c(0.000001,0.00001,0.001, 0.01, 0.1, 0.50, 0.9, 0.99, 0.999, 0.99999,0.999999))
    
    lsl<-as.numeric(theObject@lsl[colX])
    usl<-as.numeric(theObject@usl[colX])
    
 
    
    if (length(lsl)>0)
    {
      p=  p+ geom_vline(xintercept=lsl,colour="red",size=1) 
      
    }
    if (length(usl)>0)
    {
      p=  p+ geom_vline(xintercept=usl,colour="red",size=1)
    }
    return(p)
  }
)


setGeneric(
  name = "eff.cpk",
  def = function(theObject, TN_Tnr)
  {
    standardGeneric("eff.cpk")
  }
)
setMethod(
  f = "eff.cpk",
  signature = "eff",
  definition = function(theObject,TN_Tnr) {
    cpk1<-data.frame(name=TN_Tnr,mean=-1,sd=-1,q005=-1, q995=-1,lsl=-1,usl=-1,
                     oldCPK=-1,lpl=-1,upl=-1,newCPK=-1)
    data=eff.getData(theObject,TN_Tnr)
    if (is.null(data))
    {
      return(cpk1)
    }
    df1<-data.frame(x=data$x)
    #print(head(df1))
    #print(colnames(df1))
    df1<-df1[complete.cases(df1),]
    value<-na.omit(theObject@data[,data$colX])
    lsl<-as.numeric(theObject@lsl[data$colX])
    usl<-as.numeric(theObject@usl[data$colX])
    #print(lsl)
    #print(usl)
    if (length(lsl)>0)
    {
      if (length(usl)>0)
      {
        sd=sd(value)
#        print(sd)
        if(!is.na(sd))
        {
          q005=quantile(value, probs = 0.005)
          q50=quantile(value, probs = 0.50)
          q995=quantile(value, probs = 0.995)
          lpl=q50-6*(q50-q005)/2.575829
          upl=q50+6*(q995-q50)/2.575829
          
          cpk1<-data.frame(
            name=TN_Tnr,
            mean=q50,
            sd=sd,
            q005=q005,
            q995=q995,
            lsl=lsl,
            usl=usl,
            oldCPK=(usl-lsl)/(6*sd),
            lpl=lpl,
            upl=upl,
            newCPK=(upl-lpl)/(6*sd),
           
            
            yl=(1-ecdf(value)(upl))+ecdf(value)(lpl)
          )
        }
        
      }
      
    }
    
    return(cpk1)
  }
)


setGeneric(
  name = "eff.cpk2",
  def = function(theObject, TN_Tnr)
  {
    standardGeneric("eff.cpk2")
  }
)
setMethod(
  f = "eff.cpk2",
  signature = "eff",
  definition = function(theObject,TN_Tnr) {
    cpk1<-data.frame(name=TN_Tnr,mean=-1,sd=-1,q005=-1, q995=-1,lsl=-1,usl=-1,
                     oldCPK=-1,lpl=-1,upl=-1,newCPK=-1)
    data=eff.getData(theObject,TN_Tnr)
    if (is.null(data))
    {
      return(cpk1)
    }
    df1<-data.frame(x=data$x)
    #print(head(df1))
    #print(colnames(df1))
    df1<-df1[complete.cases(df1),]
    value<-na.omit(theObject@data[,data$colX])
    lsl<-as.numeric(theObject@lsl[data$colX])
    usl<-as.numeric(theObject@usl[data$colX])
    #print(lsl)
    #print(usl)
    if (length(lsl)>0)
    {
      if (length(usl)>0)
      {
        sd1=sd(value)
        #print(sd)
        if(!is.na(sd1))
        {
          q25=quantile(value, probs = 0.25)
          q50=quantile(value, probs = 0.50)
          q75=quantile(value, probs = 0.75)
          myqLow=q25-1.5*(q75-q25)
          myqHigh=q75+1.5*(q75-q25)
          value<-value[value>myqLow & value <  myqHigh]
          sd=sd(value)
#          print(hist(value))
          lpl=q50-6*sd
          upl=q50+6*sd
          
          cpk1<-data.frame(
            name=TN_Tnr,
            mean=q50,
            sd=sd,
            q25=q25,
            q75=q75,
            lsl=lsl,
            usl=usl,
            oldCPK=(usl-lsl)/(6*sd),
            lpl=lpl,
            upl=upl,
            newCPK=(upl-lpl)/(6*sd),

            yl=(1-ecdf(value)(upl))+ecdf(value)(lpl)
          )
        }
        
      }
      
    }
    
    return(cpk1)
  }
)



setGeneric(
  name = "eff.cpkList",
  def = function(theObject, TN_Tnr_vector=NULL,plot=F)
  {
    standardGeneric("eff.cpkList")
  }
)
setMethod(
  f = "eff.cpkList",
  signature = "eff",
  definition = function(theObject,TN_Tnr_vector=NULL,plot=F) {
    
    if(is.null(TN_Tnr_vector))
    {
      #get Onlx TNR not NA
      idx<- (!(theObject@tnr=="NA")) &   
        (apply(theObject@data,2,function(x){
            max(x,na.rm=TRUE)!=min(x,na.rm = T) 
        }))
      TN_Tnr_vector<- colnames(theObject@data)[which(idx==T)]
    }
    
    cpk<-NULL
    cpk<-sapply(TN_Tnr_vector,function(x)
    {
      eff.cpk(theObject,x)
    })
    cpk<-as.data.frame(t(cpk))
    
    return(cpk)
  }
)


setGeneric(
  name = "eff.DI",
  def = function(theObject, TN_Tnr,prob=0.95,path=NULL)
  {
    standardGeneric("eff.DI")
    #DEsign Index
  }
)
setMethod(
  f = "eff.DI",
  signature = "eff",
  definition = function(theObject,TN_Tnr,prob=0.95,path=NULL) {
    mydf<-data.frame(name=TN_Tnr,mean=-1,sd=-1,q05=-1, q95=-1,lsl=-1,usl=-1,
                     oldCPK=-1,lpl=-1,upl=-1,newCPK=-1)
    
   
    
    dataq50=eff.getData(theObject,paste(TN_Tnr,"_median",sep=""))
    dataq95=eff.getData(theObject,paste(TN_Tnr,"_q95",sep=""))
    dataq05=eff.getData(theObject,paste(TN_Tnr,"_q05",sep=""))
  
    dataN<-eff.getData(theObject,paste(TN_Tnr,"_base_count",sep=""))
    dataSigma<-eff.getData(theObject,paste(TN_Tnr,"_stdev",sep=""))
    
    lsl<-as.numeric(theObject@lsl[dataq50$colX])
    usl<-as.numeric(theObject@usl[dataq50$colX])
    tnam<-theObject@tnam[dataq50$colX]
    tnr<-theObject@tnr[dataq50$colX]
   
   
    v<-dataq05$x[!is.na(dataq05$x)]
    if (length(v)==0)
    {
      cat("Test Not found")
      return( mydf)
    }
    #
    A=quantile(dataq05$x, probs = (1-prob),na.rm = T)
    B=quantile(dataq95$x, probs = (prob), na.rm =   T)
    M= (A+B)/2
    #get the similar having quantile and B
    idWL<-which.min(abs(A - dataq05$x)) 
    idUL<-which.min(abs(B - dataq95$x)) 
    
    sigmaL=dataSigma$x[idWL]
    sigmaU=dataSigma$x[idUL]
    
    ICu<-qnorm(c(prob), mean = dataq50$x[idUL], sd = sigmaU, lower.tail = TRUE, log.p = FALSE)
    ICl<-qnorm(c(1-prob), mean = dataq50$x[idWL], sd = sigmaL, lower.tail = TRUE, log.p = FALSE)
    
    
    Wu=ICu + 3*sigmaU
    Wl=ICl - 3*sigmaL
    
    
    DI=2
    USL=M+DI*(Wu-M)
    LSL=M-DI*(M-Wl)
    
  
    
    mydf$mean=M
    mydf$sd=median(dataSigma$x)
    mydf$q05=median(dataq05$x)
    mydf$q95=median(dataq95$x)
    mydf$lsl=lsl
    mydf$usl=usl
    mydf$lpl=LSL
    mydf$upl=USL
    cpkU=(USL-M)/(3*sigmaU)
    cpkL=(M-LSL)/(3*sigmaL)
    mydf$newCPK=min(cpkU,cpkL)
    cpk=round(mydf$newCPK,2)
    
    
    if(!is.null(path))
    {
      cat(paste(path,"/",TN_Tnr,".png",sep=""))
      png(file=paste(path,"/",TN_Tnr,".png",sep=""))
      cat("\n")
    }
   
   
    #title=paste(c(TN_Tnr," CPK: ",cpk,".png"),sep="\n")
    p=eff.BoxPlot(theObject,TN_Tnr,max(USL[1],usl,na.rm = T),
                                   min(LSL[1],lsl,na.rm = T))
    
    abline(h=LSL[1],col="red")
    abline(h=USL[1],col="red")
    
    # abline(h=A,col="blue") 28.03.2019
    # abline(h=B,col="blue")
    # abline(h=M,col="blue")
    # 
    # abline(h=usl,col="green")
    # abline(h=Wl,col="green")
    
    abline(h=lsl,col="magenta")
    abline(h=usl,col="magenta")
    
    
    text(x=1, y = USL[1], paste(round(USL[1],2)), cex = 0.8, col = "black")
    text(x=1, y = LSL[1], paste(round(LSL[1],2)), cex = 0.8, col = "black")
    text(x=10, y = USL[1], paste("CPK:",cpk), cex = 0.8, col = "black")
    
    
    if(!is.null(path))
    {
      dev.off()
    }
 
    return(mydf)
  }
)



setGeneric(
  name = "eff.BoxPlot",
  def = function(theObject, TN_Tnr, UL=NULL,LL=NULL)
  {
    standardGeneric("eff.BoxPlot")
  }
)
setMethod(
  f = "eff.BoxPlot",
  signature = "eff",
  definition = function(theObject,TN_Tnr, UL=NULL,LL=NULL) {
    
    #boxplot(cbind(c(0,25,50,85,100),c(0,25,50,85,100)))
    
    #values<-c(paste(TN_Tnr,"min",sep="_"),paste(TN_Tnr,"q05",sep="_"),paste(TN_Tnr,"median",sep="_"),paste(TN_Tnr,"q95",sep="_"),paste(TN_Tnr,"max",sep="_"))
    #vTN<-paste(values,collapse="|")
    #vTN<-paste(c("^(",vTN,")$"),collapse="")
    #m<-regexpr(vTN,theObject@tnr,perl=T)
    #regmatches(theObject@tnr, m)
    #gregexpr(vTN,theObject@tnr,perl=T)
    cols<-c(paste(TN_Tnr,"min",sep="_"),paste(TN_Tnr,"q05",sep="_"),paste(TN_Tnr,"median",sep="_"),paste(TN_Tnr,"q95",sep="_"),paste(TN_Tnr,"max",sep="_"))
  
   
    df1<- cbind(theObject@data[,"LOT"],
                theObject@data[,theObject@tnr %in% cols])
    
    colnames(df1)<-c("LOT",cols)
    #utils::View(df1)
    
    df1<-as.data.frame(df1[complete.cases(df1),])
    df1<-t(df1)
    colnames(df1)<-df1[1,]
    df1<-df1[-c(1),]
    df1 <- apply(df1, 2, as.numeric)

    #utils::View(df1)
    if (!is.null(UL))
    {
      p=boxplot(as.data.frame(df1),ylim=c(LL,UL), main=TN_Tnr)
    }else
    {
      p=boxplot(as.data.frame(df1), main=TN_Tnr)
    }
    abline(h = LL, col = "red") 
    abline(h = UL, col = "red") 
    return(p)
  }
)

setGeneric(
  name = "eff.filter",
  def = function(theObject, colIndex)
  {
    standardGeneric("eff.filter")
  }
)
setMethod(
  f = "eff.filter",
  signature = "eff",
  definition = function(theObject, colIndex) {
      theObject@data<-theObject@data[,colIndex]
      theObject@lsl<-theObject@lsl[colIndex]
      theObject@usl<-theObject@usl[colIndex]
      theObject@tnr<-theObject@tnr[colIndex]
      theObject@tnam<-theObject@tnam[colIndex]
      theObject@unit<-theObject@init[colIndex]
      theObject@agg<-theObject@agg[colIndex]
    return(theObject)
  }
)


setGeneric(
  name = "eff.WfMap",
  def = function(theObject, testNameNum, WfNum)
  {
    standardGeneric("eff.WfMap")
  }
)
setMethod(
  f = "eff.WfMap",
  signature = "eff",
  definition = function(theObject, testNameNum, WfNum) {
    
    
    X<-eff.getData(theObject,"X")
    Y<-eff.getData(theObject,"Y")
    Wf<-eff.getData(theObject,"WAFERNR")
    data<-eff.getData(theObject,testNameNum)
    
    Allmaps<-data.frame(WF=Wf$x,X=X$x,Y=Y$x,V=data$x)
    Allmaps<-Allmaps[complete.cases(Allmaps),]
    
    Map<-Allmaps[Allmaps$WF==WfNum,c("X","Y","V")]
    if (nrow(Map)>2){
      Map<-Map[with(Map, order(X, Y)), ]
      lp<-levelplot(V ~ X + Y, data=Map)
      return(lp)
    }else
    {
      return(NULL)
    }

  }
)

setGeneric(
  name = "eff.NormCheck",
  def = function(theObject, testNameNum)
  {
    standardGeneric("eff.NormCheck")
  }
)
setMethod(
  f = "eff.NormCheck",
  signature = "eff",
  definition = function(theObject, testNameNum) {
    # if (sr.p >0.05 is normal)
    data<-eff.getData(theObject,testNameNum)
    data$x<-data$x[complete.cases(data$x)]
    if (length(data$x>2))
    {
      if (min(data$x)<max(data$x))
      {
        st<-shapiro.test(data$x)
        return(st)
      }
     
      
    }
    return(NULL)

  }
)
