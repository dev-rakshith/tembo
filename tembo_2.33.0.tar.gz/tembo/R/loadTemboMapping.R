############################################################################################
#' loadTemboMapping
#'
#' \emph{Copyright (c) 2021 Infineon Technologies}
#' @family data analysis engine
#' @author Thomas Michenthaler (IFAT DC ATV PTP TD VI), \email{thomas.michenthaler@@infineon.com}
#' @export loadTemboMapping
#' @param mappingID mappingIDs of the mapping-tables to be loaded
#' @param useCache load cached mapping-tables from rds file
#' @param initCache load mapping-tables and cache them in a proper rds file
#' @param mappingFileShare path to a fileshare from which the mapping-tables shall be loaded
#' @param temboBaseUrl string containing the Tembo base URL
#' @examples
#' tembo::loadTemboMapping(c(100, 102), TRUE, FALSE, "//VIHSDV002.infineon.com/tembo_result_prod/Mappings")
#' 
loadTemboMapping<-function(mappingIDs, useCache=FALSE, initCache=FALSE, mappingFileShare=NA, temboBaseUrl=NA, timeout=1800) {
  
  cacheFileShare<-"//VIHSDN04.eu.infineon.com/tembo_stage/cache"
  
  if (useCache && file.exists(paste0(cacheFileShare, "/mapping_", paste0(mappingIDs, collapse=","), ".rds"))) {
    # use cached mapping
    return(readRDS(paste0(cacheFileShare, "/mapping_", paste0(mappingIDs, collapse=","), ".rds")))
  }
  
  mapping<-data.frame()
  for (mappingID in mappingIDs) {
    if (!is.na(mappingFileShare) && file.exists(paste0(mappingFileShare, "/", mappingID, ".json"))) {
      mappingTable<-jsonlite::read_json(paste0(mappingFileShare, "/", mappingID, ".json"))
      mappingMetaData<-jsonlite::read_json(paste0(mappingFileShare, "/", mappingID, ".metadata.json"))
      
      # create mapping structure
      Header<-list()
      Header$Version<-"unknown"
      Header$Id<-unique(sapply(mappingMetaData, function(x) x$MappingId))
      Header$Name<-"unknown"
      MetaData<-list()
      for (metaData in mappingMetaData) {
        MetaData[[metaData$Name]]<-metaData$Value
      }
      MappingTable<-data.frame(
        CommonName=sapply(mappingTable, function(x) x$CommonName),
        Domain=unlist(sapply(mappingTable, function(x) ifelse(is.null(x$Domain), NA, x$Domain))),
        RequirementId=unlist(sapply(mappingTable, function(x) ifelse(is.null(x$RequirementId), NA, x$RequirementId)))
      )
      MappingTable$SourceFields<-lapply(mappingTable, function(x) unlist(sapply(x$SourceFields, function(y) y$SourceField)))
      MappingTable$Filters=lapply(mappingTable, function(x) paste0(unlist(sapply(x$Filters, function(y) y$Name)), ",", unlist(sapply(x$Filters, function(y) y$Value))))
      MappingTable$Mappings=lapply(mappingTable, function(x) paste0(unlist(sapply(x$Mappings, function(y) y$Name)), ",", unlist(sapply(x$Mappings, function(y) y$Value))))
      MappingTable$ExtraColumns=lapply(mappingTable, function(x) paste0(unlist(sapply(x$ExtraColumns, function(y) y$Name)), ",", unlist(sapply(x$ExtraColumns, function(y) y$Value))))
      MappingTable$Formulas=lapply(mappingTable, function(x) unlist(sapply(x$Formulas, function(y) y$Formula)))
      
      mappingTmp<-list(Header=Header, Mapping=list(MetaData=MetaData, MappingTable=MappingTable))
    } else {
      response<-httr::GET(paste0(temboBaseUrl, '/api/mapping/GetMapping?MappingId=', mappingID),
                          httr::authenticate("", "", "ntlm"),
                          httr::config(ssl_verifypeer=0L),
                          httr::timeout(timeout),
                          httr::content_type_json())
      
      if (response$status_code!=200) stop(paste0('Mapping could not be loaded\n\nHttp response:\n', httr::content(response, type = "text")))
      content<-httr::content(response)
      if (content$Message=="null" | !content$Successful) stop(paste0('Mapping could not be loaded\n\nHttp response:\n', httr::content(response, type = "text")))
      
      mappingTmp<-jsonlite::fromJSON(content$Message)
    }
    
    mapping<-rbind(mapping, mappingTmp$Mapping$MappingTable)
  }
  
  if (initCache) {
    ##########################################################################################################################################
    # Temporary hotfix for https://jiradc.intra.infineon.com/browse/TEMBO-3575
    # This is to be removed again when https://jiradc.intra.infineon.com/browse/TEMBO-3589
    # is implemented --> subtask https://jiradc.intra.infineon.com/browse/TEMBO-3612
    ##########################################################################################################################################
    saveRDS(mapping, paste0(cacheFileShare, "/mapping_", paste0(mappingIDs, collapse=","), ".rds"))
    ##########################################################################################################################################
  }
  
  return(mapping)
}