#===============================================================================================
#' This function loads waveforms from matlab data files
#' 
#' tmp <- loadMatlabWaveformDf(
#'                filename = "/Users/schmidhe/Downloads/Iq1.mat",
#'                createLimitsDataFrame = TRUE
#'              )
#' dat <- tmp[[1]]
#' currentLimits <- tmp[[2]]
#' 
#' # or if you want to access the tembo API:
#' 
#' dat <- loadMatlabWaveformDf("https://tembo.intra.infineon.com/api/Resource/tutorial/someid")
#' 
#' The file loader assumes that the R.matlab::readMat() function loads the waveforms
#' as the second list entry
#' 
#'
#' @author Helena Schmidt, \email{schmidt.external9@infineon.com}
#' @export
loadMatlabWaveformDf <- function(
    filename,
    createLimitsDataFrame = FALSE
  ){
  rmat <- R.matlab::readMat(filename)
  myDat <- data.frame(dummy=1)
  currentLimits <- data.frame()
  signalNames <- dimnames(rmat[[2]])[[1]]
  for(i in 1:length(rmat[[2]])){
    currentNames <- dimnames(rmat[[2]][[i]])[[1]]
    tmpDat <- list(
      y = as.vector(rmat[[2]][[i]][[which(currentNames == "y")]]),
      t = as.vector(rmat[[2]][[i]][[which(currentNames == "t")]])
    )
    if(length(which(currentNames == "y.unit"))>0) {
      units <- guess_unit_scale(as.vector(rmat[[2]][[i]][[which(currentNames == "y.unit")]]))
      tmpDat$y <- 10^-units$scale * tmpDat$y
      currentLimits <- rbind(currentLimits, data.frame(
        name = signalNames[i],
        unit = units$unit,
        scale = units$scale,
        stringsAsFactors = FALSE
      ))
    }
    if(length(which(currentNames == "t.unit"))) {
      units <- guess_unit_scale(as.vector(rmat[[2]][[i]][[which(currentNames == "t.unit")]]))
      tmpDat$t <- 10^-units$scale * tmpDat$t
      if(!any("t" == currentLimits$name)) {
        currentLimits <- rbind(currentLimits, data.frame(
          name = "t",
          unit = units$unit,
          scale = 1, # scale should be seconds
          stringsAsFactors = FALSE
        ))
      }
    }
    myDat[[signalNames[i]]] <- list(tmpDat)
  }
  if(createLimitsDataFrame){
    return(list(myDat,currentLimits))
  } else {
    return(myDat)
  }
}
