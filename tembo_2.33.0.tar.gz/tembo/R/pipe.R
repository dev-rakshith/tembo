#' @importFrom magrittr %>%
#' @export
magrittr::`%>%`