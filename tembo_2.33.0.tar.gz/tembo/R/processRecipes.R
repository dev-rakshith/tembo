#' Tembo Recipe Processor
#'
#' Process Tembo recipes embedded in a DITA document and replace them with the generated content
#'
#' See also \url{https://confluencewikiprod.intra.infineon.com/display/TEM}
#'
#' \emph{Copyright (c) 2016 Infineon Technologies} 
#' @param ditaFile The name of a DITA file with Tembo recipes to evaluate
#' @param outputFolder Output folder where generated content and resolved DITA files will be stored
#' @examples
#' processRecipes(ditaFile = "rdson.dita", outputFolder = "C:/temp/report")
#' @family dita
#' @author Kunze Matthias (IFAG ATV PTP MSF DM), \email{matthias.kunze2@@infineon.com}
#' @export
processRecipes <- function(ditaFile, outputFolder) {

  # Create ouput folder
  dir.create(outputFolder, showWarnings = FALSE)

  # Load the unprocessed DITA document including recipes
  doc<-XML::xmlParse(ditaFile)
  
  # Find all tembo R recipes in the document
  recipeNodes<-XML::xpathApply(doc, "//codeblock[@xml:lang='TemboRecipe']")
  
  # Iterate over the recipes and replace them with content
  for (i in 1:length(recipeNodes)) {
    recipeNode<-recipeNodes[[i]];
    
    # Execute the recipe
    eval(parse(text=XML::xmlValue(recipeNode)))
    
    # Add generated content
    #imageNode<-newXMLNode("image", parent = xmlParent(recipeNode), attrs = c(href=temboPlot));
    
    # Remove the recipe
    XML::removeNodes(recipeNode)
  }
  
  # Save the processed DITA document
  XML::saveXML(doc, file.path(outputFolder, basename(ditaFile)), indent = TRUE)  
}