#===================================================================================================
#' Tembo Template Processor
#'
#' Process Tembo templates embedded in a document and replace them with the generated content
#'
#' \emph{Copyright (c) 2017 Infineon Technologies}
#' @param templateFilePath Path to a template file with R code patterns to evaluate
#' @param outputFilePath Output file path, where generated resolved template document will be stored
#' @param templatePatternStart Start-tag of embedded R code (optional)
#' @param templatePatternEnd End-tag of embedded R code (optional)
#' @param params List of individual parameters (optional)
#' @examples
#' processTemplate(templateFilePath="C:/temp/reportTemplates/htmlTemplate.tpl", outputFilePath="C:/temp/report/processed.html", params=list(query="myQuery"))
#' @family Report templates
#' @author Thomas Michenthaler (IFAT DC ATV PTP MSF VI), \email{thomas.michenthaler@infineon.com}
#' @export
#---------------------------------------------------------------------------------------------------
processTemplate <- function(templateFilePath="", templateString="", outputFilePath, templatePatternStart="{{", templatePatternEnd="}}", params)
{
  if(templateFilePath == "" && templateString=="")
  {
    stop("please define either 'templateFilePath' or 'templateString'")
  }
  else if (templateFilePath == "")
  {
    str_templateLines <- templateString
    str_templateLines<-gsub("<br />", "\n", str_templateLines)
  }
  else
  {
    #read unprocessed template document including tembo patterns (code snippets)
    arr_templateLines <- readLines(templateFilePath)
    str_templateLines <- paste(arr_templateLines, collapse="\n")
  }

  #get all included template patterns
  arr_templatePatterns <- regmatches(str_templateLines, gregexpr(paste("(?s)(?<=", templatePatternStart, ").*?(?=", templatePatternEnd, ")", sep=""), str_templateLines, perl=TRUE))
  
  myResult<<-""
  
  #loop through template patterns
  for (i in 1:length(arr_templatePatterns[[1]]))
  {
    arr_split<-strsplit(arr_templatePatterns[[1]][i], "\n")

    myResult<<-""
    
    for (j in 1:length(arr_split[[1]]))
    {
      tryCatch(
        {
          # 17-03-16 MK: decoding deactivated
          #remove all html-tags and then decode html-entities
          #str_unescapedPattern<-textutils::HTMLdecode(removeHtmlTags(arr_split[[1]][j]))
          str_unescapedPattern<-arr_split[[1]][j]
          
          #trim string
          str_pattern<-gsub("^\\s+|\\s+$", "", str_unescapedPattern)

          if (str_pattern == "")
          {
            next
          }

          #evaluate pattern
          eval(parse(text=str_pattern))
        },
        error=function(e)
        {
          myResult<<-paste(">>>ERROR: can't evaluate template pattern \"", str_pattern,"\"<<<", sep="")
        })
    }

    #replace template pattern with evaluated result
    str_templateLines<-gsub(paste(templatePatternStart, arr_templatePatterns[[1]][i], templatePatternEnd, sep=""), myResult, str_templateLines, fixed=TRUE)
  }
  
  # 17-03-16 MK: decoding deactivated
  #decode all remaining html-entities and generate processed template document
  #write(textutils::HTMLdecode(textutils::HTMLdecode(str_templateLines)), file = outputFilePath)
  write(str_templateLines, file = outputFilePath)
}

#===================================================================================================
#' Add result to template document
#' 
#' @param result Result text that should be added to the resolved template document
#---------------------------------------------------------------------------------------------------
addToDocument <- function(result)
{
  myResult<<-result
}

#===================================================================================================
#' Helper-function that removes all html-tags from a given string
#' 
#' @param str string, that should be cleaned from html-tags
#---------------------------------------------------------------------------------------------------
removeHtmlTags <- function(str)
{
  xml2::xml_text(xml2::read_html(paste0("<x>", str, "</x>")))
}