#' Query to the Tembo database
#'
#' ...
#' 
#' @param host Host name of Elasticsearch, defaults to "elk-dev.vih.infineon.com"
#' @param user Elasticsearch user name, defaults to current user name
#' @param pwd Elasticsearch password, opens up dilog box if not given
#' @param index Elasticsearch index to be queried
#' @param query Elasticsearch query
#' @author Kunze Matthias (IFAG ATV PTP MSF DM), \email{matthias.kunze2@@infineon.com}
#' @export
#' @examples
#' query()
queryTembo <- function(host="elk-dev.vih.infineon.com", user, pwd, index, query){
  
  if(missing(user)) {
    user=Sys.info()[["user"]]
  }
  
  if(missing(pwd)) {
    pwd=getPass::getPass()
  }
  
  httr::set_config(httr::config(ssl_verifypeer=0L))

  conn<-elastic::connect(es_host=host, es_user = user, es_pwd = pwd, es_transport_schema="https", verbose=TRUE)
  
  res<-elastic::Search(index=index, body=query$getJSON(), scroll="5m", search_type = "scan", size = 10000) #, analyze_wildcard = TRUE)
  out <- list()
  hits <- 1
  while(hits != 0){
    res <- elastic::scroll(scroll_id = res$`_scroll_id`)
    hits <- length(res$hits$hits)
    #print(sprintf("<%d>", hits))
    if(hits > 0)
      out <- c(out, res$hits$hits)
  }
  
  data<-data.frame(dummy=sapply(out, function(x) x$`_source`$X));
  for (i in 1:length(query$source)) {
    data[[query$source[[i]]]] <- sapply(out, function(x) x$`_source`[[query$source[[i]]]]);
    
    if (suppressWarnings((!is.na(as.numeric(data[[query$source[[i]]]][[1]]))))) {
      data[[query$source[[i]]]]<-as.numeric(data[[query$source[[i]]]])
    }
  }
  
  data$dummy=NULL;

  return(data)
}
