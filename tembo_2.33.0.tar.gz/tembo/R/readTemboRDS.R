############################################################################################
#' Read Tembo RDS
#' 
#' \emph{Copyright (c) 2019 Infineon Technologies}
#' @family tembo analysis
#' @author Thomas Michenthaler (IFAT DC ATV PTP TD VI), \email{thomas.michenthaler@infineon.com}
#' @export readTemboRDS
#' @param dat data.frame containing RDS information
#' @param sourceFolder string containing the path to the source folder of the RDS files to be loaded
readTemboRDS<-function(dat, sourceFolder, verbose=FALSE) {
  dats<-list()
  dat_tmp<-data.frame()
  rdsRows<-which(as.vector(apply(dat, 1, function(x) any(startsWith(as.character(x), sourceFolder)))))
  
  for (row in rdsRows) {
    dat_rds<-data.frame()
    
    # add data from RDS files
    for (col in which(startsWith(as.character(dat[row,]), sourceFolder))) {
      
      if (verbose) cat(paste0("> loading ", dat[row,col], " ", row, " of ", length(rdsRows), "\n"))
      
      if (ncol(dat_rds) == 0) {
        tryCatch({dat_rds<-data.frame(readRDS(dat[row,col]), stringsAsFactors=F)},
                 error = function(e){
                   #dat_rds <- data.frame(V=as.numeric(NA))
                   #return(dat_rds)
                   filefailed <- dat[row,col]
                   stop(paste0("Following file: ", filefailed," could not be read"))
                 })
      } else {
        
        
        tryCatch({dat_rds<-cbind.data.frame(dat_rds, readRDS(dat[row,col]), stringsAsFactors=F)},
                 error = function(e) {
                   #dat_NA <- data.frame(V=as.numeric(NA))
                   #dat_rds <- cbind.data.frame(dat_rds,dat_NA)
                   #return(dat_rds)
                   filefailed <- dat[row,col]
                   stop(paste0("Following file: ", filefailed," could not be read"))
                 })
      }
      names(dat_rds)[ncol(dat_rds)]<-names(dat)[col]
    }
    # add constant values
    for (col in which(!startsWith(as.character(dat[row,]), sourceFolder) | is.na(as.data.frame(dat[row,])))) {
      if(!is.na(dat[row,col])){
        dat_rds[[names(dat)[col]]] <- dat[row,col]
      } else {
        dat_rds[[names(dat)[col]]] <- NA
      }
    }
    
    # recover order
    dats[[length(dats)+1]]<-dat_rds[,names(dat)]
  }

  # Bind ...
  if (verbose) cat("Binding...");
  binded<-data.table::rbindlist(dats, fill = TRUE)
  if (verbose) cat("done\n")
  
  # bind not RDS data
  if (length(rdsRows) > 0) dat<-dat[-rdsRows,]
  
  # Fix datatypes of rds columns. Since data frames can only have one type per column,
  # all columns with rds rows are character, because the rds filename has to be a string
  for(thisColumn in colnames(binded)){
    if(typeof(dat[[thisColumn]]) != typeof(binded[[thisColumn]])){
      if(is.character(binded[[thisColumn]])){
        dat[[thisColumn]] <- as.character(dat[[thisColumn]])
      } else if(is.numeric(binded[[thisColumn]])){
        dat[[thisColumn]] <- as.numeric(dat[[thisColumn]])
      } else if(is.factor(binded[[thisColumn]])){
        dat[[thisColumn]] <- as.factor(dat[[thisColumn]])
      } else if(is.logical(binded[[thisColumn]])){
        dat[[thisColumn]] <- as.logical(dat[[thisColumn]])
      } else {
        warning("Your data is neither character, numeric, factor nor logical. Maybe your RDS is weird?")
      }
    }
  }
  result <- rbind.data.frame(dat, binded, stringsAsFactors=F)
  gc()
  return(result)
}