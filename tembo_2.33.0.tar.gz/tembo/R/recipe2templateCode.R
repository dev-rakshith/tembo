#' Executes a Tembo Recipe
#'
#' Creates R code for usage in a Report Template  of a Tembo Recipe
#'
#' \emph{Copyright (c) 2018 Infineon Technologies} 
#' @param recipeID Tembo Recipe ID
#' @param user User name
#' @param password User password
#' @param temboServer URL of the Tembo server where recipes will be fetched
#' @examples 
#' tembo::recipe2templateCode(recipeID='71ACEDA4-8456-4EC3-8609-C970F0812989')
#' @author Kunze Matthias (IFAG ATV PTP MSF DM), \email{matthias.kunze2@@infineon.com}
#' @export
recipe2templateCode <- function(recipeID, user="", password="", temboServer="https://tembo.intra.infineon.com") {
  
  #########################################################
  # Fetch recipe from server
  #########################################################
  response<-httr::GET(paste0(temboServer, '/api/recipe/GetRecipe?recipeId=', recipeID),
                      httr::authenticate(user, password, "ntlm"),
                      httr::config(ssl_verifypeer=0L))
  if (response$status_code>299) stop(paste0('Embedded recipe with id "', recipeID, '" could not be loaded\n\nHttp response:\n', httr::content(response, type = "text")))
  if (is.null(httr::content(response)$Id)) stop(paste0('Recipe with id "', recipeID, '" could not be loaded\n\nHttp response:\n', httr::content(response, type = "text")))
  recipe<-httr::content(response)
  
  #########################################################
  # Transform recipe
  #########################################################
  recipe<-XML::xmlParse(recipe$Recipe, encoding = "UTF-8")
  
  code<-"recipe<-tembo::temboRecipe(serverBaseURL=currentPage$serverBaseURL)\n"
  
  # Iterate over steps  
  for (template in XML::xpathSApply(recipe, "/Recipe/ApplyTemplate[not(@enabled='false')]")) {  
    attributes<-XML::xmlAttrs(template)
    templateName<-attributes[["href"]]
    templateName<-stringr::str_match(templateName, "(?<=rcodes\\/).*(?=\\.xsl)")
    
    code<-paste0(code, "recipe$addStep(\"", templateName, "\"")
    
    for (param in XML::xpathSApply(template, "param")) {  
      children<-XML::xmlChildren(param);
      
      paramName<-XML::xmlValue(children[[1]])
      paramValue<-XML::xmlValue(children[[2]])
      
      if (templateName=="query" && paramName=="filter") {
        code<-paste0(code, ", filter=currentQuery$filter")
        
      } else if (templateName=="query" && paramName=="query") {
        # Skip
        
      } else if (templateName=="query_limits" && paramName=="filter") {
        code<-paste0(code, ", filter=currentLimitQuery$filter")
        
      } else if (templateName=="query_limits" && paramName=="query") {
        # Skip
        
      } else if (templateName=="save_results" && paramName=="reportPageID") {
        code<-paste0(code, ", reportPageID=currentPage$id")
        
      } else {
        code<-paste0(code, ", ", paramName, "=\"", paramValue, "\"")
      }
    }
    
    code<-paste0(code, ")\n")
  }
  
  return(code)
}