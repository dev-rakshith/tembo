#===================================================================================================
#' Tembo Template Processor
#'
#' Recipe object
#' 
#' \emph{Copyright (c) 2017 Infineon Technologies}
#' @param recipeName Name of a recipe that is generated
#' @examples
#' rp<-new("recipe", recipeName="myRecipe")
#' @family Report templates
#' @author Thomas Michenthaler (IFAT DC ATV PTP MSF VI), \email{thomas.michenthaler@infineon.com}
#' @exportClass recipe
#' @exportMethod addStep
#' @exportMethod saveRecipe
#---------------------------------------------------------------------------------------------------
setClass(
  "recipe",
  representation(recipeName="character")
)
#===================================================================================================
#' Init recipe object and define output string of recipe-document to be generated
#---------------------------------------------------------------------------------------------------
setMethod("initialize", "recipe", function(.Object, recipeName)
{
  tryCatch(
  {
    #output<<-c("<?xml version=\"1.0\" encoding=\"utf-8\"?>", "<Recipe>", paste("  <Name>", recipeName, "</Name>", sep=""))
    output<<-c("<Recipe>", paste("  <Name>", recipeName, "</Name>", sep=""))    
    .Object@recipeName <- recipeName
  },
  error=function(e)
  {
    stop("please define recipe name")
  })

  .Object
})

#===================================================================================================
#' Add XML code to recipe describing one step
#' 
#' @param theObject Recipe object
#' @param rTemplateName Name of the R template that should be used to generate step
#' @param ... Optional parameters that are needed to use/execute the defined R template
#---------------------------------------------------------------------------------------------------
setGeneric(name="addStep", def=function(theObject, rTemplateName, ...)
{
  standardGeneric("addStep")
})
setMethod(f="addStep", signature="recipe", def=function(theObject, rTemplateName, ...)
{
  output<<-c(output, paste("  <ApplyTemplate href=\"rcodes/", rTemplateName,".xsl\">", sep=""))

  #get all optional arguments
  params<-list(...)

  #loop through optional arguments
  for(paramName in ls(params))
  {
    output<<-c(output, "    <param>")
    output<<-c(output, paste("      <name>", paramName, "</name>", sep=""))
    output<<-c(output, paste("      <value>", params[[paramName]], "</value>", sep=""))
    output<<-c(output, "    </param>")
  }

  output<<-c(output, "  </ApplyTemplate>")
})

#===================================================================================================
#' Save recipe to <path>/<recipeName>.rcp
#' 
#' ATTENTION: This is a temporary solution - just for testing purposes!
#'            The entire 'save' functionality should finally be done by a web service.
#' 
#' @param theObject Recipe object
#' @return generated ID to identify recipe
#---------------------------------------------------------------------------------------------------
setGeneric(name="saveRecipe", def=function(theObject)
{
  standardGeneric("saveRecipe")
})
setMethod(f="saveRecipe", signature="recipe", def=function(theObject)
{

  # Upload recipe via AddRecipe web service
  req <- httr::POST("https://tembo-dev.intra.infineon.com/api/recipe/AddRecipe", 
                    body = paste(c('\'', output, '</Recipe>', '\''), collapse = ''), 
                    httr::content_type("application/json"),
                    httr::authenticate("", "", "gssnegotiate"),
                    httr::config(ssl_verifypeer=0L))
  
  # Get response
  result<-httr::content(req)
  
  return(result$RecipeId)
})
