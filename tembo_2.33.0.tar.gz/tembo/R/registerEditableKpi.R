#' Register editable KPIs to a given report
#' 
#' \emph{Copyright (c) 2021 Infineon Technologies}
#' 
#' @family tembo analysis engine
#' @author Thomas Michenthaler\email{thomas.michenthaler@@infineon.com}
#' @export registerEditableKPI
#' 
#' @param editableKpiList list of KPIs, including the corresponding labels and values, that shall be registered as editable KPIs
#' @examples
#' tembo::registerEditableKPI(list(list(Name="Review", data.frame(Label=c("Pass", "Fail", "Clear"), Values=c("PASS", "FAIL", ""), stringsAsFactors=FALSE))))

registerEditableKPI <- function(editableKPIs) {
  
  response<-httr::POST(paste0(currentReport$serverBaseURL, "/api/Report/", currentReport$reportId, "/EditableKpi"),
                       body=jsonlite::toJSON(editableKPIs, auto_unbox=TRUE),
                       httr::content_type("application/json"),
                       httr::authenticate(Sys.info()["user"], tembo::getPassword(), "ntlm"),
                       httr::config(ssl_verifypeer=0L))
  if (response$status_code>299) {
    stop(paste0('Error while registering editable KPIs:\n', httr::content(response, type = "text")))
  }
}
