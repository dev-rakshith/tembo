#library(httr)

#===================================================================================================
#' Tembo Template Processor
#'
#' Send request to Confluence Rest API and get HTML content of requested page
#'
#' \emph{Copyright (c) 2017 Infineon Technologies}
#' @param pageId ID of Confluence page (is to be found in Confluence URL when editing page or open site-information)
#' @param username Username for authentication (if no username and password defined, authentication is done automatically with Tembo-Serviceuser)
#' @param password Password for authentication (if no username and password defined, authentication is done automatically with Tembo-Serviceuser)
#' @return HTML content of requested page
#' @examples
#' htmlContent<-requestConfluencePageFromID(12345678) | htmlContent<-requestConfluencePageFromID(12345678, username="user1", password="myPassword")
#' @family Report templates
#' @author Thomas Michenthaler (IFAT DC ATV PTP MSF VI), \email{thomas.michenthaler@infineon.com}
#' @export
#---------------------------------------------------------------------------------------------------
requestConfluencePageFromID <- function(pageId, username="", password="")
{
  if (username == "" && password == "") {
      json<-httr::GET(paste("https://confluencewikiprod.intra.infineon.com/rest/api/content/", pageId,"?expand=body.storage", sep=""),
                      httr::authenticate("", "", "gssnegotiate"), httr::config(ssl_verifypeer=0L))
  } else {
      json<-httr::GET(paste("https://confluencewikiprod.intra.infineon.com/rest/api/content/", pageId,"?expand=body.storage", sep=""),
                      httr::authenticate(user=username, password=password), httr::config(ssl_verifypeer=0L))
  }

  result<-httr::content(json)

  return(result$body$storage$value)
}
