#library(httr)

#===================================================================================================
#' Tembo Template Processor
#'
#' Send request to Confluence Rest API and get HTML content of requested page
#'
#' \emph{Copyright (c) 2017 Infineon Technologies}
#' @param pageUrl URL of Confluence page
#' @param username Username for authentication (if no username and password defined, authentication is done automatically with Tembo-Serviceuser)
#' @param password Password for authentication (if no username and password defined, authentication is done automatically with Tembo-Serviceuser)
#' @return HTML content of requested page
#' @examples
#' htmlContent<-requestConfluencePageFromURL("https://confluencewikiprod.intra.infineon.com/display/my-confluence-page") | htmlContent<-requestConfluencePageFromURL("https://confluencewikiprod.intra.infineon.com/display/my-confluence-page", username="user1", password="myPassword")
#' @family Report templates
#' @author Thomas Michenthaler (IFAT DC ATV PTP MSF VI), \email{thomas.michenthaler@infineon.com}
#' @export
#---------------------------------------------------------------------------------------------------
requestConfluencePageFromURL<-function(pageUrl, username="", password="")
{
  #get page title
  title<-basename(pageUrl)

  if (username == "" && password == "") {
    json<-httr::GET(paste("https://confluencewikiprod.intra.infineon.com/rest/api/content?title=", title, "&expand=body.storage", sep=""),
      httr::authenticate("", "", "gssnegotiate"), httr::config(ssl_verifypeer=0L))
  } else {
    json<-httr::GET(paste("https://confluencewikiprod.intra.infineon.com/rest/api/content?title=", title, "&expand=body.storage", sep=""),
      httr::authenticate(user=username, password=password), httr::config(ssl_verifypeer=0L))
  }

  result<-httr::content(json)

  return(result$results[[1]]$body$storage$value)
}
