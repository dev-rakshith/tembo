#' Create a tembo boxplot
#'
#' The function plots a boxplot of the input data. 
#'
#' \emph{Copyright (c) 2021 Infineon Technologies}
#' @param data data frame
#' @param geom "step", "line", "point"
#' 
#' @return Returns a ggplot2 graph object
#' @examples
#' ggplot(data) + geom_boxplot(stat=tembo::StatBoxplot_ifx)

#' @family tembo plots
#' @author Helena Schmidt \email{schmidt.externel9@@infineon.com}
#' @export
stat_boxplot_ifx <- function(mapping = NULL, data = NULL,

																											 geom = "step", position = "identity",
														 ...,
														 n = NULL,
														 pad = TRUE,
														 na.rm = FALSE,
														 show.legend = NA,
														 inherit.aes = TRUE) {
	ggplot2::layer(
		data = data,
		mapping = mapping,
		stat = StatBoxplot_ifx,
		geom = geom,
		position = position,
		show.legend = show.legend,
		inherit.aes = inherit.aes,
		params = list(
			n = n,
			pad = pad,
			threshold = threshold,
			reducedDots = reducedDots,
			na.rm = na.rm,
			...
		)
	)
}

#' Calculate the data for the boxplot
#'
#' \emph{Copyright (c) 2020 Infineon Technologies}
#' @param data data frame
#' @return Data frame with caculated x and y data
#' @examples
#' currentTemboPlot$addToPlot(ggplot2::geom_boxplot(stat=tembo::StatBoxplot_ifx))

#' @family stats
#' @author Helena Schmidt \email{schmidt.externel9@@infineon.com}
#' @export
boxplot_ifx = function(data, scales, n = NULL, pad = TRUE) {
  #print(data)
  #print(ggplot2::StatBoxplot$compute_group(data))
  boxplotStats <- data.frame(
    "ymin" = data$y[1],
    "lower" = data$y[2],
    "middle" = data$y[3],
    "upper" = data$y[4],
    "ymax" = data$y[5],
    "notchupper" = data$y[6],
    "notchlower" = data$y[7]
  )
  if(nrow(data)>7){
    boxplotStats$outliers <- list(data$y[7:nrow(data)])
  } else {
    boxplotStats$outliers <- list()
  }
  x_stats <- ggplot2::StatBoxplot$compute_group(data=data.frame(x=data$x))
  boxplotStats$x <- x_stats$x
  boxplotStats$relvarwidth <- x_stats$relvarwidth
  boxplotStats$flipped_aes <- FALSE
  #print(boxplotStats)
  return(boxplotStats)
}

#' Custom Stat Object for the tembo Boxplot
#'
#'
#' \emph{Copyright (c) 2021 Infineon Technologies}
#' @param vector
#' @return Data frame with caculated x and y data
#' @examples
#' boxplot_preprocessor(dat$IVS_28V)

#' @family stats
#' @author Helena Schmidt \email{schmidt.externel9@@infineon.com}
#' @export
StatBoxplot_ifx <- ggplot2::ggproto("StatBoxplot_ifx", ggplot2::StatBoxplot,
																		compute_group = boxplot_ifx)



#' Calculate the data for the boxplot
#'
#'
#' \emph{Copyright (c) 2021 Infineon Technologies}
#' @param vector
#' @return Data frame with caculated x and y data
#' @examples
#' boxplot_preprocessor(dat$IVS_28V)

#' @family stats
#' @author Helena Schmidt \email{schmidt.externel9@@infineon.com}
#' @export
boxplot_preprocessor <- function(y) {
  calculatedStats <- ggplot2::StatBoxplot$compute_group(data.frame(y=y))
  boxplotColumns <- c( "ymin", "lower", "middle", "upper", "ymax", "notchupper", "notchlower")
  df <- calculatedStats %>% 
    dplyr::select(dplyr::all_of(boxplotColumns)) %>% 
    tidyr::pivot_longer(dplyr::all_of(boxplotColumns)) %>%
    dplyr::rename(y_ = value, boxplotName = name)
  #print(df)
  if(length(calculatedStats$outliers[[1]])>0){
    df <- rbind(as.data.frame(df), data.frame(boxplotName="outliers", y_=unlist(calculatedStats$outliers)))
  }
  return(df)
}




