#' Create a tembo cumulative frequency plot
#'
#' The function plots an ecdf of the input data. The definition is similar to stat_ecdf
#' from ggplot2, but this function divides by (n+1) instead of (n)
#' See also https://en.wikipedia.org/wiki/Empirical_distribution_function
#'
#' \emph{Copyright (c) 2018 Infineon Technologies}
#' @param data data frame
#' @param geom "step", "line", "point"
#' @param threshold 2000 above the threshold of data points, the data to plot gets reduced to increase plot speed
#' @param reducedDots 200 number of data points that get plotted if the plotsize is reduced 
#' 
#' @return Returns a ggplot2 graph object
#' @examples
#' ggplot(data) + stat_ecdf_ifx(geom = 'line') + stat_ecdf_ifx(geom = 'point')

#' @family tembo plots
#' @author Helena Schmidt \email{schmidt.externel9@@infineon.com}
#' @export
stat_ecdf_ifx <- function(mapping = NULL, data = NULL,

																											 geom = "step", position = "identity",
														 ...,
														 n = NULL,
														 pad = TRUE,
														 threshold = 2000,
														 reducedDots = 200,
														 na.rm = FALSE,
														 show.legend = NA,
														 inherit.aes = TRUE) {
	ggplot2::layer(
		data = data,
		mapping = mapping,
		stat = StatEcdf_ifx,
		geom = geom,
		position = position,
		show.legend = show.legend,
		inherit.aes = inherit.aes,
		params = list(
			n = n,
			pad = pad,
			threshold = threshold,
			reducedDots = reducedDots,
			na.rm = na.rm,
			...
		)
	)
}

#' Calculate the data for the cumulative frequency plot
#'
#' The definition is similar to ecdf,
#' but this function divides by (n+1) instead of (n)
#' See also https://en.wikipedia.org/wiki/Empirical_distribution_function
#'
#' \emph{Copyright (c) 2020 Infineon Technologies}
#' @param data data frame
#' @return Data frame with caculated x and y data
#' @examples
#' ecdf_ifx(data.frame(x=dat$IVS_28V))

#' @family stats
#' @author Helena Schmidt \email{schmidt.externel9@@infineon.com}
#' @export
ecdf_ifx = function(data, scales, n = NULL, pad = TRUE, threshold= 2000, reducedDots=200) {
  ecdf_simple(data$x, threshold=threshold, reducedDots = reducedDots)
}

StatEcdf_ifx <- ggplot2::ggproto("StatEcdf_ifx", ggplot2::StatEcdf,
																		compute_group = ecdf_ifx)



#' Calculate the data for the cumulative frequency plot
#'
#' The definition is similar to ecdf,
#' but this function divides by (n+1) instead of (n)
#' See also https://en.wikipedia.org/wiki/Empirical_distribution_function
#'
#' \emph{Copyright (c) 2020 Infineon Technologies}
#' @param vector
#' @return Data frame with caculated x and y data
#' @examples
#' ecdf_simple(dat$IVS_28V)

#' @family stats
#' @author Helena Schmidt \email{schmidt.externel9@@infineon.com}
#' @export
ecdf_simple <- function(x, threshold= 2000, reducedDots=200) {
  x <- sort(x)
  n <- length(x)
  if (n < 1) 
    stop("'x' must have 1 or more non-missing values")
  vals <- unique(x)
  y <- approxfun(vals, cumsum(tabulate(match(x, vals)))/(n+1), 
                 method = "constant", yleft = 0, yright = 1, f = 0, ties = "ordered")(x)
  df <- data.frame(x = x, y = y)
  if(nrow(df) > threshold){
    indicesToUse <- c(1:5,
                      (nrow(df)-4):nrow(df),
                      round(seq(from=6,to=nrow(df)-5, length.out=reducedDots-10)))
    span <- max(df$x)-min(df$x)
    span
    diffs <- diff(df$x)
    largeDiffs <- which(diffs > (span/50))
    #make sure both points will be plotted
    indicesToUse <- unique(c(indicesToUse,largeDiffs, largeDiffs + 1))
    df <- df[sort(indicesToUse),]
  }
  if(nrow(df)>1 & length(unique(df$y)) == 1) {
    #don't plot single value data only at one extreme position:
    #print("only one value")
    df$y <- seq(from=df$y[1],to=1-df$y[1],length.out=nrow(df))
  }
  colnames(df) <- c("x_", "y_")
  return(df)
}
