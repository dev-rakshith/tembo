############################################################################################
#' Fetch tests from TCE by filter conditions
#' 
#' TCE documentation:
#' https://confluencewikiprod.intra.infineon.com/display/TCE/Test+Control+Environment+Home
#' 
#' TCE Swagger:
#' https://tce.infineon.com/api/docs/index.html
#' 
#' Example:
#' 
#' limits<-getTceTests(51, testNumbers = c(14128, 14129, 14130, 14131), insertions = "Q3")
#' 
#' \emph{Copyright (c) 2021 Infineon Technologies}
#' @author Kunze Matthias (IFAG ATV PTP MSF PDM), \email{matthias.kunze2@infineon.com}
#' @export
getTceTests <- function(id, testNumbers=c(), insertions=c(), testflows=c(), revision=NA, apiURL="https://tce.infineon.com/api/v1", 
                        apiKey="qJz8UdFFRftP9ijVmAANkiMWrxLVpWuQ", chunkSize=500) {
  
  # Parameters for URL
  params<-""
  if (length(testNumbers)) params<-paste0(params, '&', paste(paste0("testNumbers=", testNumbers, collapse = "&")))
  if (length(insertions)) params<-paste0(params, '&', paste(paste0("insertions=", insertions, collapse = "&")))
  if (length(testflows)) params<-paste0(params, '&', paste(paste0("testflows=", testflows, collapse = "&")))
  if (!is.na(revision)) params<-paste0(params, '&revision=', revision)
  
  # Fetch data with pagination
  offset<-0
  data<-list()
  repeat {
    
    # Build command
    cmd=paste0(apiURL, "/tests/product/", id, '?limit=', chunkSize, '&offset=', offset, params)
    #cat(cmd, '\n')
    
    # Do call
    response<-httr::GET(cmd, httr::config(ssl_verifypeer=0L), httr::add_headers(accept="application/json"), httr::add_headers('x-api-key'=apiKey))
    
    # Check for errors 
    if (httr::http_error(response)) stop(httr::http_status(response), httr::content(response))
    
    # Get the data...
    res<-httr::content(response)
    if (!length(res$data)) stop("No matching limits found")
    data<-append(data, res$data)
    offset<-length(data)
    
    # Stop?
    if (offset>=res$meta$pageInfo$totalResults) break
  }
  
  # Transform to Tembo limit format
  test_number<-c()
  name<-c()
  description<-c()
  testModule<-c()
  test_insertion<-c()
  product_variant<-c()
  
  # limits
  limit_type<-c()
  minimum<-c()
  maximum<-c()
  unit<-c()
  scale<-c()
  
  # binning
  hbin_number<-c()
  hbin_name<-c()
  sbin_number<-c()
  sbin_name<-c()
  
  # requirements
  reqID<-c()
  p_number<-c()
  requirementName<-c()
  requirementProjectId<-c()
  requirementSymbol<-c()
  asil<-c()
  requirementCondition<-c()
  requirementVersion<-c()
  
  for (thisTest in data) {
    for (thisExecution in thisTest$execution) {
      for (thisTestflow in thisExecution$testflows) {
        for (limitType in c("testLimit", "specifiedLimit")) {
          
          if (is.null(thisTestflow[[limitType]])) next
          
          if (is.null(thisTest$number)) test_number[length(test_number)+1]<-NA
          else test_number[length(test_number)+1]<-thisTest$number
          
          if (is.null(thisTest$name)) name[length(name)+1]<-""
          else name[length(name)+1]<-toupper(paste0(thisTest$name, "___", thisTest$number))
          
          if (is.null(thisTest$description)) description[length(description)+1]<-""
          else description[length(description)+1]<-thisTest$description
          
          if (is.null(thisTest$testModule)) testModule[length(testModule)+1]<-""
          else testModule[length(testModule)+1]<-thisTest$testModule
          
          if (is.null(thisTest$unitKind)) unit[length(unit)+1]<-""
          else unit[length(unit)+1]<-thisTest$unitKind
          
          if (is.null(thisTest$unitScale)) scale[length(scale)+1]<-NA
          else scale[length(scale)+1]<-thisTest$unitScale*-1
          
          if (is.null(thisTest$binning$hardBin$number)) hbin_number[length(hbin_number)+1]<-NA
          else hbin_number[length(hbin_number)+1]<-thisTest$binning$hardBin$number
          
          if (is.null(thisTest$binning$hardBin$name)) hbin_name[length(hbin_name)+1]<-""
          else hbin_name[length(hbin_name)+1]<-thisTest$binning$hardBin$name
          
          if (is.null(thisTest$binning$softBin$number)) hbin_number[length(sbin_number)+1]<-NA
          else sbin_number[length(sbin_number)+1]<-thisTest$binning$softBin$number
          
          if (is.null(thisTest$binning$softBin$name)) hbin_name[length(sbin_name)+1]<-""
          else sbin_name[length(sbin_name)+1]<-thisTest$binning$softBin$name
          
          if (is.null(thisExecution$insertionName)) test_insertion[length(test_insertion)+1]<-""
          else test_insertion[length(test_insertion)+1]<-thisExecution$insertionName
          
          if (is.null(thisTestflow$name)) product_variant[length(product_variant)+1]<-""
          else product_variant[length(product_variant)+1]<-thisTestflow$name
          
          if (is.null(thisTestflow$testLimit$lower)) minimum[length(minimum)+1]<-NA
          else minimum[length(minimum)+1]<-ifelse(is.null(thisTest$unitScale), thisTestflow[[limitType]]$lower, thisTestflow[[limitType]]$lower*10^thisTest$unitScale)
          
          if (is.null(thisTestflow$testLimit$upper)) maximum[length(maximum)+1]<-NA
          else maximum[length(maximum)+1]<-ifelse(is.null(thisTest$unitScale), thisTestflow[[limitType]]$upper, thisTestflow[[limitType]]$upper*10^thisTest$unitScale)
              
          if (limitType=="specifiedLimit") {
            limit_type[length(limit_type)+1]<-"spec"
            
            if (is.null(thisTestflow$requirements$primary$apiId)) reqID[length(reqID)+1]<-NA
            else reqID[length(reqID)+1]<-thisTestflow$requirements$primary$apiId
            
            if (is.null(thisTestflow$requirements$primary$documentKey)) p_number[length(p_number)+1]<-""
            else p_number[length(p_number)+1]<-thisTestflow$requirements$primary$documentKey
            
            if (is.null(thisTestflow$requirements$primary$name)) requirementName[length(requirementName)+1]<-""
            else requirementName[length(requirementName)+1]<-thisTestflow$requirements$primary$name
            
            if (is.null(thisTestflow$requirements$primary$projectId)) requirementProjectId[length(requirementProjectId)+1]<-NA
            else requirementProjectId[length(requirementProjectId)+1]<-thisTestflow$requirements$primary$projectId
            
            if (is.null(thisTestflow$requirements$primary$symbol)) requirementSymbol[length(requirementSymbol)+1]<-""
            else requirementSymbol[length(requirementSymbol)+1]<-thisTestflow$requirements$primary$symbol
            
            if (is.null(thisTestflow$requirements$primary$asil)) asil[length(asil)+1]<-""
            else asil[length(asil)+1]<-thisTestflow$requirements$primary$asil
            
            if (is.null(thisTestflow$requirements$primary$condition)) requirementCondition[length(requirementCondition)+1]<-""
            else requirementCondition[length(requirementCondition)+1]<-thisTestflow$requirements$primary$condition
            
            if (is.null(thisTestflow$requirements$primary$version)) requirementVersion[length(requirementVersion)+1]<-NA
            else requirementVersion[length(requirementVersion)+1]<-thisTestflow$requirements$primary$version
          
          } else {
            limit_type[length(limit_type)+1]<-"test"
            reqID[length(reqID)+1]<-NA
            p_number[length(p_number)+1]<-""
            requirementName[length(requirementName)+1]<-""
            requirementProjectId[length(requirementProjectId)+1]<-NA
            requirementSymbol[length(requirementSymbol)+1]<-""
            asil[length(asil)+1]<-""
            requirementCondition[length(requirementCondition)+1]<-""
            requirementVersion[length(requirementVersion)+1]<-NA
          }
        }
      }
    }
  }
  
  limits<-data.frame(test_number=test_number, name=name, description=description, testModule=testModule, test_insertion=test_insertion, product_variant=product_variant,
                     sbin_number=sbin_number, sbin_name=sbin_name, hbin_number=hbin_number, hbin_name=hbin_name,
                     unit=unit, scale=scale, min=minimum, max=maximum, limit_type=limit_type, reqID=reqID, p_number=p_number, requirementName=requirementName,
                     requirementProjectId=requirementProjectId, requirementSymbol=requirementSymbol, asil=asil, requirementCondition=requirementCondition, requirementVersion=requirementVersion)
  
  return(limits)
}
