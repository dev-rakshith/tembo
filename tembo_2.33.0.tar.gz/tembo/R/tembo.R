#' tembo
#' 
#' Tembo package for data analysis
#' \emph{Copyright (c) 2018 Infineon Technologies} 
#' 
#' @docType package
#' @author Tembo Team (Infineon)
#' @import httr ggplot2 jsonlite data.table Rcpp
#' @importFrom Rcpp evalCpp
#' @useDynLib tembo
#' @name tembo
NULL  
