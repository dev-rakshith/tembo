
library(data.table)
#' Create a generic tembo analysis object
#'
#'
#' \emph{Copyright (c) 2019 Infineon Technologies}
#' @return Returns Tembo analysis object
#' @examples 
#' currentAnalysis <- tembo::statInd$new()
#' currentAnalysis$addData(generateTestData()[[1]])
#' groupBy <- c("cond_tambient", "product_variant")
#' currentAnalysis$addGrouping(groupBy)
#' currentAnalysis$setParam("IVS_28V")
#' results <- data.frame()
#' for (datTmp in currentAnalysis$generateSubsets()) {
#' 	resultRow <- list()
#' 	if (length(groupBy) > 0) {
#' 		for (group in groupBy) {
#' 			resultRow[group] <- unique(datTmp[[group]])
#' 		}
#' 	}
#' 	resultRow[["Count"]] <- nrow(datTmp)
#' 	resultRow[["Count_NA"]] <- sum(is.na(datTmp[["IVS_28V"]]))
#' 	results <- rbind(results,as.data.frame(resultRow))
#' }
#' print(results)
#'
#' @family tembo table
#' @author Helena Schmidt \email{schmidt.externel9@@infineon.com}
#' @export temboAnalysis
#' @exportClass temboAnalysis
temboAnalysis <- setRefClass("temboAnalysis",
                       fields = list(data = "data.frame",
                                     limits = "data.table",
                                     parameter = "character",
                                     groups = "vector",
                                     .internalMapping = "list"#mappings like groups and facets
                       ),
                       methods = list(
                         addData = function(expr, param=NULL){
                         	 "Adds data to the analysis object"
                           subsetExpr <- substitute(expr)
                           tryCatch({
                             data <<- eval(expr)
                           },
                           error = function(e) stop("Your data is missing"))
                           if(!is.null(param)){
                           	 parameter <<- param
                           }
                         },
                         addLimits = function(expr, evaluateConditions = FALSE){
                         	 "Adds limits to the analysis object. evaluateConditions = TRUE means that the condition column is evaluated"
                           subsetExpr <- substitute(expr)
                           tryCatch({
                             tmpLimits <- eval(expr)
                             tmpLimits <- subset(tmpLimits, tmpLimits$name == parameter)
                             # backup limits and clean all parameters used for grouping, if they are not varied
                             if("limit_type" %in% colnames(tmpLimits) & !("limit_type" %in% groups)){
                               if(length(unique(tmpLimits$limit_type))>1){
                                 tmpLimits$limit_type[is.na(tmpLimits$limit_type)] <- ""
                                 groups <<- c(groups,"limit_type")
                               }
                             }
                             for (group in groups) {
                             	 if(!is.null(tmpLimits[[group]])){
                             	 	#removes columns without variation
                             	 	 if (length(unique(tmpLimits[[group]])) == 1) {
                             	 	 	 tmpLimits[[group]] <- NULL
                             	 	 }
                             	 }
                             }
                             if(evaluateConditions & !is.null(tmpLimits$condition)){
                             	tmpLimits$parsed_conditions <- lapply(tmpLimits$condition, function(x) {temboCondition(x)})
                             }
                             limits <<- as.data.table(tmpLimits)
                           }, error = function(e) {limits <<- data.table()})
                           if(any(is.character(c(limits$min, limits$max)))){
                             limits$min <<- as.numeric(limits$min)
                             limits$max <<- as.numeric(limits$max)
                           }
                         },
                         filterData = function(expr){
                         	 "Filter data with an R experession inside of the analysis object"
                           subsetExpr <- substitute(expr)
                           tryCatch({
                           	 if(ncol(data) == 1) { #filtering fails if the data frame does only have one column
                           	 	 data$dummy_INTERNAL <<- ""
                           	 }
                             data <<- data[eval(subsetExpr,data),] 
                             if(!is.null(data$dummy_INTERNAL)) {
                             	data$dummy_INTERNAL <<- NULL
                             }
                           },
                           error = function(e) stop("Your data filtering expression does not work"))
                           
                         },
                         filterLimits = function(expr){
                           subsetExpr <- substitute(expr)
                           tryCatch({
                             if(nrow(limits) > 0){
                               limits <<- limits[eval(subsetExpr,limits),]
                               for (group in groups) {
                               	if (length(unique(limits[[group]])) == 1) {
                               		limits[[group]] <<- NULL
                               		if(!(group %in% colnames(data))){
                               		  groups <<- groups[groups != group]
                               		}
                               	}
                               }
                             } else {
                               warning("No limits to filter")
                             }
                           },
                           error = function(e) stop("Your limit filtering expression does not work"))
                         },
                         addGrouping = function(grouping){
                         	 #if(grouping != ""){
                         	 groups <<- grouping
                         	 #}
                           #Done
                         },
                         getGrouping = function(){
                           return(groups)
                         },
                         setParam = function(param){
                           parameter <<- param
                         },
                         #addAnalysisFunction = function(colname, expr){
                         #  subsetExpr <- substitute(expr)
                         #  analysisFunctions[[length(analysisFunctions) + 1]] <<- expr
                         #},
                         #getResult = function(){
                         #  #do the calculations
                         #  return(results)
                         #}
                       generateSubsets = function(dfToSplit = data){
                         "generate subsets of dat in case of grouping is used and do limit handling"
                         if (length(groups) == 0) {
                           datTmp <- dfToSplit
                           if( !is.null(limits)){
                           	if (nrow(limits)>0) {
                           		upperLimit <- as.vector(na.omit(unique(limits$max)))
                           		lowerLimit <- as.vector(na.omit(unique(limits$min)))
                           		
                           		if (length(upperLimit) > 1 || length(lowerLimit) > 1) {
                           			createLimitErrorMessage()
                           		}
                           		if (length(upperLimit) == 0) {
                           			upperLimit <- as.numeric(NA)
                           		}
                           		if (length(lowerLimit) == 0) {
                           			lowerLimit <- as.numeric(NA)
                           		}
                           		
                           		if(!is.null(limits$parsed_conditions)){
                           			datTmp <- filterDataByCondition(limits, datTmp)
                           			if(nrow(datTmp)){
                           				limitName <- sapply(limits$parsed_conditions, function(x) {x$getLimitName()})
                           				datTmp$condition <- paste(limitName, collapse = "|")
                           			}
                           		}
                           		if (nrow(datTmp)) {
                           			datTmp <- cbind(datTmp, UpperLimit = upperLimit)
                           			datTmp <- cbind(datTmp, LowerLimit = lowerLimit)
                           		}
                           		if ("reqID" %in% names(limits)) {
                           			datTmp<-cbind(datTmp, ReqID = paste(unique(limits$reqID),collapse=","))
                           		}
                           		if ("description" %in% names(limits)) {
                           			datTmp<-cbind(datTmp, Description = paste(unique(limits$description),collapse=","))
                           		}
                           		if ("unit" %in% names(limits)) {
                           			datTmp<-cbind(datTmp, Unit = paste(unique(limits$unit),collapse=","))
                           		}
                           		if ("jamaId" %in% names(limits)) {
                           			datTmp<-cbind(datTmp, jamaId = paste(unique(limits$jamaId),collapse=","))
                           		}                
                           	}
                           }
                           if(is.null(datTmp$UpperLimit) & nrow(datTmp)){
                             datTmp$UpperLimit <- NA
                             datTmp$LowerLimit <- NA
                           }
                           dats <- list(datTmp)
                         } else {
                           dats <- list()
                           groupsInDf <- (groups %in% colnames(dfToSplit))
                           limitGroups <- groups[!groupsInDf]
                           if(length(limitGroups)>0){
                             #if there are groups, that which do not exist in the data:
                             #limitGroups <- groups[!groupsInDf]
                             for(limitGroup in limitGroups){
                               i <- 1
                               dfs <- list()
                               groupValues <- unique(limits[[limitGroup]])
                               if(length(groupValues) > 0){
                                 for(groupValue in groupValues){
                                   dfs[[i]] <- dfToSplit
                                   dfs[[i]][limitGroup] <- groupValue
                                   i <- i+1
                                 }
                                 dfToSplit <- as.data.frame(data.table::rbindlist(dfs))
                               } else {
                                 dfToSplit[[limitGroup]] <- ""
                               }
                             }
                           }
                           if( length(groups) == 1) {
                             splittedData <- split(dfToSplit, dfToSplit[,groups])
                           } else if( length( groups ) > 1){
                             splittedData <- split(dfToSplit, as.list(dfToSplit[,groups]))
                           } else {
                             splittedData <- list(dfToSplit)
                           }
                           
                           # remove empty data.frames which are generated, if not all data was measured with the same groups variations
                           splittedData <- subset(splittedData, sapply(splittedData, function(x) nrow(x) > 0))
                           
                           for( datTmp in splittedData) {
                             if (length(limits) > 0) {
                               # get only values of grouping columns that are available in limits table
                               checkGroupsInLimits <- function(group){
                             	   #if a condition is defined for group, it is prioritized over a column with this parameter                    
                               	 if(is.factor(datTmp[1,group])){
                              		 value <- as.character(datTmp[1,group])
                              	 } else {
                              		 value <- datTmp[1,group]
                              	 }
                             		 if(!is.null(limits$parsed_conditions)){
                             			 result <- limits$parsed_conditions[[1]]
                             			 conditionedLimits <- sapply(limits$parsed_conditions, function(x){x$isParameterInCondition(group, value)})
                             		 } else {
                             			 conditionedLimits <- rep(NA,nrow(limits))
                             		 }
                             		 if(group %in% colnames(limits)){
                             		 	 tmpResult <- limits[[group]] == value | is.na(limits[[group]])
                             		 	 conditionedLimits[is.na(conditionedLimits)] <- tmpResult[is.na(conditionedLimits)]
                             		 } else {
                             			 conditionedLimits[is.na(conditionedLimits)] <- TRUE
                             		 }
                               	 return(conditionedLimits)
                               }
                               tmp <- sapply(groups, checkGroupsInLimits)
                               if(is.null(nrow(tmp))) {
                               	 tmp <- all(tmp)
                               } else {
                               	 tmp <- apply(tmp,1,all)
                               }
                               limTmp <- limits[tmp,]
                               upperLimit <- as.vector(na.omit(unique(limTmp$max)))
                               lowerLimit <- as.vector(na.omit(unique(limTmp$min)))

                               if (length(upperLimit) > 1 || length(lowerLimit) > 1) {
                                 createLimitErrorMessage()
                               }
                               if (length(upperLimit) == 0) {
                                 upperLimit <- as.numeric(NA)
                               }
                               if (length(lowerLimit) == 0) {
                                 lowerLimit <- as.numeric(NA)
                               }
                               if(!is.null(limTmp$parsed_conditions)){
                               	 datTmp <- filterDataByCondition(limTmp, datTmp)
                               	 limitName <- sapply(limTmp$parsed_conditions, function(x) {x$getLimitName()})
                               	 datTmp$condition <- paste(limitName, collapse = "|")
                               }
                               if (nrow(datTmp)) {
                                 datTmp <- cbind(datTmp, UpperLimit = upperLimit)
                                 datTmp <- cbind(datTmp, LowerLimit = lowerLimit)
                               }
                               if ("reqID" %in% names(limTmp)) {
                               	datTmp<-cbind(datTmp, ReqID = paste(unique(limTmp$reqID),collapse=","))
                               }
                               if ("description" %in% names(limTmp)) {
                               	datTmp<-cbind(datTmp, Description = paste(unique(limTmp$description),collapse=","))
                               }
                               if ("unit" %in% names(limTmp)) {
                               	datTmp<-cbind(datTmp, Unit = paste(unique(limTmp$unit),collapse=","))
                               }
                               if ("jamaId" %in% names(limTmp)) {
                               	datTmp<-cbind(datTmp, jamaId = paste(unique(limTmp$jamaId),collapse=","))
                               }                
                               
                             }
                             if(is.null(datTmp$UpperLimit)){
                               datTmp$UpperLimit <- NA
                               datTmp$LowerLimit <- NA
                             }
                             dats[[length(dats) + 1]] <- datTmp
                           }
                         }
                         return(dats)
                       }, 
                       createLimitErrorMessage = function(){
                         cnLimits <- colnames(limits)
                         cnDat <- colnames(data)
                         cnDat <- cnDat[!(cnDat %in% groups)]
                         if( any(cnLimits %in% cnDat)){
                           possibleGroups <- cnLimits[cnLimits %in% cnDat]
                           #stop(c(groups,possibleGroups))
                           for(possibleGroup in possibleGroups){
                             if(checkUniqueness(limits,c(groups,possibleGroup))){
                               if(length(groups == 0)){
                                 stop(paste("Selected Limits are not unique, maybe you want to group by "), possibleGroup)      
                               } else {
                                 stop(paste("Selected Limits are not unique, maybe you want to add the group "), possibleGroup)
                               }
                             }
                           }
                           if(length(possibleGroups) > 1 ){
                             if(checkUniqueness(limits,c(groups,possibleGroups))){
                               if(length(groups == 0)){
                                 stop(paste("Selected Limits are not unique, maybe you want to group by "), paste(possibleGroups,collapse=", "))
                               } else {
                                 stop(paste("Selected Limits are not unique, maybe you want to add the groups "), paste(possibleGroups,collapse=", "))
                               }
                             }
                           }
                           if(length(possibleGroups) > 2){
                             stop("Selected Limits are not unique. Please filter out some limits or make better grouping.")    
                           }
                         }
                         stop("Selected Limits are not unique. Please filter out some limits.")
                       }
)
)



checkUniqueness <- function(limits, groups){
  if(length(groups) > 1){
    splittedDat <- split(limits, customInteraction(limits[,groups,with=FALSE]))
  } else if(length(groups) == 1){
    splittedDat <- split(limits, as.factor(limits[[groups]]))
  } else {
    splittedDat <- list()
    splittedDat[[1]] <- limits
  }
  all(unname(sapply(splittedDat, function(x) {max(length(unique(x$min)),length(unique(x$max)))})) <= 1)
}

filterDataByCondition <- function(limits, datTmp){
	if(nrow(limits)==1){
		#datTmp <- limits$parsed_condition$filterDataByCondition(datTmp)
		datTmp <- limits$parsed_condition[[1]]$filterDataByCondition(datTmp)
	} else {
		#Filter out data by all applying conditions and remove duplicated entries later
		datTmp$original_row <- 1:nrow(datTmp)
		newDataList <- lapply(limits$parsed_conditions, function(x){x$filterDataByCondition(datTmp)})
		newDat <- rbindlist(newDataList)
		newDat <- newDat[!duplicated(newDat$original_row),]
		newDat$original_row <- NULL
		datTmp <- newDat
	}
	return(datTmp)
}
	
	