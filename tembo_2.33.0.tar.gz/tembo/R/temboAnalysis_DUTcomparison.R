#' @author Helena Schmidt, \email{schmidt.external9@infineon.com}
#' @export
DUTcomparison <- function(dat, dutVar, comparisonVar,refdutname, smpdutname ){
  colNames <- colnames(dat)
  #make colNames variable filled with all colnames that are not used otherwise
  colNames <- colNames[!colNames %in% c(comparisonVar, dutVar)]
  #split the data by the dutVar before looking for poissible idvar parameters for reshape
  tmpSplitted <- split(dat, dat[[dutVar]])
  tmpSplitted1 <- tmpSplitted[[1]]
  tmpSplitted2 <- tmpSplitted[[2]]
  # fill idCols with all meaningful colums that can be used as idvar in reshape
  idCols <- c()
  for(colN in colNames){
    tmp1 <- unique(tmpSplitted1[[colN]])
    tmp2 <- unique(tmpSplitted2[[colN]])
    if(all(tmp1 %in% tmp2) & all(tmp2 %in% tmp1)){
      #only if all values of the column are present in both DUTs, use the column as idvar
      idCols <- c(idCols, colN)
    }
  }
  #remove temporary data
  rm(tmpSplitted1)
  rm(tmpSplitted2)
  rm(tmpSplitted)
  rm(tmp1)
  rm(tmp2)
  
  #reshape data
  reshaped <- reshape(dat, idvar = idCols, timevar=dutVar, direction = "wide")
  #rm(idColsInteraction)
  cols <- colnames(reshaped)
  #get the column  ids for the new columns that should be compared
  colNumbers <- grep(comparisonVar,cols)
  #calculate the relative error
  #compareTo <- 1
  #what colnumber has the reference DUT?
  refN <- grep(paste0(refdutname, "$"), cols[colNumbers])
  smpN <- grep(paste0(smpdutname, "$"), cols[colNumbers])
  if(smpN[1] == refN[1]){
    stop("Error, sample and reference match the same column, please adjust the sample or reference name.")
  }
  #if idCols has length 1, without data.frame() nrow() would not work
  subDat <- data.frame(dat[grep(paste0(refdutname,"$"), dat[[dutVar]]),c(idCols, comparisonVar)], stringsAsFactors = FALSE)
  subDat <- data.frame(subDat[!duplicated(subDat),idCols], stringsAsFactors = FALSE)
  if ( nrow(subDat) != nrow(unique(subDat)) ){
    stop("Conditions are not unique, could not decide which values to choose")
  }        
  subDat <- data.frame(dat[grep(paste0(smpdutname,"$"), dat[[dutVar]]),c(idCols, comparisonVar)], stringsAsFactors = FALSE)
  subDat <- data.frame(subDat[!duplicated(subDat),idCols], stringsAsFactors = FALSE)
  if ( nrow(subDat) != nrow(unique(subDat)) ){
    stop("Conditions are not unique, could not decide which values to choose")
  }#stop(smpN)
  reshaped$rel_error <- (reshaped[,colNumbers[smpN[1]]]-reshaped[,colNumbers[refN[1]]])/reshaped[,colNumbers[refN[1]]]
  cols <- colnames(reshaped)
  #remove unused columns and fill currentResults table
  currentResults <-reshaped[cols %in% c(idCols, 'rel_error') | grepl(comparisonVar, cols)]
  rm(reshaped)
  return(currentResults) 
}