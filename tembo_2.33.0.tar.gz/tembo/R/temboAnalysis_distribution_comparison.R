#' Create a distribution comparison analysis object
#'
#'
#' \emph{Copyright (c) 2019 Infineon Technologies}
#' @return Returns Tembo Analysis object with distribution comparison functions
#' @family tembo table
#' @author Helena Schmidt \email{schmidt.externel9@@infineon.com}
#' @export distComp
#' @exportClass distComp
distComp <- setRefClass("distComp",
												contains = "temboAnalysis",
                       	fields = list(datRef = "data.frame",
                                     datSmp = "data.frame",
                       							 groups = "vector"
                        ),
                        methods = list(
                         defineSample = function(sample){
                         	 "evaluates the filter expression to define the sample distribution"
                           sampleExpr <- substitute(sample)
                           tryCatch({
                             datSmp <<- data[eval(sampleExpr,data),] 
                           },
                           error = function(e) stop("Your sample filtering expression does not work"))
                           if(is.null(datSmp[[parameter]])) {
                             stop("no sample data available")
                           }
                         },
                         defineReference = function(reference){
                         	"evaluates the filter expression to get the reference distribution"
                           referenceExpr <- substitute(reference)
                           tryCatch({
                             datRef <<- data[eval(referenceExpr,data),] 
                           },
                           error = function(e) stop("Your reference filtering expression does not work"))
                           if(is.null(datRef[[parameter]])) {
                             stop("no reference data available")
                           }
                         },
                         calculateQumat = function(){
                         	"calculate qumat data"
                         	qs <- as.numeric(quantile(datRef[[parameter]], c(0.001,0.005,0.05,0.1,0.25,0.5,0.75,0.9,0.95,0.995,0.999), na.rm=T,names = FALSE))
                         	names(qs) <- c("rq00p1", "rq00p5", "rq05", "rq10", "rq25", "rq50", "rq75", "rq90", "rq95", "rq99p5", "rq99p9")
                         	qumatRef <- data.frame(rsigma = sd(datRef$x))         
                         	qumatRef <- cbind(qumatRef,t(qs))
                         	qumats <- list()
                         	for( sample in generateSubsets(dfToSplit = datSmp)){
                         		qs <- as.numeric(quantile(sample[[parameter]], c(0.001,0.005,0.05,0.1,0.25,0.5,0.75,0.9,0.95,0.995,0.999), na.rm=T,names = FALSE))
                         	  names(qs) <- c("q00p1", "q00p5", "q05", "q10", "q25", "q50", "q75", "q90", "q95", "q99p5", "q99p9")
                         	  qumat <- cbind(qumatRef,t(qs))
                         	  if (length(groups) > 0) {
                         		  for (group in groups) {
                         			  qumat[[group]] <- unique(sample[[group]])
                         		  }
                         	  }
                         	  
                         	  rownames(qumat) <- parameter
                         	  qumat$countSmp <- sum(! is.na(sample[[parameter]]))
                         	  qumat$nlevelsSmp <- nlevels(factor(sample[[parameter]]))
                         	  if(!is.null(limits)){
                         	  	if(nrow(limits) > 0){
                         	  		qumat$lsl <- sample[["LowerLimit"]][1]
                         	  		# upper spec limit
                         	  		qumat$usl <- sample[["UpperLimit"]][1]
                         	  	}
                         	  }
                         		qumats <- c(qumats, list(qumat))
                         	}
                          return(qumats)
                         })
)
  
