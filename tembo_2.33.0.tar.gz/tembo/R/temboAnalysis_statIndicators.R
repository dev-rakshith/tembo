#' Create a statistical Indicators analysis object
#'
#'
#' \emph{Copyright (c) 2019 Infineon Technologies}
#' @return Returns Tembo Analysis object for statistical indicators calculation
#' @seealso \code{\link{temboAnalysis}}
#' @family tembo analysis
#' @author Helena Schmidt \email{schmidt.externel9@@infineon.com}
#' @export statInd
#' @exportClass statInd
statInd <- setRefClass("statInd",
											 contains = "temboAnalysis",
                       fields = list(analysisFunctions = "list",
                                    results = "data.frame"
                       )
)
