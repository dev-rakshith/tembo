#' Create a tembo condition object
#'
#'
#' \emph{Copyright (c) 2019 Infineon Technologies}
#' @return Returns a condition object
#' @family tembo analysis
#' @author Helena Schmidt \email{schmidt.externel9@@infineon.com}
#' @export temboCondition
#' @exportClass temboCondition
temboCondition <- setRefClass("temboCondition",
                         fields = list(condition_data = "data.frame",
                         							 condition_expr = "language",
                                       condition_string = "character",
                                       x_parameter = "character",
                                       y_parameter = "character",
                         							 error_text = "character"
                                       ),
                         methods = list(
                           initialize = function(condition, x = NULL, y  = NULL){
                           	 "initialize condition class, condition is a condition string, x,y are axes parameters to evaluate the conditions for"
                           	 error_text <<- ""
                             tryCatch({
                               condition_string <<- as.character(condition)
                               if(jsonlite::validate(condition_string)){
                               	 condition_data <<- jsonlite::fromJSON(condition_string)
                               } else if(any(grepl("(list\\()|(c\\()|&|\\|", condition_string))){
                               	 condition_expr <<- rlang::parse_expr(condition_string)
                               	 whiteList <- c(">", "<", ">=", "<=","%in%", "==", "!", "(", "&", "|", "-", "c", "list")
                               	 allFunctions <- find_functions(condition_expr)
                               	 #print(allFunctions)
                               	 if(!all( allFunctions %in% whiteList)){
                               	 	 stop(paste("You used the following not allowed functions in your condition:", paste0(allFunctions[!(allFunctions%in%whiteList)],"()",collapse=",")))
                               	 }
                               	 condition_data <<- getGroupedConditions(condition_expr)
                               	 #print(condition_data)
                               } else {
                               	 condition_data <<- parseConditionString(condition_string)
                               }
                               #add more sanity checks!
                             }, error = function(e) {
                             	 error_text <<- paste("Your condition is malformed.", paste(e) )
                             	 print(error_text)
                             	 condition_data <<- data.frame(parameter = c(), operator=c(), value=c(), group=c())
                             })
                           	 if(all(c("parameter","value", "operator") %in% colnames(condition_data))){
                           	 	 #remove wrong columns
                           	 	 if("group" %in% colnames(condition_data)){
                           	 	 	condition_data <<- subset(condition_data, select=c("parameter","operator", "value", "group"))
                           	 	 } else {
                           	 	 	 #if no groups are given, guess groups:
                           	 	 	 condition_data$groups <<- "a"
                           	 	 	 #condition_data$groups[condition_data$operator %in% c(">", "<", ">=", "<=")] <<- "a"
                           	 	 	 #emptyGroups <- which(condition_data$groups == "")
                           	 	 	 #if(length(emptyGroups)>0){
                           	 	 	 #  condition_data$groups[emptyGroups] <<- c(letters,LETTERS)[2:(length(emptyGroups)+1)]
                           	 	 	 #}
                           	 	 }
                           	 	 #remove data with invalid operators
                           	 	 condition_data <<- subset(condition_data, operator %in% c("==", "=", "<=", ">=", "<", ">", "in"))
                           	 } else {
                            	 condition_data <<- data.frame()
                           	 }
                             if(!is.null(x)){
                               if(is.character(x)){
                                 x_parameter <<- x
                               }
                             }
                             if(!is.null(y)){
                               if(is.character(y)){
                                 y_parameter <<- y
                               }
                             }
                           },
                           setAxisParameters = function(x = NULL, y = NULL){
                           	 "set the axes parameters"
                             if(!is.null(x)){
                               if(is.character(x)){
                                 x_parameter <<- x
                               }
                             }
                             if(!is.null(y)){
                               if(is.character(y)){
                                 y_parameter <<- y
                               }
                             }
                           },
                           filterDataByCondition = function(allDat){
                           	 "allDat is a data.frame before filtering the data, and it gets filtered according to the condition defined in this object"
                           	 if(nrow(condition_data)==0){
                           	 	 return(allDat)
                           	 }
                           	 if(ncol(allDat) == 1 ){
                           	 	allDat$dummy <- 1 #prevent data.frame from being coerced to vector
                           	 }

                             localFilterByCondition <- function(dat, thisGroup){
                             	conds <- condition_data[condition_data$parameter %in% colnames(dat),]
                             	conds <- condition_data[condition_data$group == thisGroup,]
                             	if(nrow(conds)==0){
                             		return(dat)
                             	}
                             	tmp_dat <- dat
                             	for(i in 1:nrow(conds)){
                             		 #conds$value is a character. Type converting is done with regard to operator
                             		 if(conds$operator[i] == "=" | conds$operator[i] == "=="){
                             			 tmp_dat <- tmp_dat[as.character(tmp_dat[,conds$parameter[i]]) == conds$value[i],]
                             		 } else if(conds$operator[i] == ">="){
                             			 tmp_dat <- tmp_dat[tmp_dat[,conds$parameter[i]] >= as.numeric(conds$value[i]),]
                             		 } else if(conds$operator[i] == "<="){
                             			 tmp_dat <- tmp_dat[tmp_dat[,conds$parameter[i]] <= as.numeric(conds$value[i]),]
                             		 } else if(conds$operator[i] == ">"){
                             			 tmp_dat <- tmp_dat[tmp_dat[,conds$parameter[i]] > as.numeric(conds$value[i]),]
                             		 } else if(conds$operator[i] == "<"){
                             			 tmp_dat <- tmp_dat[tmp_dat[,conds$parameter[i]] < as.numeric(conds$value[i]),]
                             		 } else if(conds$operator[i] == "in"){
                             		   if(typeof(conds$value[i][[1]]) == "language"){
                             		     mc <- conds$value[i][[1]]
                             		     matchList <- as.character(mc[2:length(mc)])
                             		   } else {
                             		     matchList <- gsub("<comma>", ",", strsplit(conds$value[i], " *, *")[[1]])
                             		   }
                             			 tmp_dat <- tmp_dat[as.character(tmp_dat[,conds$parameter[i]]) %in% matchList,]
                             		 }
                             		 if(nrow(tmp_dat) == 0){
                             			 break
                             	 	 }
                             	 }
                             	 return(tmp_dat)
                             }
                             allDat$condition_original_row <- 1:nrow(allDat)
                             newDataList <- lapply(unique(condition_data$group), function(x){localFilterByCondition(allDat,x)})
                             newDat <- data.table::rbindlist(newDataList)
                             newDat <- newDat[!duplicated(newDat$condition_original_row),]
                             newDat$condition_original_row <- NULL
                             return(newDat)
                           },
                           show = function(){
                           	 print(condition_string)
                           },
                           diffCondition = function(otherCondition, remove_tmp_cols = TRUE){
                           	 if(nrow(condition_data)==0){
                           	 	return(otherCondition$condition_data)
                           	 }
                           	 tmpThisCond <- condition_data
                           	 tmpThisCond$inc_this <- TRUE
                           	 tmpOtherCond <- otherCondition$condition_data
                           	 tmpOtherCond$inc_other <- TRUE
                           	 mergedCond <- merge(tmpThisCond, tmpOtherCond, all=TRUE)
                           	 mergedCond$inc_this[is.na(mergedCond$inc_this)] <- FALSE
                           	 mergedCond$inc_other[is.na(mergedCond$inc_other)] <- FALSE
                           	 diffCond <- mergedCond[xor(mergedCond$inc_this, mergedCond$inc_other),]
                           	 if(remove_tmp_cols){
                           	 	diffCond$inc_this <- NULL
                           	 	diffCond$inc_other <- NULL
                           	 }
                           	 return(diffCond)
                           },
                           getPlotData = function(param){
                           	 "get data relevant for a plot, uses param, x and y data to evaluate"
                           	 if(nrow(condition_data)==0){
                           	 	 return(NULL)
                           	 }
                           	 currentParameterConditions <- subset(condition_data, parameter == param)
                           	 if(nrow(currentParameterConditions)>0){
                           	 	 plotPoints <- c()
                           	 	 ranges <- c()
                           	 	 for(group in unique(currentParameterConditions$group)){
                           	 	   currentConditions <- currentParameterConditions[group == currentParameterConditions$group,]
                           	 	 	 currentPoints <- c()
                           	 		 if(any(currentConditions$operator == "in")){
                           	 		   for( i in which(currentConditions$operator == "in")){
                           	 		     if(typeof(currentConditions$value[i][[1]]) == "language"){
                           	 		       mc <- currentConditions$value[i][[1]]
                           	 		       matchList <- as.character(mc[2:length(mc)])
                           	 		       tmpPoints <- as.character(mc[2:length(mc)])
                           	 		     } else {
                           	 		       listString <- paste(currentConditions$value[i],collapse=",")
                           	 		       tmpPoints <- gsub("<comma>", ",", strsplit(listString, " *, *")[[1]])
                           	 		     }
                           	 		     currentPoints <- c(currentPoints,tmpPoints)
                           	 		   }
                           	 		 }
                           	 		 if(any(currentConditions$operator %in% c("=","=="))){
                           	 			 tmpPoints <- currentConditions$value[currentConditions$operator %in% c("=","==")]
                           	 			 if(length(currentPoints)>0) {
                           	 			 	 currentPoints <- currentPoints[currentPonits %in% tmpPoints]
                           	 			 } else {
                           	 			 	 currentPoints <- tmpPoints
                           	 			 }
                           	 		 }
                           	 		 rangeFrom <- NA
                           	 		 rangeTo <- NA
                           	 		 if(any(currentConditions$operator %in% c("<", "<="))){
                           	 			 rangeTo <- max(as.numeric(currentConditions$value[currentConditions$operator %in% c("<", "<=")]), na.rm=T)
                           	 		 }
                           	 		 if(any(currentConditions$operator %in% c(">", ">="))){
                           	 			 rangeFrom <- min(as.numeric(currentConditions$value[currentConditions$operator %in% c(">", ">=")]), na.rm=T)
                           	 		 }
                           	 		 if((!is.na(rangeTo)|!is.na(rangeFrom)) & (length(currentPoints)>0)){
                           	 		 	 #if points and ranges are defined in one group, remove ranges and use only points within the range
                           	 		 	 if((!is.na(rangeTo)) & is.na(rangeFrom)) {
                           	 		 	 	 currentPoints <- currentPoints[currentPoints <= rangeTo]
                           	 		 	 } else if((!is.na(rangeFrom)) & is.na(rangeTo)) {
                           	 		 	   currentPoints <- currentPoints[currentPoints >= rangeFrom]
                           	 		 	 } else {
                           	 		 	 	 if(rangeTo > rangeFrom){
                           	 		 	 	 	 currentPoints <- currentPoints[currentPoints >= rangeFrom & currentPonits <= rangeTo]
                           	 		 	 	 }
                           	 		 	 }
                           	 		 }
                           	 		 if(!is.na(rangeTo)&!is.na(rangeFrom)) {
                           	 		 	 if(rangeTo < rangeFrom) {
                           	 		 	 	 rangeTo <- NA
                           	 		 	 	 rangeFrom <- NA
                           	 		 	 	 currentPoints <- c()
                           	 		 	 }
                           	 		 }
                           	 		 plotPoints <- c(plotPoints,currentPoints)
                           	 		 ranges <- c(ranges,rangeFrom,rangeTo)
                           	 	 }
                           	 	 if(all(is.na(ranges))){
                           	 		 ranges <- c(NA,NA)
                           	 	 } else if(any(is.na(ranges))){
                           	 		 newRange <- c()
                           	 		 #remove ranges that only consist of two NAs
                           	 		 #TODO add range sanitizer that also merges ranges if necessary
                           	 		 for(i in 1:(length(ranges)/2)){
                           	 			 if(is.na(ranges[i*2])&is.na(ranges[i*2-1])){
                           	 				 newRange <- c(newRange,FALSE,FALSE)
                           	 			 } else {
                           	 				 newRange <- c(newRange,TRUE,TRUE)
                           	 			 }
                           	 		 }
                           	 		 ranges <- ranges[newRange]
                           	 	 }
                           	 	 return(list(points=plotPoints, range=ranges))
                           	 }
                           	 return(NULL)#Adding NULL to a plot does not change the plot
                           },
                           hasConditionForParam = function(param){
                           	 "checks weather a condition is valid for param"
                           	 if(any(condition_data$parameter == param)){
                           	 	 return(TRUE)
                           	 }
                           	 return(FALSE)
                           },   
                           getLimitName = function(groups = c()) {
                           	 if(nrow(condition_data)==0){
                           	   return("")
                           	 }
                           	 if(length(groups)>0){
                           	 	 unGroupedParams <- subset(condition_data, !(parameter %in% groups))
                           	 	 outputString <- ""
                           	 	 for(thisGroup in groups){
                           	 	 	 if(thisGroup %in% condition_data$parameter){
                           	 	 	 	if(nchar(outputString) > 0){
                           	 	 	 		outputString <- paste0(outputString, ";")
                           	 	 	 	}
                           	 	 	 	thisGroup <- subset(condition_data, parameter == thisGroup)
                           	 	 	 	for(i in 1:nrow(thisGroup)){
                           	 	 	 		if(thisGroup$operator[i]%in% c("in", "=", "==")){
                           	 	 	 			outputString <- paste(outputString, thisGroup$value[i])
                           	 	 	 		} else {
                           	 	 	 			outputString <- paste(outputString, paste0(thisGroup$operator[i],thisGroup$value[i]))
                           	 	 	 		}
                           	 	 	 	}
                           	 	 	 }
                           	 	 }
                           	 	 if(nrow(unGroupedParams)>0){
                           	  	 tmpString <- paste(paste(unGroupedParams$parameter,unGroupedParams$operator,unGroupedParams$value),collapse = "; ")
                           	  	 outputString <- paste0(outputString, "; ", tmpString)
                           	 	 }
                           	 	 return(outputString)
                           	 } else {
                           	   paste(paste(condition_data$parameter,condition_data$operator,condition_data$value),collapse = "; ")
                           	 } 
                           },
                           isParameterInCondition = function(param, value) {
                           	 #returns NA if there is no condition for this parameter
                           	 #returns TRUE if the parameter is valid for this condition
                           	 #returns FALSE if the parameter is no valid for this condition
                           	 if(any(condition_data$parameter == param)){
                           	 	 testDat <- data.frame(param = value)
                           	 	 colnames(testDat) <- param
                           	 	 testDat <- filterDataByCondition(testDat)
                           	 	 if(nrow(testDat) > 0){
                           	 	 	 return(TRUE)
                           	 	 } else {
                           	 	 	 return(FALSE)
                           	 	 }
                           	 } else {
                           	 	 return(NA)
                           	 }
                           }

                         )
)

parseConditionString <- function(condition){
	tmp <- strsplit(condition, ",")[[1]]
	newTmp <- as.data.frame(data.table::rbindlist(lapply(tmp,splitSingleCondition)))
	return(newTmp)
}

splitSingleCondition <- function(cond){
	operators <- c("==", "<=", ">=", "=", "<", ">", "%in%")
	for(ops in operators){
		if(grepl(ops,cond)){
			tmp2 <- strsplit(cond, ops)[[1]]
			tmp <- data.frame(parameter=tmp2[1],operator=ops,value=tmp2[2], stringsAsFactors = FALSE)
			tmp$value <- gsub(";", ",", tmp$value)
			tmp$value <- gsub("^ *", "", tmp$value)
			tmp$value <- gsub(" *$", "", tmp$value)
			tmp$value <- gsub("'", "", tmp$value)
			tmp$value <- gsub("\"", "", tmp$value)
			tmp$operator <- gsub("%in%", "in", tmp$operator)
			tmp$parameter <- gsub("^[ \t]*", "", tmp$parameter)
			tmp$parameter <- gsub("[ \t]*$", "", tmp$parameter)
			return(as.data.frame(tmp))
		}  
	}
	return(data.frame())
}


######### Starting R Metaprogramm section ##########
# Read https://adv-r.hadley.nz/expressions.html#ast for a description on the following functions


expr_type <- function(x) {
	if (rlang::is_syntactic_literal(x)) {
		"constant"
	} else if (is.symbol(x)) {
		"symbol"
	} else if (is.call(x)) {
		"call"
	} else if (is.pairlist(x)) {
		"pairlist"
	} else {
		typeof(x)
	}
}
switch_expr <- function(x, ...){
	switch(expr_type(x),
				 ...,
				 stop("Don't know how to handle type", typeof(x), call. = FALSE)
	)
}



find_functions <- function(x) {
	switch_expr(x,
							# Base cases
							constant = ,
							symbol = character(),
							
							# Recursive cases
							pairlist = unlist(sapply(as.list(x), find_functions)),
							call = {
								
								if (length(x) == 1) {
									rlang::as_string(x[[1]])
								} else {
									c(rlang::as_string(x[[1]]),unlist(sapply(as.list(x[2:length(x)]), find_functions)))
								}
							}
	)
}



find_symbols <- function(x) {
	switch_expr(x,
							# Base cases
							constant = character(),
							symbol = as.character(x),
							
							# Recursive cases
							pairlist = unlist(sapply(as.list(x), find_symbols)),
							call = {
								if(length(x)>1){
									unlist(sapply(as.list(x[2:length(x)]), find_symbols))
								} else {
									character()
								}
							}
	)
}

find_constants <- function(x) {
	switch_expr(x,
							# Base cases
							constant = as.character(x),
							symbol = character(),
							
							# Recursive cases
							pairlist = unlist(sapply(as.list(x), find_constants)),
							call = {
								if(rlang::is_call(x, "-")){ #put a unary - to the constant
									if(length(x) == 2){
										if(rlang::is_syntactic_literal(x[[2]])){
											return(paste0("-", as.character(x[[2]])))
										}
									}
									return(character())
								} else if(length(x)>1){
									unlist(sapply(as.list(x[2:length(x)]), find_constants))
								} else {
									character()
								}
							}
	)
}

generate_df <- function(op, param, value){
	if(rlang::is_call(value,"-")){
		tmp <- as.list(value)
		if(rlang::is_syntactic_literal(tmp[[2]])){
			value <- paste0("-", tmp[[2]])
		} else {
			return(data.frame())
		}
	} else {
		value <- value
	}
	#print(value)
	if(op == "%in%") op <- "in"
	df <- data.frame(
		parameter=as.character(param),
		operator=op,
		stringsAsFactors = FALSE
	)
	df$value <- list(value)
	return(df)
}






convertToConditionData <- function(x, group="a") {
  #print("convertToConditionData")
	switch_expr(x,
							# Base cases
							constant = data.frame(),
							symbol = data.frame(),
							
							# Recursive cases
							pairlist = unlist(sapply(as.list(x), function(x) convertToConditionData(x,group))),
							call = {
								if(rlang::is_call(x,c(">", "<", ">=", "<=", "==", "!=", "%in%"))){
									if( (rlang::is_syntactic_literal(x[[3]]) | rlang::is_call(x[[3]],"-")) & is.symbol(x[[2]])){
										df <- generate_df(op = as.character(x[[1]]), param = x[[2]], value = x[[3]])
									} else if( rlang::is_call(x[[3]],"c") | rlang::is_call(x[[3]],"list")){
									  df <- generate_df(op = as.character(x[[1]]), param = x[[2]], value = x[[3]])
									  #print(df)
									} else if( (rlang::is_syntactic_literal(x[[2]]) | rlang::is_call(x[[2]],"-")) & is.symbol(x[[3]])){
										op <- as.character(x[[1]])
										#normalize order of parameter and comparison value
										if(op == "<"){
											op <- ">"
										} else if(op == ">"){
											op <- "<"
										} else if(op == ">="){
											op <- "<="
										} else if(op == "<="){
											op <- ">="
										}
										df <- generate_df(op = op, param = x[[3]], value = x[[2]])
									}
									df$group <- group
									df
								} else if(rlang::is_call(x,"|")){
									data.table::rbindlist(
										mapply(convertToConditionData,
													 as.list(x),
													 paste0(group,groupLetters(length(x))),
													 SIMPLIFY = FALSE
										)
									)
								} else {
									data.table::rbindlist(lapply(as.list(x), function(x) convertToConditionData(x,group)))
								}
							}
	)
}


groupLetters <- function(x){
	c(letters,LETTERS)[1:x]
}
pyZip <- function(x,y){
	mapply(list,x,y,SIMPLIFY = FALSE)
}


getGroupedConditions <- function(x_expr){
	parsedConditions <- convertToConditionData(x_expr)
	#print(parsedConditions)
	newGroups <- list()
	for(i in 1:nrow(parsedConditions)){
		newGroups[[i]] <- grepl(paste0(parsedConditions$group[i],".+"),parsedConditions$group)
	}
	tmpDf <- as.data.frame(newGroups,col.names = 1:nrow(parsedConditions))
	allNewGroups <- list()
	count <- 1
	for(i in 1:ncol(tmpDf)){
		if(any(tmpDf[,i])){
			next
		} else {
			groupEntries <- c(i,which(t(tmpDf[i,])))
			thisDf <- parsedConditions[groupEntries,]
			thisDf$group <- thisDf$group[1]
			allNewGroups[[count]] <- thisDf
			count <- count + 1
		}
	}
	data.table::rbindlist(allNewGroups)
}
