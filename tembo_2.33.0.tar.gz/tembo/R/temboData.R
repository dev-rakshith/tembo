############################################################################################
#' Tembo data class
#'
#' \emph{Copyright (c) 2019 Infineon Technologies}
#' @export temboData
#' @exportClass temboData
#' @author Kunze Matthias (IFAG ATV PTP MSF DM), \email{matthias.kunze2@infineon.com}
temboData <- setRefClass("temboData",
                         
                         ############################################################################################
                         # Properties
                         ############################################################################################
                         fields = c("baseUrl", "temboBaseUrl", "index", "baseUrlWithoutIndex", "mappingFileShare", "extended_stats_data", "queries", "timeout", "user", "password", "encrypted_password", "filter", "queryBody", "mappingIDs", "failedQueries"),
                         
                         ############################################################################################
                         # Methods
                         ############################################################################################
                         methods = list(
                           
                           initialize = function(index=NA, timeout=1800, user=NA, password=NA, mappingIDs=c(), temboBaseUrl=NA, mappingFileShare=NA, baseUrl='https://vihxs050.vih.infineon.com:9200') {
                             "Constructor"
                             extended_stats_data<<-list()
                             queries<<-data.frame()
                             queryBody <<- ""
                             timeout<<-timeout
                             index<<-index
                             mappingIDs<<-mappingIDs
                             temboBaseUrl<<-temboBaseUrl
                             mappingFileShare<<-mappingFileShare
							 
                             # Container to build up xml node while adding filters
                             # needed in processing of embedded code in report template
                             filter<<-XML::newXMLNode("filters")
                             
                             if (is.na(index)) {
                               baseUrl<<-baseUrl
                               baseUrlWithoutIndex<<-baseUrl
                             } else {
                               baseUrl<<-paste0(baseUrl, index)
                               baseUrlWithoutIndex<<-baseUrl
                             }
                             
                             # provide user credentials globally
                             user<<-user
                             password<<-password
                           },
                           
                           copy = function (...)
                           {
                             "specialized copy function to copy an object instead of referencing it"
                             # Call standard copy method
                             value=callSuper(...)
                             
                             # Clone XML filter
                             value$filter=XML::xmlClone(value$filter, recursive = TRUE)
                             
                             value
                           },
                           
                           addQuery = function (query, group = "") {
                             "add query"
                             
                             queries<<-rbind(queries, data.frame(query=query, group=group))
                             
                             # Clear extended stats cache
                             extended_stats_data<<-list()
                           },
                           
                           addMatchQuery = function (field, value, group = "") {
                             'Add match query. Everything in one group gets ANDed, and the groupes are ORed. The empty group is ANDed to all other groups.'
                             #print("addedMatchQuer")
                             queries<<-rbind(queries,
                                             data.frame(query=paste0('{"match": {"', field,'": "', value, '"}}'),
                                                        group=group))
                             
                             # Clear extended stats cache
                             extended_stats_data<<-list()
                           },
                           
                           addWildcardQuery = function (field, value, group = "") {
                             "Adds wildcard query"
                             #print("addedWildcardQuery")
                             queries<<-rbind(queries,
                                             data.frame(query=paste0('{"wildcard": {"', field,'": "', value, '"}}'),
                                                        group=group))
                             
                             # Clear extended stats cache
                             extended_stats_data<<-list()
                           },
                           
                           addTermsQuery = function (field, values, group = "") {
                             "Add a terms query"
                             
                             # Remove already existing queries for the same field if they are in the same group
                             if (nrow(queries)) {
                               # Clean up data table
                               groupTemp<-group
                               if (group=="") {
                                 queries<<-subset(queries, !(grepl(paste0('\\{"terms": \\{"', field,'":'), queries$query)))
                                 # Clean up XML
                                 XML::xpathApply(filter, paste0('//filter[field="', field,'"][filterType="MultiSelect"]'), function(node) XML::removeNodes(node))
                               } else {
                                 queries<<-subset(queries, !(grepl(paste0('\\{"terms": \\{"', field,'":'), queries$query) & groupTemp==queries$group))
                                 # Clean up XML
                                 XML::xpathApply(filter, paste0('//filter[field="', field,'"][filterType="MultiSelect"][@groupIndex="', group, '"]'), function(node) XML::removeNodes(node))
                               }
                             }
                             
                             #print("addedTermsQuery")
                             queries<<-rbind(queries,
                                             data.frame(query=paste0('{"terms": {"', field,'": [', paste(paste0("\"", values, "\""), collapse = ", "), ']}}'),
                                                        group=group))
                             
                             # Keep track in filter xml
                             if (group=="") {
                               xmlAttrs <- NULL
                             } else {
                               xmlAttrs <- c(groupIndex=group)
                             }
                             node<-XML::addChildren(filter, XML::newXMLNode("filter", attrs = xmlAttrs,
                                                                            XML::newXMLNode("field", field),
                                                                            XML::newXMLNode("name"),
                                                                            XML::newXMLNode("filterType", "MultiSelect"),
                                                                            XML::newXMLNode("filterOperator"),
                                                                            XML::newXMLNode("filterUnit"),
                                                                            XML::newXMLNode("filterValues", sapply(values, function(x) XML::newXMLNode('filterValue', x)))))
                             
                             # Clear extended stats cache
                             extended_stats_data<<-list()
                           },
                           
                           addRangeQuery = function (field, gte=NA, gt=NA, lte=NA, lt=NA, group = "") {
                             "Add a range query"
                             
                             thisQuery<-paste0('{"range": {"', field,'": {')
                             
                             if (!is.na(gte)) thisQuery<-paste0(thisQuery, '"gte": ', gte, ',')
                             if (!is.na(gt))  thisQuery<-paste0(thisQuery, '"gt": ',  gt,  ',')
                             if (!is.na(lte)) thisQuery<-paste0(thisQuery, '"lte": ', lte, ',')
                             if (!is.na(lt))  thisQuery<-paste0(thisQuery, '"lt": ',  lt,  ',')
                             
                             if (!is.na(gte) | !is.na(gt) | !is.na(lte) | !is.na(lt)) thisQuery<-substr(thisQuery, 1, nchar(thisQuery)-1)
                             
                             thisQuery<-paste0(thisQuery, '}}}')
                             
                             queries<<-rbind(queries,
                                             data.frame(query=thisQuery,
                                                        group=group))
                             
                             
                             # Clear extended stats cache
                             extended_stats_data<<-list()
                             # Keep track in filter xml
                             if (group=="") {
                               xmlAttrs <- NULL
                             } else {
                               xmlAttrs <- c(groupIndex=group)
                             }
                           
                             for(i in c('gte', 'gt', 'lte', 'lt')) {
                               if(!is.na(eval(parse(text=i))))
                               {
                                 node<-XML::addChildren(filter, XML::newXMLNode("filter", attrs = xmlAttrs,
                                                                                XML::newXMLNode("field", field),
                                                                                XML::newXMLNode("name"),
                                                                                XML::newXMLNode("filterType", "Decimal"),
                                                                                XML::newXMLNode("filterOperator", toupper(i)),
                                                                                XML::newXMLNode("filterUnit"),
                                                                                XML::newXMLNode("filterValues", sapply(eval(parse(text=i)), function(x) XML::newXMLNode('filterValue', x)))))
                               }
                              }
                             
                           },
                           addTimeWithinQuery = function (field, seconds, group = "") {
                             "Filter field for within the last n seconds"
                             
                             thisQuery<-paste0('{"range": {"', field,'": {')
                             
                             thisQuery<-paste0(thisQuery, '"gte": ', as.integer(Sys.time()-seconds), ',')

                             thisQuery<-substr(thisQuery, 1, nchar(thisQuery)-1)
                             
                             thisQuery<-paste0(thisQuery, '}}}')
                             
                             queries<<-rbind(queries,
                                             data.frame(query=thisQuery,
                                                        group=group))
                             
                             
                             # Clear extended stats cache
                             extended_stats_data<<-list()
                             # Keep track in filter xml
                             if (group=="") {
                               xmlAttrs <- NULL
                             } else {
                               xmlAttrs <- c(groupIndex=group)
                             }
                             
                             node<-XML::addChildren(filter, XML::newXMLNode("filter", attrs = xmlAttrs,
                                                                            XML::newXMLNode("field", field),
                                                                            XML::newXMLNode("name"),
                                                                            XML::newXMLNode("filterType", "DateTime"),
                                                                            XML::newXMLNode("filterOperator", "Within"),
                                                                            XML::newXMLNode("filterUnit", "seconds"),
                                                                            XML::newXMLNode("filterValues", sapply(c(seconds), function(x) XML::newXMLNode('filterValue', x)))))
                         
                           },
                           addDateBetweenQuery = function (field, startDate, endDate, group = "") {
                             "Add a time between query, use dates as strings in format '2021-03-04'"
                             
                             thisQuery<-paste0('{"range": {"', field,'": {')
                             
                             thisQuery<-paste0(thisQuery, '"gte": ', as.integer(as.POSIXct(startDate)), ',')
                             thisQuery<-paste0(thisQuery, '"lte": ', as.integer(as.POSIXct(endDate)), ',')
                             
                             thisQuery<-substr(thisQuery, 1, nchar(thisQuery)-1)
                             
                             thisQuery<-paste0(thisQuery, '}}}')
                             
                             queries<<-rbind(queries,
                                             data.frame(query=thisQuery,
                                                        group=group))
                             
                             
                             # Clear extended stats cache
                             extended_stats_data<<-list()
                             # Keep track in filter xml
                             if (group=="") {
                               xmlAttrs <- NULL
                             } else {
                               xmlAttrs <- c(groupIndex=group)
                             }
                             
                             node<-XML::addChildren(filter, XML::newXMLNode("filter", attrs = xmlAttrs,
                                                                            XML::newXMLNode("field", field),
                                                                            XML::newXMLNode("name"),
                                                                            XML::newXMLNode("filterType", "DateTime"),
                                                                            XML::newXMLNode("filterOperator", "Between"),
                                                                            XML::newXMLNode("filterUnit"),
                                                                            XML::newXMLNode("filterValues", sapply(c(startDate,endDate), function(x) XML::newXMLNode('filterValue', x)))))
                             
                           },
                           
                           buildQuery = function(fieldNames = NULL) {
                             "build the query"
                             query<-'"query": { "bool": {"must": [ '
                             if(nrow(queries)>0){
                               emptyGroups <- subset(queries, group == "")
                               groupQueries <- subset(queries, group != "")
                               #The default group is the empty string.
                               if(length(unique(groupQueries$group)) == 1) { #one group is aequivalent to no groups at all
                                 emptyGroups <- queries
                                 groupQueries <- data.frame()
                               }
                               if(nrow(emptyGroups) > 0){
                                 for (thisQuery in emptyGroups$query) {
                                   query<-paste0(query, thisQuery, ',')
                                 }
                               }
                               
                               if(nrow(groupQueries) > 1) {
                                 #Add should query in which each group is a must query
                                 query<-paste0(query,'{ "bool": {"should": [')
                                 for(thisQueries in split(groupQueries$query, groupQueries$group)){
                                   if(length(thisQueries) > 0){#not sure why split generates empty lists
                                     query <- paste0(query,'{ "bool": {"must": [ ')
                                     for (thisQuery in thisQueries) {
                                       query<-paste0(query, thisQuery, ',')
                                     }
                                     query<-substr(query, 1, nchar(query)-1)   # Remove last comma
                                     query<-paste0(query,']}},')
                                     
                                   }
                                 }
                                 query<-substr(query, 1, nchar(query)-1)   # Remove last comma
                                 query<-paste0(query,']}},')
                               }
                             }
                             
                             if(any(grep("^payload.*",fieldNames))){
                               query<-paste0(query, '{"bool": {"should": [')
                               for( fieldName in fieldNames){
                                 # In combination with wildcards, exist leads to a "too_many_clauses" error in Elastic
                                 # --> only use exist if no wildcard is present
                                 if (!grepl('\\*', fieldName) & grepl("^payload.*",fieldName)) {
                                   query<-paste0(query, '{
       									"exists" : { "field" : "', fieldName, '" }
 					}', ',')
                                 }
                               }
                               query<-substr(query, 1, nchar(query)-1)   # Remove last comma
                               query<-paste0(query, ']}},')
                             }
                             query<-substr(query, 1, nchar(query)-1)   # Remove last comma
                             query<-paste0(query, ']}}')
                             
                             return(query)
                           },
                           
                           getFieldNames = function(method="payloadStructureTable") {
                             "Get field names in scope"
                             
                             if (method=="payloadStructureTable") {
                               
                               fieldNames<-getFieldNamesFromPayloadStructureTable()
                               
                               # Fallback to painless
                               if (!length(fieldNames)) return(getFieldNamesWithPainless())
                               
                               return(fieldNames)
                               
                             } else if (method=="painless") {
                               return(getFieldNamesWithPainless())
                             } else {
                               return(getFieldNamesFromFirst100())
                             }
                           },
                           
                           getFieldNamesWithPainless = function() {
                             "Get field names in scope with elastic search painless"
                             ####################################
                             # Prepare scripted metric aggregation
                             # https://www.elastic.co/guide/en/elasticsearch/reference/current/search-aggregations-metrics-scripted-metric-aggregation.html
                             ####################################
                             body<-paste0('{',
                                          buildQuery(), ',
        "size": 0,
        "sort": ["_doc"],
        "aggs": {
          "data": {
            "scripted_metric": {
              "init_script": "
/*##########################################################################################################*/
/* Init script: Executed prior to any collection of documents                                               */
/*##########################################################################################################*/

/*----------------------------------------------------------------------------------------------------------*/
/* Hash set in order to always have a list with unique values                                               */
/*----------------------------------------------------------------------------------------------------------*/
state.fieldnames = new HashSet();

/*----------------------------------------------------------------------------------------------------------*/
/* For ATE: keep track of already analysed datasets                                                         */
/*----------------------------------------------------------------------------------------------------------*/
state.dataset_id = [];
",

              "map_script": "
/*##########################################################################################################*/
/* Map script: Executed once per document collected                                                         */
/*##########################################################################################################*/

/*----------------------------------------------------------------------------------------------------------*/
/* ATE domain has very wide documents, which all have the same fieldnames in one dataset                    */
/* --> If in ATE domain a document of a dataset has been already analysed, the rest is skipped              */
/*----------------------------------------------------------------------------------------------------------*/
if (!(params._source.metaData.generator_domain==\'ATE\' && state.dataset_id.contains(params._source.metaData.dataset_id))) {

  /*----------------------------------------------------------------------------------------------------------*/
  /* If the current document is ATE domain and not a limit, remember the dataset_id as already analysed       */
  /*----------------------------------------------------------------------------------------------------------*/
  if (params._source.metaData.generator_domain==\'ATE\' && params._source.metaData.data_object_type!=\'limit\')
    state.dataset_id.add(params._source.metaData.dataset_id);

  /*----------------------------------------------------------------------------------------------------------*/
  /* Add metaData and payload fieldnames to list for this shard                                               */
  /*----------------------------------------------------------------------------------------------------------*/
  for(fieldname in params._source.metaData.keySet()) state.fieldnames.add(\'metaData.\'+fieldname);
  for(fieldname in params._source.payload.keySet())  state.fieldnames.add(\'payload.\' +fieldname);
}
",

              "combine_script": "
/*##########################################################################################################*/
/* Combine script: Executed once on each shard after document collection is complete                        */
/*##########################################################################################################*/
return state.fieldnames.toString();
",

              "reduce_script": "
/*##########################################################################################################*/
/* Reduce script: Executed once on the coordinating node after all shards have returned their results       */
/*##########################################################################################################*/

/* FIXME: Due to toString() in the combine_script, unifying via HashSet does not work here anymore          */
/* As a workaround a unique is added in the R part                                                          */

HashSet results=new HashSet();

/*----------------------------------------------------------------------------------------------------------*/
/* Combine results from all shards                                                                          */
/*----------------------------------------------------------------------------------------------------------*/
for (resultsFromShard in states) results.add(resultsFromShard);

/*----------------------------------------------------------------------------------------------------------*/
/* Return unique list                                                                                       */
/*----------------------------------------------------------------------------------------------------------*/
return results;
"
            }
          }
        }
      }')
                             
                             # Cleanup JSON --> newline not allowed inside string
                             body<-gsub('\\n', ' ', body)
                             queryBody <<- body
                             ####################################
                             # Execute in Elastic
                             ####################################
                             if (is.na(password)) {
                               response <- httr::POST(paste0(baseUrl, '/_search'), body = body,
                                                      httr::authenticate(user, getPassword()),
                                                      httr::config(ssl_verifypeer=0L),
                                                      httr::timeout(timeout),
                                                      httr::content_type_json())
                             } else {
                               response <- httr::POST(paste0(baseUrl, '/_search'), body = body,
                                                      httr::authenticate(user, password),
                                                      httr::config(ssl_verifypeer=0L),
                                                      httr::timeout(timeout),
                                                      httr::content_type_json())
                             }
                             res <- httr::content(response)
                             
                             ####################################
                             # Check for errors
                             ####################################
                             if ('error' %in% names(res)) stop(paste0('\nReason:\n', res$error$reason, '\n\nRoot cause:\n', res$error$root_cause))
                             
                             # Remove whitespaces, [, ] and then split at ,
                             return(unique(unlist(strsplit(stringr::str_replace_all(res$aggregations$data$value, '\\s|\\[|\\]', ''), ','))))
                           },

getFieldNamesFromFirst100 = function() {
  "Get field names in scope limits to 100 entries"
  
  # Method: query top 100 documents and get unique field names
  
  ####################################
  # Prepare data fetching
  ####################################
  body<-paste0('{',
               buildQuery(), ',
        "_source": ["metaData.*", "payload.*"],
        "sort": ["_doc"],
        "size":100
      }')
  queryBody <<- body
  ####################################
  # Execute in Elastic
  ####################################
  if (is.na(password)) {
    response <- httr::POST(paste0(baseUrl, '/_search'), body = body,
                           httr::authenticate(user, getPassword()),
                           httr::config(ssl_verifypeer=0L),
                           httr::timeout(timeout),
                           httr::content_type_json())
  } else {
    response <- httr::POST(paste0(baseUrl, '/_search'), body = body,
                           httr::authenticate(user, password),
                           httr::config(ssl_verifypeer=0L),
                           httr::timeout(timeout),
                           httr::content_type_json())
  }
  res <- httr::content(response)
  fieldNames<-unique(unlist(lapply(res$hits$hits, function(x) c(paste0('metaData.', names(x$`_source`$metaData)), paste0('payload.', names(x$`_source`$payload))))))
  
  return(fieldNames)
},

getFieldNamesFromPayloadStructureTable = function() {
  "Get field names in scope from payload structure table"
  
  # Get unique payload_structure_ids
  structure_ids<-getUniqueFieldValues('metaData.payload_structure_id')
  
  # Fetch fieldnames for payload_structure_ids
  structDat<-tembo::temboData(index=index, user=user, baseUrl=baseUrlWithoutIndex)
  structDat$addTermsQuery("payload_structure.id", structure_ids)
  fieldsDat<-structDat$getData("payload_structure.fields")
  
  # Get unique field names
  fieldNames<-unique(unlist(fieldsDat$structure_fields))  
  
  # Fallback if no metaData included: this happens with early, outdated structure_fields table
  if (is.character(fieldNames)) if (!any(startsWith(fieldNames, "metaData."))) {
    warning("No metaData found, fallback to painless solution")
    return(getFieldNamesWithPainless())
  }
  
  # Prepend "payload."
  fieldNames<-unlist(lapply(fieldNames, function(x) if(!startsWith(x, 'metaData.') && !startsWith(x, 'payload.')) paste0('payload.', x) else x))  
  
  return(fieldNames)
},

getData = function (fieldNames, useArrayMode=TRUE) {
  "Download data from Elastic"
  
  fieldNames <- unique(fieldNames)
  if (length(mappingIDs) != 0) {
    return(getDataWithMapping(fieldNames, useArrayMode))
  } else {
    if (useArrayMode==TRUE) {
      return(getDataWithArrayMode(fieldNames))
    } else {
      return(getDataWithScrollMode(fieldNames))
    }
  }
},

getMappingFromDatabase = function (mappingID){
  response<-httr::GET(paste0(temboBaseUrl, '/api/mapping/GetMapping?MappingId=', mappingID),
                      #httr::authenticate(user, getPassword()),
                      httr::authenticate("", "", "ntlm"),
                      httr::config(ssl_verifypeer=0L),
                      httr::content_type_json())
  
  if (response$status_code!=200) stop(paste0('Mapping could not be loaded\n\nHttp response:\n', httr::content(response, type = "text")))
  content<-httr::content(response)
  if (content$Message=="null" | !content$Successful) stop(paste0('Mapping could not be loaded\n\nHttp response:\n', httr::content(response, type = "text")))
  
  return(jsonlite::fromJSON(content$Message))
},

getDataWithMapping = function (commonFieldNames, useArrayMode) {
  "Load mapping for selected data"
  commonNames <- grepl("^commonName\\.", commonFieldNames)
  additionalFieldNames <- commonFieldNames[!commonNames]
  commonFieldNames <- commonFieldNames[commonNames]
  
  if (exists("recipeID")) {
    # Load cached mapping data from RDS file (scheduler mode)
    mappingTable <- tembo::loadTemboMapping(mappingIDs, useCache=TRUE, initCache=FALSE, mappingFileShare=mappingFileShare, temboBaseUrl=temboBaseUrl)
  } else {
    mappingTable <- tembo::loadTemboMapping(mappingIDs, useCache=FALSE, initCache=FALSE, mappingFileShare=mappingFileShare, temboBaseUrl=temboBaseUrl)
  }
  
  # Get mappings for the selected parameters
  thisMappings <- mappingTable[mappingTable$CommonName%in%gsub('commonName\\.', '', commonFieldNames),]
  
  dat<-data.frame()
  failedQueries<<-data.frame(elasticQuery=c(), mappingLine=c())
  if (nrow(thisMappings) > 0) {
    
    # Load data and apply mapping
    queriesBCK<-queries
    for (i in 1:nrow(thisMappings)) {
      
      thisMapping<-sapply(thisMappings[i,], function(c) unlist(c))
      
      # Add specific filters
      if(!is.null(thisMapping$Filters)) {
        if(length(thisMapping$Filters) > 0) {
          queries<<-queriesBCK
          for (ii in 1:length(thisMapping$Filters)) {
            splitted<-unlist(strsplit(thisMapping$Filters[[ii]], split = ','))
            addTermsQuery(splitted[1], splitted[2])
          }
        }
      }
      
      # Fetch data and in case of an error, store affected queries
      fieldNames<-c(unlist(thisMapping$SourceFields), additionalFieldNames)
      delayedAssign("do.next", { next })
      tryCatch({
        # resolve wildcards and add real field names
        fieldNames<-unique(c(grep("^metaData\\..*\\*", fieldNames, value=TRUE, invert=TRUE), unlist(lapply(grep("^metaData\\..*\\*", fieldNames, value=TRUE), function(x) grep(x, getFieldNames(), value=TRUE)))))
        if (useArrayMode==TRUE) {
          dat_tmp<-getDataWithArrayMode(c('metaData.dataset_id', fieldNames))
        } else {
          dat_tmp<-getDataWithScrollMode(c('metaData.dataset_id', fieldNames))
        }
      }, error=function(e) {
        failedQueries<<-rbind(failedQueries, data.frame(elasticQuery=queryBody, mappingLine=as.character(jsonlite::toJSON(thisMapping))))
        force(do.next)
      })
      if(nrow(dat_tmp)==0) {
        failedQueries<<-rbind(failedQueries, data.frame(elasticQuery=queryBody, mappingLine=as.character(jsonlite::toJSON(thisMapping))))
        next
      }
      
      # Rename columns
      if(length(thisMapping$Mappings) > 0) {
        for (ii in 1:length(thisMapping$Mappings)) {
          splitted<-unlist(strsplit(thisMapping$Mappings[ii], split=','))
          source<-splitted[1]
          target<-splitted[2]
          names(dat_tmp)[names(dat_tmp) == source]<-target
        }
      }
      
      # Apply formulas
      if(length(thisMapping$Formulas) > 0) {
        for (ii in 1:length(thisMapping$Formulas)) {
          if (!identical(thisMapping$Formulas[[ii]], character(0))) {
            evaluate::try_capture_stack(parse(text=thisMapping$Formulas[[ii]]), env=environment())
          }
        }
      }
      
      # Add extra columns
      if(length(thisMapping$ExtraColumns) > 0) {
        for (ii in 1:length(thisMapping$ExtraColumns)) {
          splitted<-unlist(strsplit(thisMapping$ExtraColumns[ii], split=','))
          name<-splitted[1]
          value<-splitted[2]
          suppressWarnings(if (!is.na(as.numeric(value))) value<-as.numeric(value))
          dat_tmp[,name]<-value
        }
      }
      
      dat<-rbind(dat, dat_tmp, fill=TRUE)
    }
    
    # Reset queries
    queries<<-queriesBCK
  }
  
  return(dat)
},

getDataWithArrayMode = function (fieldNames, convertToNumeric=TRUE) {
  "Download data from Elastic using scroll mode"
  ####################################
  # Prepare scripted metric aggregation
  # https://www.elastic.co/guide/en/elasticsearch/reference/current/search-aggregations-metrics-scripted-metric-aggregation.html
  ####################################
  
  mapScript<-'"def thisValues=[];
for (fieldName in params.fieldNames) {
  try {
    if (doc[fieldName].isEmpty()) {
      thisValues.add(\'<NA>\');
    } else {
      if (doc[fieldName].length > 1) {
        thisValues.add(String.join(\'%|%\', doc[fieldName]));
        if (!state.listCols.contains(fieldName)) state.listCols.add(fieldName);
      } else {
        thisValues.add(doc[fieldName].value);
      }
    }
  } catch (Exception e) {
    thisValues.add(\'<NA>\');
  }
}
state.values.add(thisValues)"'

reduceScript<-'"def results=[]; def listCols=[]; def hMap=new HashMap();
for (resultsFromShard in states) {
  listCols.addAll(resultsFromShard[\'listCols\']);
  results.addAll(resultsFromShard[\'values\']);
}
hMap.put(\'listCols\', listCols);
hMap.put(\'values\', results);
return hMap;"'

body<-paste0('{',
             buildQuery(fieldNames), ',
        "size": 0,
        "sort": ["_doc"],
        "aggs": {
          "data": {
            "scripted_metric": {
              "params": {
                "fieldNames": [', paste0(sapply(fieldNames, function(x) paste0('"', x, '"')), collapse = ", "), ']
              },
              "init_script": "state.values=[]; state.listCols=[];",
              "map_script": ', gsub('\\n', ' ', gsub("\\s+", " ", mapScript)), ',
              "combine_script": "return state;",
              "reduce_script": ', gsub('\\n', ' ', gsub("\\s+", " ", reduceScript)), '
            }
          }
        }
      }')

####################################
# Execute in Elastic
####################################
queryBody <<- body
if (is.na(password)) {
  response <- httr::POST(paste0(baseUrl, '/_search'), body = body,
                         httr::authenticate(user, getPassword()),
                         httr::config(ssl_verifypeer=0L),
                         httr::timeout(timeout),
                         httr::content_type_json())
} else {
  response <- httr::POST(paste0(baseUrl, '/_search'), body = body,
                         httr::authenticate(user, password),
                         httr::config(ssl_verifypeer=0L),
                         httr::timeout(timeout),
                         httr::content_type_json())
}
res <- httr::content(response)

####################################
# Check for errors
####################################
if ('error' %in% names(res)) stop(paste0('\nReason:\n', res$error$reason, '\n\nRoot cause:\n', res$error$root_cause))

####################################
# Return empty data frame in case of no results
####################################
if ("value" %in%  names(res$hits$total)) {
  if (!res$hits$total$value) return(data.frame())
} else {
  if (!res$hits$total) return(data.frame())
}

####################################
# Convert to data.frame
####################################
dat <- data.table::rbindlist(res$aggregations$data$value$values)
colnames(dat) <- gsub('payload.|metaData.', '', fieldNames)

# if needed, convert appropriate columns to columns of type list (sep = '%|%')
listCols <- gsub('payload.|metaData.', '', unique(unlist(res$aggregations$data$value$listCols)))
if (length(listCols) > 0) {
  for (listCol in listCols) {
    dat[[listCol]] <- strsplit(dat[[listCol]], "%|%", fixed=TRUE)
  }
}

####################################
# Replace NA placeholder with real NA
####################################
dat[dat=='<NA>'] <- NA

####################################
# Convert to numeric if possible
####################################
if (convertToNumeric) {
  suppressWarnings({
    for (name in names(dat)) {
      if (!class(dat[[name]]) == "list" && !anyNA(as.numeric(dat[[name]][!is.na(dat[[name]]) & dat[[name]]!=""]))) {
        dat[[name]]<-as.numeric(dat[[name]])
      }
    }
  })
}

####################################
# Normalize colnames of dat:
####################################
newColnames <- gsub("[^(a-zA-Z0-9_)]","_",colnames(dat))
tmpDuplicates <- duplicated(newColnames) #in case some colnames are now duplicated
newColnames[tmpDuplicates] <- paste0(newColnames[tmpDuplicates],"_",1:sum(tmpDuplicates))
colnames(dat) <- newColnames

return(dat)
},

getDataWithScrollMode = function (fieldNames, scroll_window_size=100000, convertToNumeric=TRUE, max_scroll_pages = Inf) {
  "Download data from Elastic using scroll mode"
  ####################################
  # Prepare data fetching
  ####################################
  body<-paste0('{',
               buildQuery(fieldNames), ',
        "_source": [', paste0(sapply(fieldNames, function(x) paste0('"', x, '"')), collapse = ", "), '],
        "sort": ["_doc"],
        "size": ', scroll_window_size,'
      }')
  queryBody <<- body
  ####################################
  # Initialize scroll in Elastic
  ####################################
  if (is.na(password)) {
    response<-httr::POST(paste0(baseUrl, '/_search?scroll=5m&filter_path=hits.hits._source.*,_scroll_id'),
                         body = body,
                         httr::authenticate(user, getPassword()),
                         httr::config(ssl_verifypeer=0L),
                         httr::timeout(timeout),
                         httr::content_type_json())
  } else {
    response<-httr::POST(paste0(baseUrl, '/_search?scroll=5m&filter_path=hits.hits._source.*,_scroll_id'),
                         body = body,
                         httr::authenticate(user, password),
                         httr::config(ssl_verifypeer=0L),
                         httr::timeout(timeout),
                         httr::content_type_json())
  }
  res<-httr::content(response)
  
  ####################################
  # Check for errors
  ####################################
  if ('error' %in% names(res)) stop(paste0('\nReason:\n', res$error$reason, '\n\nRoot cause:\n', res$error$root_cause))
  
  hits<-length(res$hits$hits)
  if (hits) {
    tmp<-lapply(res$hits$hits, function(x) c(x$`_source`$metaData, x$`_source`$payload))
  }
  scroll_id <- res$`_scroll_id`
  pagesScrolled <- 0
  tryCatch({
    while((hits != 0) && (pagesScrolled < max_scroll_pages)){
      pagesScrolled <- pagesScrolled + 1
      ####################################
      # Fetch next scroll data
      ####################################
      if (is.na(password)) {
        response<-httr::POST(paste0(baseUrlWithoutIndex, '_search/scroll?filter_path=hits.hits._source.*,_scroll_id'),
                             body = paste0('{"scroll":"5m","scroll_id":"', res$`_scroll_id`,'"}'),
                             httr::authenticate(user, getPassword()),
                             httr::config(ssl_verifypeer=0L),
                             httr::timeout(timeout),
                             httr::content_type_json())
      } else {
        response<-httr::POST(paste0(baseUrlWithoutIndex, '_search/scroll?filter_path=hits.hits._source.*,_scroll_id'),
                             body = paste0('{"scroll":"5m","scroll_id":"', res$`_scroll_id`,'"}'),
                             httr::authenticate(user, password),
                             httr::config(ssl_verifypeer=0L),
                             httr::timeout(timeout),
                             httr::content_type_json())
      }
      res<-httr::content(response)
      
      hits<-length(res$hits$hits)
      if (hits) {
        tmp<-append(tmp, lapply(res$hits$hits, function(x) c(x$`_source`$metaData, x$`_source`$payload)))
      }
    }
  }, error = function(e) stop(e),
  finally={
    ###################
    # Close scroll mode
    ###################
    if (is.na(password)) {
      response<-httr::DELETE(paste0(baseUrlWithoutIndex, '_search/scroll'),
                             body = paste0('{"scroll_id":"', scroll_id,'"}'),
                             httr::authenticate(user, getPassword()),
                             httr::config(ssl_verifypeer=0L),
                             httr::timeout(timeout),
                             httr::content_type_json())
    } else {
      response<-httr::DELETE(paste0(baseUrlWithoutIndex, '_search/scroll'),
                             body = paste0('{"scroll_id":"', scroll_id,'"}'),
                             httr::authenticate(user, password),
                             httr::config(ssl_verifypeer=0L),
                             httr::timeout(timeout),
                             httr::content_type_json())
    }
    ###################
  })
  
  for(i in 1:length(tmp)){
    #NULL is not a valid value for a data.frame, so replace it with NA:
    tmp[[i]] <- as.data.frame(lapply(tmp[[i]], function(x) if(!is.null(x)) x else NA), stringsAsFactors=FALSE)
  }
  tmp<-data.table::rbindlist(tmp, fill = TRUE)
  
  ####################################
  # Convert to numeric if possible
  ####################################
  if (convertToNumeric) {
    suppressWarnings({
      for (name in names(tmp)) {
        if (!anyNA(as.numeric(tmp[[name]][!is.na(tmp[[name]]) & tmp[[name]]!=""]))) {
          tmp[[name]]<-as.numeric(tmp[[name]])
        }
      }
    })
  }
  
  #Normalize colnames of dat:
  newColnames <- gsub("[^(a-zA-Z0-9_)]","_",colnames(tmp))
  newColnames <- gsub("^([0-9_])","a\\1",newColnames)
  tmpDuplicates <- duplicated(newColnames) #in case some colnames are now duplicated
  newColnames[tmpDuplicates] <- paste0(newColnames[tmpDuplicates],"_",1:sum(tmpDuplicates))
  colnames(tmp) <- newColnames
  
  
  return(tmp)
},

getUniqueFieldValues = function(fieldName) {
  "Get unique values of a field"
  
  ####################################
  # Prepare terms aggregation
  ####################################
  body<-paste0('{', buildQuery(), ', "aggs":{"field":{"terms" : { "field" : "', fieldName,'","size":10000}}}, "size": 0}')
  queryBody <<- body
  
  ####################################
  # Execute in Elastic
  ####################################
  if (is.na(password)) {
    response <- httr::POST(paste0(baseUrl, '/_search'), body = body,
                           httr::authenticate(user, getPassword()),
                           httr::config(ssl_verifypeer=0L),
                           httr::timeout(timeout),
                           httr::content_type_json())
  } else {
    response <- httr::POST(paste0(baseUrl, '/_search'), body = body,
                           httr::authenticate(user, password),
                           httr::config(ssl_verifypeer=0L),
                           httr::timeout(timeout),
                           httr::content_type_json())
  }
  res <- httr::content(response)
  
  ####################################
  # Check for errors
  ####################################
  if ('error' %in% names(res)) stop(paste0('\nReason:\n', res$error$reason, '\n\nRoot cause:\n', res$error$root_cause))
  
  return(sapply(res$aggregations$field$buckets, function(x) x$key))
},

getExtendedStatsData = function (fieldName) {
  "Fetch extended statistic data of a data field from Elastic"
  
  ####################################
  # Prepare extended stats aggregation
  # https://www.elastic.co/guide/en/elasticsearch/reference/current/search-aggregations-metrics-extendedstats-aggregation.html
  ####################################
  body<-paste0('{',
               buildQuery(fieldName), ',
        "aggs":{
          "extended_stats":{
            "extended_stats":{
              "field":"', fieldName, '"
            }
          }
        },
        "size": 0
      }')
  queryBody <<- body
  ####################################
  # Execute in Elastic
  ####################################
  if (is.na(password)) {
    response <- httr::POST(paste0(baseUrl, '/_search'), body = body,
                           httr::authenticate(user, getPassword()),
                           httr::config(ssl_verifypeer=0L),
                           httr::timeout(timeout),
                           httr::content_type_json())
  } else {
    response <- httr::POST(paste0(baseUrl, '/_search'), body = body,
                           httr::authenticate(user, password),
                           httr::config(ssl_verifypeer=0L),
                           httr::timeout(timeout),
                           httr::content_type_json())
  }
  res <- httr::content(response)
  
  extended_stats_data[[fieldName]]<<-res$aggregations$extended_stats
},

getIQR = function (fieldName) {
  "Fetch inter quantile range of a data field from Elastic"
  
  qnt<-getQuantiles(fieldName, probs=c(0.25, 0.75))
  return(qnt[2]-qnt[1])
},

getQuantiles = function (fieldName, probs=c(0.25, 0.75), compression=40000) {
  "Fetch quantiles of a data field from Elastic"
  ####################################
  # Prepare percentiles aggregation
  # https://www.elastic.co/guide/en/elasticsearch/reference/current/search-aggregations-metrics-percentile-aggregation.html
  ####################################
  body<-paste0('{',
               buildQuery(fieldName), ',
        "aggs":{
          "percentiles":{
            "percentiles":{
              "field":"', fieldName, '",
              "percents" : [', paste(probs*100, collapse = ', '),'],
              "tdigest": {"compression" : ', compression,'}
            }
          }
        },
        "size": 0
      }')
  queryBody <<- body
  ####################################
  # Execute in Elastic
  ####################################
  if (is.na(password)) {
    response <- httr::POST(paste0(baseUrl, '/_search'), body = body,
                           httr::authenticate(user, getPassword()),
                           httr::config(ssl_verifypeer=0L),
                           httr::timeout(timeout),
                           httr::content_type_json())
  } else {
    response <- httr::POST(paste0(baseUrl, '/_search'), body = body,
                           httr::authenticate(user, password),
                           httr::config(ssl_verifypeer=0L),
                           httr::timeout(timeout),
                           httr::content_type_json())
  }
  res <- httr::content(response)
  
  return(unname(unlist(res$aggregations$percentiles$values)))
},

getCount = function (fieldName) {
  "Get element count of a data field from Elastic"
  
  if (is.null(extended_stats_data[[fieldName]])) { getExtendedStatsData(fieldName) }
  return(extended_stats_data[[fieldName]]$count)
},

getMin = function (fieldName) {
  "Get minimum of a data field from Elastic"
  if (is.null(extended_stats_data[[fieldName]])) { getExtendedStatsData(fieldName) }
  return(extended_stats_data[[fieldName]]$min)
},

getMax = function (fieldName) {
  "Get maximum of a data field from Elastic"
  if (is.null(extended_stats_data[[fieldName]])) { getExtendedStatsData(fieldName) }
  return(extended_stats_data[[fieldName]]$max)
},

getMean = function (fieldName) {
  "Get mean value of a data field from Elastic"
  if (is.null(extended_stats_data[[fieldName]])) { getExtendedStatsData(fieldName) }
  return(extended_stats_data[[fieldName]]$avg)
},

getSum = function (fieldName) {
  "Get sum of a data field from Elastic"
  if (is.null(extended_stats_data[[fieldName]])) { getExtendedStatsData(fieldName) }
  return(extended_stats_data[[fieldName]]$sum)
},

getVariance = function (fieldName) {
  "Get variance of a data field from Elastic"
  if (is.null(extended_stats_data[[fieldName]])) { getExtendedStatsData(fieldName) }
  return(extended_stats_data[[fieldName]]$variance)
},

getStdDeviation = function (fieldName) {
  "Get standard deviation of a data field from Elastic"
  if (is.null(extended_stats_data[[fieldName]])) { getExtendedStatsData(fieldName) }
  return(extended_stats_data[[fieldName]]$std_deviation)
},

getCardinality = function (fieldName) {
  "Get cardinality of a data field from Elastic"
  ####################################
  # Prepare cardinality aggregation
  # https://www.elastic.co/guide/en/elasticsearch/reference/current/search-aggregations-metrics-cardinality-aggregation.html
  ####################################
  body<-paste0('{',
               buildQuery(fieldName), ',
        "aggs":{
          "cardinality":{
            "cardinality":{
              "field":"', fieldName, '"
            }
          }
        },
        "size": 0
      }')
  queryBody <<- body
  ####################################
  # Execute in Elastic
  ####################################
  if (is.na(password)) {
    response <- httr::POST(paste0(baseUrl, '/_search'), body = body,
                           httr::authenticate(user, getPassword()),
                           httr::config(ssl_verifypeer=0L),
                           httr::timeout(timeout),
                           httr::content_type_json())
  } else {
    response <- httr::POST(paste0(baseUrl, '/_search'), body = body,
                           httr::authenticate(user, password),
                           httr::config(ssl_verifypeer=0L),
                           httr::timeout(timeout),
                           httr::content_type_json())
  }
  res <- httr::content(response)
  
  return(res$aggregations$cardinality$value)
}
                         )
)
