#' Create a temboPlot object
#'
#'
#' \emph{Copyright (c) 2019 Infineon Technologies}
#' @return Returns a ggplot2 graph object
#' @examples
#' ### create a tembo plot object:
#' currentTemboPlot <- temboPlot$new()
#' ### add the data to the 
#' currentTemboPlot$addData(data)
#' currentTemboPlot$addLimits(currentLimits) #note that this works even if currentLimits does not exist. The function does test for the existence of the variable. Also the limits are necessary even without limit handling, because they provide the units
#' ### filtering is done similar to filtering in subset:
#' currentTemboPlot$filterData(cond_tambient == 25)
#' currentTemboPlot$filterLimits(cond_tambient == 145)
#' ### after filtering, the most important step is setAesthetics:
#' currentTemboPlot$setAesthetics(x = 'IVS_28V', y = NULL, grouping = "cond_tambient, product_variant", facets = "cond_tambient")
#' ### using any ggplot2 function and adding it to the plot is done by addToPlot():
#' currentTemboPlot$addToPlot(ggplot2::geom_line())
#' ### Plot labels can be set:
#' currentTemboPlot$setXLabel("x")
#' currentTemboPlot$setYLabel("y")
#' currentTemboPlot$setTitle("New Plot Title")
#' ### The scaling can be changed by:
#' currentTemboPlot$setScaling(xmin = 0.001, xmax = 10, ymin = 0.001, ymax = 10, facetNr = 1)
#' currentTemboPlot$setYLog10()
#' currentTemboPlot$setXLog10()
#' currentTemboPlot$setYLinear()
#' currentTemboPlot$setXLinear()
#' ### Limit handling is done with:
#' currentTemboPlot$doLimitHandling()
#' ### Showing the plot is done with:
#' currentTemboPlot$show()
#' @family tembo plots
#' @author Helena Schmidt \email{schmidt.externel9@@infineon.com}
#' @export temboPlot
#' @exportClass temboPlot
temboPlot <- setRefClass("temboPlot",
             fields = list(data = "data.frame",
                    limits = "data.frame",
                    plot = "list",#list of plots in the object
                    plotType = "character",#a string with the plottype or inherited classes with the plot type?
                    .plotData = "data.frame",#data after filtering out unneeded columns and NAs
                    .plotXScaleTransform = "character",
                    .plotYScaleTransform = "character",
                    .pixelAxisMapping = "data.frame",
                    .internalMapping = "list",#mappings like groups and facets
                    .filename = "character",
                    .preprocessor = "function"),
             methods = list(
             	initialize = function(plotName = NULL){
             		if(!is.null(plotName)){
             			plotType <<- plotName
             		}
             	},
              addToPlot = function(x, facetNr = 1){
              	"Adds the given ggplot2 function to the current plot, x can be every ggplot compatible function like geom_point()"
              	if(ggplot2::is.ggplot(plot[[facetNr]])){
              		plot[[facetNr]] <<- plot[[facetNr]] + x
              	}
              }
             )
)



