########
#This file contains some of the temboPlot class related functions
#
#              setXLabel = foofun,
#setYLabel,
#setTitle,
#setScaling,
#setYLinear,
#setYLog10,
#setXLog10,
#setXLinear,

#
########
temboPlot$methods(
setXLabel = function(label) {
	"Sets the label on the x axis on the first plot object"
	addToPlot(ggplot2::xlab(label))
},
setYLabel = function(label) {
	"Sets the label on the y axis on the first plot object"
	addToPlot(ggplot2::ylab(label))
},
setTitle =  function(label) {
	"Sets the title of the plot on the first plot object"
	if(length(plot)==1 | plotType == "waveplot"){
		addToPlot(ggplot2::ggtitle(label))
	}
},
setScaling = function(xmin = NULL, xmax = NULL, ymin = NULL, ymax = NULL, facetNr = NULL, expand = FALSE){
	"sets the scaling of the plot or given facetNr. expand=TRUE means, that misssing x/y values are calculated from the data after filtering out the given limits. if expand='x', the tembo package tries to calculate spacing around the x axis, if expand='y', it tries the same with the y axis."
  .internalMapping$expand <<- expand
  if(is.null(facetNr))
    facetNr <- 1
  if(facetNr > length(plot)){
    facetNr <- 1
  }
  if(is.null(xmin))
    xmin <- NA
  if(is.null(xmax))
    xmax <- NA
  if(is.null(ymin))
    ymin <- NA
  if(is.null(ymax))
    ymax <- NA
  if(expand == "x"){
    expand <- FALSE
    if(!is.null(.internalMapping$x)) {
      min_x <- min(.plotData[[.internalMapping$x]], na.rm=TRUE)
      max_x <- max(.plotData[[.internalMapping$x]], na.rm=TRUE)
    }
    span <- max_x - min_x
    y_pos <- median(c(ymin,ymax),na.rm=TRUE)
    addToPlot(
      ggplot2::geom_point(
        data=data.frame(tmp_y=y_pos, tmp_x=c(min_x-span*0.05,max_x + span*0.05)),
        mapping=ggplot2::aes(x=tmp_x,y=tmp_y),
        colour="#FFFFFF00",
        inherit.aes = FALSE
      ),
      facetNr=facetNr
    )
  }
  if(expand == "y"){
    expand <- FALSE
    if(!is.null(.internalMapping$y)) {
      min_y <- min(.plotData[[.internalMapping$y]], na.rm=TRUE)
      max_y <- max(.plotData[[.internalMapping$y]], na.rm=TRUE)
      span <- max_y - min_y
      x_pos <- median(c(xmin,xmax),na.rm=TRUE)
      addToPlot(
        ggplot2::geom_point(
          data=data.frame(tmp_y=x_pos, tmp_x=c(min_y-span*0.05,max_y + span*0.05)),
          mapping=ggplot2::aes(x=tmp_x,y=tmp_y),
          colour="#FFFFFF00",
          inherit.aes = FALSE
        ),
        facetNr=facetNr
      )
    }
  }
  for(i in 1:length(plot)){
    if(i == facetNr ){
      plot <<- setScalingInternal(plot,xmin,xmax,ymin,ymax,i,.pixelAxisMapping,.plotXScaleTransform,.plotYScaleTransform, expand = expand)
    } else {
    	if(!is.null(.internalMapping$gridlayout)){
    		zoomedFacet <- which(facetNr==.internalMapping$gridlayout, arr.ind = TRUE)
    		thisFacet <- which(i==.internalMapping$gridlayout, arr.ind = TRUE)
    		if(zoomedFacet[1]==thisFacet[1]){
    			#is in same row
    			if(!(plotType=="matrixplot" & (thisFacet[1]==thisFacet[2] | zoomedFacet[1]==zoomedFacet[2]))){
    				#don't zoom y-axis in case of a histogram in a matrixplot
    				plot <<- setScalingInternal(plot,NA,NA,ymin,ymax,i, .pixelAxisMapping,.plotXScaleTransform,.plotYScaleTransform)
    			}
    		} else if(zoomedFacet[2]==thisFacet[2]){
    			#is in same column
    			plot <<- setScalingInternal(plot,xmin,xmax,NA,NA,i, .pixelAxisMapping,.plotXScaleTransform,.plotYScaleTransform)
    		}
    	}
    }
  }
}, 
setYLinear = function(facetNr = 1){
	"Sets the y axis to a linear transformation (default) for the given facet"
  if(is.null(facetNr))
    facetNr <- 1
  addToPlot(ggplot2::scale_y_continuous(),facetNr=facetNr)
  #plot[[facetNr]]$plot_env$yScaleTransform <- "linear"
  .plotYScaleTransform[facetNr] <<- "linear"
  
},
setYLog10 = function(facetNr = 1){
	"Sets the y axis to a log10 transformation for the given facet"
	if(is.null(facetNr))
    facetNr <- 1
  addToPlot(ggplot2::scale_y_log10(), facetNr=facetNr)
  #plot[[facetNr]]$plot_env$yScaleTransform <- "linear"
  .plotYScaleTransform[facetNr] <<- "log10"
  
},

setXLog10 = function(){
	"Sets the x axis to a log10 transformation for all factes"
	xrange <- c(min(.plotData[[.internalMapping$x]]), max(.plotData[.internalMapping$x]))
  if(!(xrange[1] < 0 & xrange[2] > 0)) {
    for( i in 1:length(plot)) {
      addToPlot(ggplot2::coord_cartesian(xlim=xrange, expand = FALSE),
      					facetNr=i)
    	addToPlot(ggplot2::scale_x_log10(),
    						facetNr=i)
    
    }
  } else {
    stop(paste0("Your ", .internalMapping$x, " is positive and negative, it cannot be scaled log10"))
  }
  .plotXScaleTransform <<- "log10"
},
setXLinear = function(){
	"Sets the x axis to a linear transformation (default) for all factes"
  for( i in 1:length(plot)) {
  	addToPlot(ggplot2::scale_x_continuous(),i)
  }
  #plot[[facetNr]] <<- plot[[facetNr]] + ggplot2::scale_y_log10()            
  .plotXScaleTransform <<- "linear"
},
removeLegend = function(externalCall = TRUE) {
	"Removes the legend of the plot. externalCall = TRUE means, that the legend ist not automatically added again."
	addToPlot( ggplot2::theme(legend.position = 'none') )
	if(externalCall){
		.internalMapping$legendExternallyRemoved <<- TRUE
	}
},
includeLegend = function(externalCall = TRUE) {
	"Includes the legend of the plot. externalCall = TRUE means, that the legend ist not automatically removed again."
	if(is.null(.internalMapping$legendExternallyRemoved)) {
		.internalMapping$legendExternallyRemoved <<- FALSE
	}
	if(externalCall | !(.internalMapping$legendExternallyRemoved)){
		if(plotType == "spiderchart"){
			addToPlot( ggplot2::theme(legend.position = 'left') )			
		} else {
			addToPlot( ggplot2::theme(legend.position = 'right') )
		}
		if(externalCall){
			.internalMapping$legendExternallyRemoved <<- FALSE
			.internalMapping$legendThreshold <<- 1000
		}
	}
},
setLegendEntryThreshold = function(threshold){
	"Sets the threshold for the number of legend entrys from which upwards the legend is automatically removed (default: 15)"
	.internalMapping$legendThreshold <<- threshold
},
setLegendFontSize = function(fontsize = 'auto'){
	"Sets the font size of the plot to the given value, the title is set 1.33 times larger. auto=TRUE means, that the fontsize is automatically calculated"
	.internalMapping$legendFontSize <<- fontsize
	if(length(plot)>0 & fontsize != 'auto'){
		for(i in 1:length(plot)){
			addToPlot(ggplot2::theme(legend.title=ggplot2::element_text(size=fontsize*1.33),
																							legend.text=ggplot2::element_text(size=fontsize),
																							legend.key.size = grid::unit(fontsize*1.1,"pt"),
															 ),
								i)
		}	
	}
},
setPlotSize = function(width = NA, height = NA){
	"Sets the size of the plot in pixels, dafault is 840x480"
	if(!is.na(width)){
		.internalMapping$pixelWidth <<- width
	}
	if(!is.na(height)){
		.internalMapping$pixelHeight <<- height
	}
},
setShowOnlyLegend = function(showOnlyLegend = TRUE){
	"When showOnlyLegend=TRUE, the plot is removed and only the legend ist shown instead when show() is called."
	.internalMapping$showOnlyLegend <<- showOnlyLegend
},
autodecideToPlotLegend = function(){
	entriesForLimits <- nrow(.internalMapping$tmpLimits)
	if(is.null(entriesForLimits)){entriesForLimits <- 0}
	if(is.null(.internalMapping$overlayedPlot)){
		numberOfLegendEntries <- entriesForLimits + length(unique(.plotData$groups))
	} else {
		numberOfLegendEntries <- entriesForLimits + 
			                       length(unique(.plotData$groups)) +
														 length(unique(.internalMapping$overlayedPlot$.plotData$groups))
	}
	#print(numberOfLegendEntries)
	if(is.null(.internalMapping$legendThreshold)){
		.internalMapping$legendThreshold <<- 15
	}
	if(numberOfLegendEntries >= .internalMapping$legendThreshold){
		removeLegend(externalCall = FALSE)
	} else {
		includeLegend(externalCall = FALSE)
	}
},
getAxisColumnNameX = function(){
  "get the names of the data columns that is plotted on the x axis"
  if(is.null(.internalMapping$overlayedPlot)){
    return(.internalMapping$x)
  } else {
    return(unique(.internalMapping$x,.internalMapping$overlayedPlot$.internalMapping$x))
  }
},
getAxisColumnNameY = function(){
  "get the names of the data columns that is plotted on the y axis"
  if(is.null(.internalMapping$overlayedPlot)){
    return(.internalMapping$y)
  } else {
    return(unique(.internalMapping$y,.internalMapping$overlayedPlot$.internalMapping$y))
  }
},
convertXToPixel = function(x, facetNo = 1){
  #works only for single grob plots
  px <- .pixelAxisMapping[facetNo,]
  if(.plotXScaleTransform == "log10"){
    x <- 10^(x)
  }
  q <- (px$px2-px$px1)/(px$ax2 - px$ax1)
  return (q*(x - px$ax1)+px$px1)
},
convertYToPixel = function(y, facetNo = 1){
  #works only for single grob plots
  px <- .pixelAxisMapping[facetNo,]
  if(.plotYScaleTransform == "log10"){
    y <- log10(y)
  } else if(.plotYScaleTransform == "norm"){
    #in case of a cumulative frequency plot
    y <- scales::probability_trans(distribution="norm")$transform(y)
  }
  q <- (px$py2-px$py1)/(px$ay2 - px$ay1)
  return (q*(y - px$ay1)+px$py1)
}


)

setScalingInternal <- function(currentPlot,xmin,xmax,ymin,ymax,facetNr, pixelAxisMapping,plotXScaleTransform,plotYScaleTransform,expand=FALSE){
	if(!ggplot2::is.ggplot(currentPlot[[facetNr]])){
		return(currentPlot)
	}
  if(!all(is.na(c(xmin,xmax,ymin,ymax)))){
  	if(expand){
  		#expand means rescale not given values
  		xScaleTransform <- plotXScaleTransform[min(length(currentPlot),facetNr)]
  		yScaleTransform <- plotYScaleTransform[min(length(currentPlot),facetNr)]
  		print("calculate new limits")
  		gg <- ggplot_build(currentPlot[[facetNr]])
  		subDats <- gg$data
  		#rename columns: (to make limits available)
  		subDats <- lapply(subDats, function(dat) { 
  			cnames <- colnames(dat)
  			if("xintercept" %in% cnames & !"x"%in% cnames){
  				dat$x <- dat$xintercept
  			}
  			if("yintercept" %in% cnames & !"y"%in% cnames){
  				dat$y <- dat$yintercept
  			}
  			dat
  		})
  		
  		if(!is.na(xmin)){
  			if(xScaleTransform == "log10"){
  				xmin <- log10(xmin)
  			}
  			subDats <- lapply(subDats, function(dat) { 
  				if("x" %in% colnames(dat) & nrow(dat) > 0){
  					dat <- subset(dat,x >= xmin)
  				}
  				dat
  			})
  			#subDats <- sapply(subDats, function(dat) { subset(dat,x >= xmin)})
  		}
  		if(!is.na(xmax)){
  			if(xScaleTransform == "log10"){
  				xmax <- log10(xmax)
  			}
  			subDats <- lapply(subDats, function(dat) { 
  				if("x" %in% colnames(dat) & nrow(dat) > 0){
  					dat <- subset(dat,x <= xmax)
  				}
  				dat
  			})
  			#subDats <- sapply(subDats, function(dat) { subset(dat,x <= xmax)})
  		}
  		if(!is.na(ymin)){
  			if(yScaleTransform == "log10"){
  				ymin <- log10(ymin)
  			} else if(yScaleTransform == "norm"){
  				ymin <- scales::probability_trans(distribution="norm")$transform(ymin)
  			}
  			subDats <- lapply(subDats, function(dat) { 
  				if("y" %in% colnames(dat) & nrow(dat) > 0){
  				 	dat <- subset(dat,y >= ymin)
  				}
  				dat
  				})
  		}
  		if(!is.na(ymax)){
  			if(yScaleTransform == "log10"){
  				ymax <- log10(ymax)
  			} else if(yScaleTransform == "norm"){
  				ymax <- scales::probability_trans(distribution="norm")$transform(ymax)
  			}
  			subDats <- lapply(subDats, function(dat) { 
  				if("y" %in% colnames(dat) & nrow(dat) > 0){
  					dat <- subset(dat,y <= ymax)
  				}
  				dat
  			})
  		}
  		xmin <- min(sapply(subDats, function(dat){
  			if("x" %in% colnames(dat) & nrow(dat) > 0){
  				min(dat$x)
  			} else {
  				NA
  			}
  		}), na.rm=TRUE)
  		xmax <- max(sapply(subDats, function(dat){
  			if("x" %in% colnames(dat) & nrow(dat) > 0){
  				max(dat$x)
  			} else {
  				NA
  			}
  		}), na.rm=TRUE)
  		ymin <- min(sapply(subDats, function(dat){
  			if("y" %in% colnames(dat) & nrow(dat) > 0){
  				min(dat$y)
  			} else {
  				NA
  			}
  		}), na.rm=TRUE)
  		ymax <- max(sapply(subDats, function(dat){
  			if("y" %in% colnames(dat) & nrow(dat) > 0){
  				max(dat$y)
  			} else {
  				NA
  			}
  		}), na.rm=TRUE)
  		#xmax <- max(sapply(subDats, function(dat){max(dat$x)}))
  		#ymin <- min(sapply(subDats, function(dat){min(dat$y)}))
  		#ymax <- max(sapply(subDats, function(dat){max(dat$y)}))
  		#rescale in case of transformations:
  		if(yScaleTransform == "norm"){
  			ymin <- scales::probability_trans(distribution="norm")$inverse(ymin)
  			ymax <- scales::probability_trans(distribution="norm")$inverse(ymax)
  		} else if(yScaleTransform == "log10") {
  			ymin <- 10^(ymin)
  			ymax <- 10^(ymax)
  		}
  		if(xScaleTransform == "log10") {
  			xmin <- 10^(xmin)
  			xmax <- 10^(xmax)
  		}
  	}
  	#fill in NAs with values from pixelAxisMapping
    if(is.na(xmin)){
			if(plotXScaleTransform[min(length(currentPlot),facetNr)] == "log10") {
    		xmin <- 10^(pixelAxisMapping$ax1[facetNr])
    	} else {
    		xmin <- pixelAxisMapping$ax1[facetNr]
    	}
    }
    if(is.na(xmax)){
    	if(plotXScaleTransform[min(length(currentPlot),facetNr)] == "log10") {
    		xmax <- 10^(pixelAxisMapping$ax2[facetNr])
    	} else {
    		xmax <- pixelAxisMapping$ax2[facetNr]
    	}
    }
    if(is.na(ymin)){
    	if(plotYScaleTransform[min(length(currentPlot),facetNr)] == "norm"){
    		ymin <- scales::probability_trans(distribution="norm")$inverse(pixelAxisMapping$ay1[facetNr])
    	} else if(plotYScaleTransform[min(length(currentPlot),facetNr)] == "log10") {
    		ymin <- 10^(pixelAxisMapping$ay1[facetNr])
    	} else {
    		ymin <- pixelAxisMapping$ay1[facetNr]
    	}
    }
    if(is.na(ymax)){
    	if(plotYScaleTransform[min(length(currentPlot),facetNr)] == "norm"){
    		ymax <- scales::probability_trans(distribution="norm")$inverse(pixelAxisMapping$ay2[facetNr])
    	} else if(plotYScaleTransform[min(length(currentPlot),facetNr)] == "log10") {
    		ymax <- 10^(pixelAxisMapping$ay2[facetNr])
    	} else {
    		ymax <- pixelAxisMapping$ay2[facetNr]
    	}
    }
  	if(ggplot2::is.ggplot(currentPlot[[facetNr]])){
  		currentPlot[[facetNr]]<-currentPlot[[facetNr]] + ggplot2::coord_cartesian(xlim = c(xmin, xmax), ylim=c(ymin, ymax), expand = expand)
  		if(any(sapply(currentPlot[[facetNr]]$layers, function(x) "GeomLineReduced" %in% class(x$geom)))) {
  		  xScales <- sapply(currentPlot[[facetNr]]$scales$scales, function(x) "x" %in% x$aesthetics)
  		  if(any(xScales)){
  		    currentScale <- currentPlot[[facetNr]]$scales$scales[[which(xScales)[1]]]
  		    currentScale$limits <- currentScale$trans$transform(c(xmin, xmax))
  		  } else {
  		    currentPlot[[facetNr]]  <- currentPlot[[facetNr]] + ggplot2::scale_x_continuous(limits = c(xmin, xmax))
  		  }
  		}
  	}
  } else {
    if(expand) {
      if(any(sapply(currentPlot[[facetNr]]$layers, function(x) "GeomLineReduced" %in% class(x$geom)))) {
        xScales <- sapply(currentPlot[[facetNr]]$scales$scales, function(x) "x" %in% x$aesthetics)
        if(any(xScales)){
          currentScale <- currentPlot[[facetNr]]$scales$scales[[which(xScales)[1]]]
          currentScale$limits <- NULL
        } 
      }
      currentPlot[[facetNr]] <-currentPlot[[facetNr]] + ggplot2::coord_cartesian(expand = TRUE)
    }
  }
  return(currentPlot)
}

