#the matrix plot plots scatterplots for all columns given in columnsToPlot
temboPlot$methods(
  plotContourplot = function(doInterpolation=TRUE, nIntervals=5){
    "nIntervals defines the number of intervals that are used when the contours are generated"
    param <- .internalMapping[['z']]
    x <- .internalMapping[['x']]
    y <- .internalMapping[['y']]
    xDiffs <- unique(diff(unique(sort(.plotData[[x]]))))
    xDiff <- min(abs(xDiffs))
    xMax <- max(.plotData[[x]])
    xMin <- min(.plotData[[x]])
    xSpan <- xMax-xMin
    # minimum distance between coordinates has to be at least 1% of the span
    yDiffs <- unique(diff(unique(sort(.plotData[[y]]))))
    yDiff <- min(abs(yDiffs))
    yMin <- min(.plotData[[y]])
    yMax <- max(.plotData[[y]])
    ySpan <- yMax - yMin

    if(length(xDiffs)<3 & length(yDiffs)<3){
      # raster is better for evenly distributed data
      addToPlot(ggplot2::geom_raster())
    } else {
      addToPlot(ggplot2::geom_tile())
    }
    
    if(doInterpolation){
      # if the data does not fit on a single grid with minimum size of 1% of data span, do rounding
      if(abs(xDiff/xSpan) < 0.01){
        if(abs(xMin) > abs(xMax)){
          tmpX <- round(.plotData[[x]]/xMin*100)
          .plotData[[x]] <<- tmpX/100*xMin
        } else{
          tmpX <- round(.plotData[[x]]/max(.plotData[[x]])*100)
          .plotData[[x]] <<- tmpX/100*xMax
        }
        plot[[1]]$data <<- .plotData
      }
      if(abs(yDiff/ySpan) < 0.01){
        if(abs(yMin) > abs(yMax)){
          tmpY <- round(.plotData[[y]]/yMin*100)
          .plotData[[y]] <<- tmpY/100*yMin
        } else{
          tmpY <- round(.plotData[[y]]/max(.plotData[[y]])*100)
          .plotData[[y]] <<- tmpY/100*yMax
          plot[[1]]$data <<- .plotData
        }
        plot[[1]]$data <<- .plotData
      }
    }
    if( typeof(data[[param]]) == "logical" ){
      addToPlot(
        ggplot2::scale_fill_manual(
          values=c(
            "TRUE"="#009E73",
            "FALSE"="#E54E00",
            "NA"="#999999"
            )
          )
      )
    } else {
      # "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7"
      int <- seq(min(.plotData[[param]]),max(.plotData[[param]]), length=nIntervals)
      .plotData[[param]] <<- paste(">=", round(int[findInterval(.plotData[[param]],int)],2))
      .internalMapping$colours <<- param
      plot[[1]]$data <<- .plotData
      tmpColours <- unique(.plotData[,c(param,.internalMapping$colours)])
      colors <- makeColours(tmpColours)
      .internalMapping$colourMapping <<- colors
      addToPlot(ggplot2::scale_colour_manual(
        values=.internalMapping$colourMapping
      ))
    }
  }
)