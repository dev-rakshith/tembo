temboPlot$methods(
  errorHandling = function(){
    if(plotType == "boxplot"){
      if(!is.null(.internalMapping[['x']])){
        if(.internalMapping[['x']]!=""){
          x <- .internalMapping[['x']]
          n <- length(unique(.plotData[[x]]))
          if(n > 50){
            y <- .internalMapping[['y']]
            n <- length(unique(.plotData[[y]]))
            if( n < 25){
              stop("Your x axis variable has too many unique values. Maybe you mixed up x and y?")
            }
            stop("Your x axis variable has too many unique values and is not feasible for boxplots.")
          }
        }
      }
    }
  }
)