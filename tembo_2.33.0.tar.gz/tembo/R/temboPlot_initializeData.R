temboPlot$methods(
  addData = function(expr){
  	"Adds data to the plot object"
    subsetExpr <- substitute(expr)
    tryCatch({
      data <<- eval(expr)
    },
    error = function(e) stop("Your data is missing"))
  },
  addLimits = function(expr){
  	"Adds limits to the plot object, columns with only NA values in it are filtered out automatically."
  	subsetExpr <- substitute(expr)
    tryCatch({
      limits <<- eval(expr)
    }, error = function(e) {limits <<- data.frame()})
  	
  	if(any(is.character(c(limits$min, limits$max)))){
  	  limits$min <<- as.numeric(limits$min)
  	  limits$max <<- as.numeric(limits$max)
  	}
    for(column in colnames(limits)){
    	if(is.character(limits[[column]])){
    		limits[[column]][limits[[column]] == 'NOT UNIQUE'] <<- NA #NOT UNIQUE is basically an NA identifier from the uploader
    	}
    	if(column != "min" && column != "max" && column != "lower_limit" && column != "upper_limit" && all(is.na(limits[[column]]))){
    		limits[[column]] <<- NULL
    	}
    }
  	if("color" %in% names(limits) & !"colour" %in% names(limits)) {
  	  limits$colour <<- limits$color
  	}
  },
  filterData = function(expr){
  	"filters data using an R expression, e.g. cond_tambient == 25"
  	subsetExpr <- substitute(expr)
    tryCatch({
      if(is.null(.internalMapping$currentSignalNumber)){
        data <<- data[eval(subsetExpr,data),]
      } else {
        #in this case it filters waveform data:
        tmpDf <- .internalMapping$currentSignals[[.internalMapping$currentSignalNumber]]
        tmpDf <- tmpDf[eval(subsetExpr,tmpDf),]
        .internalMapping$currentSignals[[.internalMapping$currentSignalNumber]] <<- tmpDf
      }
    },
    error = function(e) stop("Your data filtering expression does not work"))

  },
  filterLimits = function(expr){
  	"filters limits using an R expression, e.g. cond_tambient == 25"
    subsetExpr <- substitute(expr)
    tryCatch({
      if(nrow(limits) > 0){
        limits <<- limits[eval(subsetExpr,limits),]
      } else {
        warning("No limits to filter")
      }
    },
    error = function(e) stop("Your limit filtering expression does not work"))
  },
  setAesthetics = function(x = NULL, y = NULL, z = NULL, grouping = NULL, colour = NULL, shape = NULL, facets = NULL) {
  	"sets the aesthetics for the plot. facets defines ggplot facets,
  	colour gives the variables that is used for colouring,
  	shape gives the variables that define the shape,
  	grouping defines groups of the plot, if no coloring is given, it is used also as base for colour"
    if(plotType == "xyplot-boxplot-overlay"){
      #browser()
    }
    .plotData <<- createDataObject(data, x, y, z, grouping, colour, facets, fn=.preprocessor)
    if(!is.null(.preprocessor)){
      if(is.null(x) & "x_" %in% colnames(.plotData)) {
        x <- "x"
        .plotData <<- .plotData %>% dplyr::rename(x="x_")
      } 
      if(is.null(y) & "y_" %in% colnames(.plotData)) {
        y <- "y"
        .plotData <<- .plotData %>% dplyr::rename(y="y_")
      }
      if(is.null(z) & "z_" %in% colnames(.plotData)) {
        z <- "z"
        .plotData <<- .plotData %>% dplyr::rename(z="z_")
        
      }
    }
    if(plotType == "cumulative_freq" & x == ""){
    	stop("A cumulative frequency plot needs at least one data column")
    }
    mapping <- list()
    .internalMapping[['x']] <<- x
    .internalMapping[['y']] <<- y
    .internalMapping[['z']] <<- z
    #grouping <- colour
    if(!is.null(grouping)){
      groups <- unique(splitStrings(grouping))
      .internalMapping[['groups']] <<- groups
      #print(groups)
      if(length(groups) > 1) {
        .plotData$groups <<- customInteraction(.plotData[,groups],sep = "; ")
      } else {
        .plotData$groups <<- as.factor(.plotData[[groups]])
      }
      #if only grouping is set, groups define the color:
      mapping["colour"] <- "groups"
      .internalMapping[['colours']] <<- "groups"
    }
    colourUnitScale <- list()
    if(!is.null(colour)){
    	colours <- splitStrings(colour)
    	if(length(colours) > 1) {
    		.plotData$colours <<- customInteraction(.plotData[,colours],sep = "; ")
    		colourUnitScale <- list()
    		mapping["colour"] <- "colours"
    		.internalMapping[['colours']] <<- "colours"
    	} else {
    		if(is.numeric(.plotData[[colour]])){
    			if(colour %in% .internalMapping[['groups']]){
    				#grouping needs factors, but numeric variables shall not be converted to those
    				.plotData[[paste0(colour,"_factor")]] <<- as.factor(.plotData[[colour]])
    				colour <- paste0(colour,"_factor")
    			} else {
    				colourUnitScale <- getUnitAndScale(limits, colour, .plotData)
    			}
    		}
    		.internalMapping[['colours']] <<- colour
    		mapping["colour"] <- colour
    	}
    	if(all(colours%in%.internalMapping[['groups']])){
    	  if(!plotType %in% c("boxplot", "xyplot-boxplot-overlay")) {
    	    mapping["colour"] <- "groups"
    	  } else {
    	    mapping["group"] <- "groups"
    	  }
    	}
    }
    makeAllColoursBlack <- FALSE
    if(!is.null(shape)){
    	shapes <- splitStrings(shape)
    	if(length(shapes) > 1) {
    		.plotData$shapes <<- customInteraction(.plotData[,shapes],sep = "; ")
    		mapping["shape"] <- "shapes"
    		.internalMapping[['shapes']] <<- "shapes"
    	} else {
    		mapping["shape"] <- shape
    		.internalMapping[['shapes']] <<- shape
    	}
    	if(all(shapes %in% .internalMapping[['groups']])){
    		mapping["shape"] <- "groups"
    		if(is.null(colour)){
    			#if groups are set but coloring is not, remove coloring of groups
    			makeAllColoursBlack <- TRUE
    			#mapping["colour"] <- NULL
    		}
    	}
    }
    if(is.null(.internalMapping$overlayedPlot)){
    	plot[[1]] <<-ggplot2::ggplot(data=.plotData)
	    .plotXScaleTransform <<- "linear"
	    .plotYScaleTransform <<- "linear"

	    if (!is.null(x)) {
	      mapping["x"] <- list(x)
	      xUnitScale <- getUnitAndScale(limits, x, .plotData)
	      if(plotType %in% c("boxplot","xyplot-boxplot-overlay")){
	        if(is.null(grouping)){
	          mapping["group"] <- list(x)
	        } else {
	          if(x==""){
	            .internalMapping[['x']] <<- x
	            mapping["x"] <- mapping["group"]
	          }
	        }
	      }
	    } else {
	      xUnitScale <- list()
	    }
	    if (!is.null(y)) {
	      mapping["y"] <- list(y)
	      yUnitScale <- getUnitAndScale(limits, y, .plotData)
	    } else {
	      yUnitScale <- list()
	    }
	    if (!is.null(z)) {
	      mapping["fill"] <- list(z)
	      zUnitScale <- getUnitAndScale(limits, z, .plotData)
	    } else {
	      zUnitScale <- list()
	    }
	    mapping <- lapply(mapping, function(x) {
	      if (is.character(x)) {
	        if(x == ""){#this is in a boxplot without x variable the case
	          x
	        } else {
	        	x <- paste0('`', x, '`')
	          parse(text = x)[[1]]

	        }
	      }
	      else {
	        x
	      }
	    })
	    #print(mapping)
	    #the following is aequivalent to an aes() call, see also View(aes_string):
	    addToPlot(structure(mapping, class = "uneval"))
	    if(!is.null(xUnitScale$unit)){
	    	currentFormatSi <- format_si(unit=xUnitScale$unit, scale=xUnitScale$scale)
	    	if(xUnitScale$unit != ""){
	    		tmpUnitString <- paste0(" [", gsub("0", "", currentFormatSi(0)),"]")
	    		if(!grepl("\\[\\]",tmpUnitString)[1]){
	    			.internalMapping$xUnitString <<- tmpUnitString
	    		}
	    		currentFormatSi <- format_si(unit=xUnitScale$unit, scale=xUnitScale$scale, removeUnitString = TRUE)
	    	} else {
	    		currentFormatSi <- format_si(unit="", scale=xUnitScale$scale)
	    	}
	    	currentFormatSi(1)#lazy evaluation is annoying!
	    	addToPlot(ggplot2::scale_x_continuous(labels = currentFormatSi))
	    }
	    if(!is.null(yUnitScale$unit)){
	    	currentFormatSi <- format_si(unit=yUnitScale$unit, scale=yUnitScale$scale)
	    	if(yUnitScale$unit != ""){
	    		tmpUnitString <- paste0(" [", gsub("0", "", currentFormatSi(0)),"]")
	    		if(!grepl("\\[\\]",tmpUnitString)[1]){
	    			.internalMapping$yUnitString <<- tmpUnitString
	    		}
	    		currentFormatSi <- format_si(unit=yUnitScale$unit, scale=yUnitScale$scale, removeUnitString = TRUE)
	    	} else {
	    		currentFormatSi <- format_si(unit="", scale=yUnitScale$scale)
	    	}
	    	currentFormatSi(1)#lazy evaluation is annoying!
	    	addToPlot(ggplot2::scale_y_continuous(labels = currentFormatSi))
	    }
    }
    if(!is.null(colourUnitScale$unit)){
    	currentFormatSi <- format_si(unit=colourUnitScale$unit, scale=colourUnitScale$scale)
    	currentFormatSi(1)#lazy evaluation is annoying!
    	addToPlot(ggplot2::scale_colour_gradientn(colours = terrain.colors(10), labels = currentFormatSi))
    }
    if(!is.null(grouping)){
      #set legend title
      #addToPlot(labs(colour = gsub("\\s+","", grouping)))
      if(plotType == "boxplot"){
        addToPlot(labs(colour = paste(colour, collapse=",")))
      } else if(plotType == "xyplot-boxplot-overlay") {
        #addToPlot(labs(colour = paste(colour, collapse=",")))
      } else {
        addToPlot(labs(colour = paste(groups, collapse=",")))
      }
    	#print(names(mapping))
    	if("shape" %in% names(mapping)){
    		if(mapping["shape"]=="groups"){
    			tmpShapes <- unique(.plotData[,c("groups",.internalMapping$shapes)])
    			#print(.internalMapping$shapes)#why is this varable NULL?
    			#print(tmpShapes)
    			#if(is.data.frame(tmpShapes)){}
    			shapes <- (as.numeric(as.factor(tmpShapes[,2]))) %% 19 #shape 19 is also a filled circle, additional shapes are getting weird
    			names(shapes) <- tmpShapes[,1]
    			.internalMapping$shapeMapping <<- shapes
    			#addToPlot(labs(shape = gsub("\\s+","", grouping)))
    			addToPlot(labs(shape = paste(groups, collapse=",")))
    			addToPlot(ggplot2::scale_shape_manual(
    				values=.internalMapping$shapeMapping
    			))
    		}
    	}
    	if(mapping["colour"]=="groups"){
    		if(makeAllColoursBlack){
    			tmpColours <- unique(.plotData$groups)
    			colors <- rep("#000000",length(tmpColours))
    			names(colors) <- tmpColours
    		} else {
    			tmpColours <- unique(.plotData[,c("groups",.internalMapping$colours)])
    			colors <- makeColours(tmpColours)
    		}
    		.internalMapping$colourMapping <<- colors

    		addToPlot(ggplot2::scale_colour_manual(
    			values=.internalMapping$colourMapping
    		))
    	} else if("colour" %in% names(mapping)) {
    	  #print(mapping$colour)
    	  if(makeAllColoursBlack){
    	    tmpColours <- unique(.plotData$groups)
    	    colors <- rep("#000000",length(tmpColours))
    	    names(colors) <- tmpColours
    	  } else {
    	    tmpColours <- unique(.plotData[,c(.internalMapping$colours,.internalMapping$colours)])
    	    if(plotType == "xyplot-boxplot-overlay"){
    	      colors <- makeColours(tmpColours, colourOffset = length(unique(c(.internalMapping$overlayedPlot$.internalMapping$tmpVec$colours,.internalMapping$overlayedPlot$.internalMapping$colourMapping))))
    	    } else {
    	      colors <- makeColours(tmpColours)
    	    }
    	  }
    	  .internalMapping$colourMapping <<- colors

    	  if(plotType == "xyplot-boxplot-overlay"){
    	    tmpVec <- .internalMapping$overlayedPlot$.internalMapping$tmpVec
    	    #tmpVec
    	    if(!is.null(tmpVec)){
    	      for(cname in c(unique(sort(names(colors)), tmpVec$names))) {
    	        if( cname %in% names(colors)) {
    	          if( cname %in% tmpVec$names){
    	            tmpVec$colours[cname==tmpVec$names] <- colors[cname==names(colors)]
    	          } else {
    	            tmpVec$names <- c(tmpVec$names,cname)
    	            tmpVec$printNames <- c(tmpVec$printNames,cname)
    	            tmpVec$colours <- c(tmpVec$colours,colors[cname==names(colors)])
    	          }
    	        }
    	      }
    	      colourNamedList <- setNames( as.character(tmpVec$colours), as.character(tmpVec$names))
    	      addToPlot(ggplot2::scale_colour_manual(
    	        values = colourNamedList,
    	        breaks = tmpVec$names,
    	        labels = tmpVec$printNames))
    	    } else {
    	      oldMapping <- .internalMapping$overlayedPlot$.internalMapping$colourMapping
    	      for(cname in c(unique(sort(names(oldMapping))))) {
    	        if( !cname %in% names(colors)) {
    	          colors <- c(colors, oldMapping[cname==names(oldMapping)])
    	        }
    	      }
    	      addToPlot(ggplot2::scale_colour_manual(
    	        values=colors
    	      ))
    	    }
    	  } else {
    	    addToPlot(ggplot2::scale_colour_manual(
    	      values=.internalMapping$colourMapping
    	    ))
    	  }
    	}
      .internalMapping$grouping <<- grouping
    } else if("shape" %in% names(mapping)) {
      tmpShapes <- unique(.plotData[,.internalMapping$shapes])
    }
    #print(names(mapping))
    if(!is.null(facets)){
      .internalMapping$grouping <<- facets
      facets <- gsub("\\s+","",facets)
      facets <- unlist(strsplit(facets,','))
      #facets <- paste0("`",facets,"`")
      #facets <- gsub("`\\.`", ".", facets)
      .internalMapping$facets <<- facets
      if( length(facets) == 2 ) {
        facetString <- paste0("`",facets[2], "`", "~", "`", facets[1], "`")
        addToPlot(ggplot2::facet_grid(facetString))
      } else if( length(facets) == 1) {
        facetString <- paste0(facets[1])
        addToPlot(ggplot2::facet_wrap(facetString))
      } else {
        stop("too many facets, facets could only have too dimensions")
      }

    }
    addToPlot(ggplot2::theme(legend.text=ggplot2::element_text(size=7)))
    errorHandling()
  },
  getData = function() {
    return(.plotData)
  }, 
  getColourColumn = function() {
    return(.internalMapping$colours)
  },
  getGroupColumn = function() {
    if(length(.internalMapping$groups)<=1) {
      return(.internalMapping$groups)
    } else {
      return("groups")
    }
  }
  
)

createDataObject <- function(data, x = NULL, y = NULL, z = NULL,  grouping = NULL, colour = NULL, shape = NULL, facets = NULL, fn=NULL) {
  #browser()
  columnsToPlot <- c()
  groups <- c()
  if(!is.null(x)) {
    #only remove NAs on axis values, not on grouping etc.
    if(x != ""){
      columnsToPlot <- c(columnsToPlot, x)
      notNa <- !is.na(data[[x]])
      data <- subset(data, notNa)
    }
  }
  if(!is.null(y)) {
    if(y != ""){
      columnsToPlot <- c(columnsToPlot, y)
      notNa <- !is.na(data[[y]])
      data <- subset(data, notNa)
    }
  }
  if(!is.null(z)) {
    if(z != ""){
      columnsToPlot <- c(columnsToPlot, z)
      #notNa <- !is.na(data[[z]])
      #data <- subset(data, notNa)
    }
  }
  if(!is.null(colour)) {
    columnsToPlot <- c(columnsToPlot, splitStrings(colour))
    groups <- c(groups, splitStrings(colour))
  } 
  if(!is.null(shape)) {
    columnsToPlot <- c(columnsToPlot, splitStrings(shape))
    groups <- c(groups, splitStrings(shape))
  }
  if(!is.null(grouping)) {
    columnsToPlot <- c(columnsToPlot, splitStrings(grouping))
    groups <- c(groups, splitStrings(grouping))
  }
  if(!is.null(facets)) {
    columnsToPlot <- c(columnsToPlot, splitStrings(facets))
    groups <- c(groups, splitStrings(facets))
  }
  columnsToPlot <- unique(columnsToPlot)
  columnsToPlot <- subset(columnsToPlot, columnsToPlot != "." & columnsToPlot != "")#remove dot from facets
  groups <- unique(groups)
  groups <- subset(groups, groups != "." & groups != "")#remove dot from facets
  if(length(columnsToPlot) > 0){
    tmpData <- subset(data, TRUE, select=columnsToPlot)
  } else {
    stop("Aesthetics are missing")
  }
  
  if(any(columnsToPlot %in% c("_x", "_y", "_z", "groups"))){
    stop("_x, _y, _z and groups are reserved columns names in Tembo, please make sure to use different column names!")
  }
  
  #is.null(fn) is always false, because the datatype of fn is defined to be a function
  #but we can instead make sure only to run the preprocessor when the function has arguments
  if(!is.null(formalArgs(fn))){
    #browser()
    args <- formalArgs(fn)  
    argColumns <- c()
    if("x" %in% args) {
      argColumns <- c(argColumns, x)
    } else if(!is.null(x)) {
      groups <- c(groups,x)
    }
    if("y" %in% args) {
      argColumns <- c(argColumns, y)
    } else if(!is.null(y)) {
      groups <- c(groups,y)
    }
    if("z" %in% args) {
      argColumns <- c(argColumns, z)
    } else if(!is.null(z)) {
      groups <- c(groups,z)
    }
    groups <- groups[!grepl("^$",groups)] # remove empty strings
    if(length(args) == 1){
      tmpData <- tmpData %>%
        dplyr::group_by(dplyr::across(dplyr::all_of(groups))) %>%
        dplyr::summarise(
          fn(dplyr::cur_data()[[argColumns[1]]])
        ) %>%
        dplyr::rename_with(
          function(colname) {
            ifelse(colname == "x_" & !is.null(x) & !any(x %in% c(colnames(.data),groups)), x,
            ifelse(colname == "y_" & !is.null(y) & !any(y %in% c(colnames(.data),groups)), y,
            ifelse(colname == "z_" & !is.null(z) & !any(z %in% c(colnames(.data),groups)), z,
            colname)))
          }
        )
      
    } else if(length(args)==2){
      tmpData <- tmpData %>%
        dplyr::group_by(dplyr::across(dplyr::all_of(groups))) %>%
        dplyr::summarise(
          fn(dplyr::cur_data()[[argColumns[1]]],dplyr::cur_data()[[argColumns[2]]])
        ) %>% 
        dplyr::rename_with(
          function(colname) {
            ifelse(colname == "x_" & !is.null(x), x,
            ifelse(colname == "y_" & !is.null(y), y,
            ifelse(colname == "z_" & !is.null(z), z,
            colname)))
          }
        )
      
    } else {
      tmpData <- tmpData %>%
        dplyr::group_by(dplyr::across(dplyr::all_of(groups))) %>%
        dplyr::summarise(
          fn(dplyr::cur_data()[[argColumns[1]]],dplyr::cur_data()[[argColumns[2]]],dplyr::cur_data()[[argColumns[3]]])
        ) %>%
        dplyr::rename_with(
          function(colname) {
            ifelse(colname == "x_" & !is.null(x), x,
            ifelse(colname == "y_" & !is.null(y), y,
            ifelse(colname == "z_" & !is.null(z), z,
            colname)))
          }
        )
    }
  }
  as.data.frame(tmpData)
}

#'
#' @author Helena Schmidt, \email{schmidt.external9@infineon.com}
#' @export
customInteraction <- function(myDf, sep="; "){
  myDf %>%
    dplyr::group_by(dplyr::across(dplyr::all_of(colnames(myDf)))) %>%
    dplyr::mutate(
      interaction_result = factor(paste(dplyr::cur_group(),collapse=sep))
    ) -> 
    tmp
  tmp$interaction_result
}

splitStrings <- function(tmpString){
  tmpString <- gsub("\\s+","",tmpString)
  tmpString <- unlist(strsplit(tmpString,','))
  #print(tmpString)
  return(tmpString)
}

#'
#' @author Helena Schmidt, \email{schmidt.external9@infineon.com}
#' @export
getUnitAndScale <- function(myLimits, variable, data){
  substitute(myLimits)
  retValue <- list(unit = "")
  if(!is.numeric(data[[variable]])) {
    return(NULL)
  }
  limits <- data.frame()
  tryCatch(
    limits <- eval(myLimits)
  ,
  error = function(e) limits <- data.frame())

  if(any(limits$name %in% variable)) {#do any limits fit the x axis variable?
    currentLimit <- subset(limits, name %in% variable)
    if(!is.null(currentLimit$unit)){
      currentLimit <- subset(currentLimit, !is.na(unit))
      if(nrow(currentLimit) > 0){
        retValue$unit <- currentLimit$unit[1]
        #currentFormatSi <- tembo::format_si(unit=currentLimit$unit[1])
        #print(currentLimit$unit[1])
        #print(currentLimit$scale[1])
        if(!is.null(currentLimit$scale)){
          #the scale column exists
          currentLimit <- subset(currentLimit, !is.na(scale))
          if(nrow(currentLimit) > 0){
            retValue$scale <- as.numeric(currentLimit$scale[1])
            #currentFormatSi <- tembo::format_si(unit=currentLimit$unit[1], scale=as.numeric(currentLimit$scale[1]))
          }
        } else {
        	#guess the scale
        	if(is.numeric(data[[variable]])){
        	  retValue$scale <- guess_scale(data[[variable]])
        	}
        }
      }
    }
  }
  return(retValue)
}
