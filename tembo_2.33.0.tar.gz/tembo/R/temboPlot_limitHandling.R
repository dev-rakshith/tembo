#This function implements limit handling for the temboPlot class

temboPlot$methods(
	doLimitHandling = function(){
	"When limits are set, this function does the handling and plotting of limits for supported plot types
		(boxplot, xyplot, histogram, correlation plot, cumulative frequency plot)"
  if(is.null(limits)){
    return(invisible())#no limit handling
  }
  #print("limits!")
  currentLimit <- getRelevantLimits(.internalMapping, limits, data, plotType)
  if(nrow(currentLimit)== 0){
    return(invisible())#no limits left
  }
  tmpLimits <- reformatLimits(currentLimit,.internalMapping)
  if(is.null(tmpLimits)) { 
    print("no limits?")
    return(invisible())#no limits left
  }
  numberOfLayersBeforeLimits <- length(plot[[1]]$layers)
  #if limits are not unique, stop execution. check if the name is identical without the value part of the limit name for that
  if( length(tmpLimits$limitColShow) != length(unique(gsub("^(.*)@.*","\\1",tmpLimits$limitColShow)))) {
    stop("Limit not unique, refine limits filter or add grouping/facet variable")
  }
  
  #the limits are annotated with letters to better find the corresponding legend entry 
  #in case of the overlay, the new added limit letters should start after the former one
  if(grepl("overlay",plotType)[1]) {
    #This may have to be updated when refactoring boxplot
  	.internalMapping$labelsAnnotate <<- c(LETTERS,letters)[seq(nrow(tmpLimits))+length(.internalMapping$labelsAnnotate)]
  } else {
  	.internalMapping$labelsAnnotate <<- c(LETTERS,letters)[seq(nrow(tmpLimits))]
  }
  
  tmpLimits$labelsAnnotate <- .internalMapping$labelsAnnotate
  tmpLimits$limitColShow <- paste0(.internalMapping$labelsAnnotate, ": ", tmpLimits$limitColShow)
  
  
  if(plotType == "boxplot"  || plotType == "xyplot-boxplot-overlay") {
    addToPlot(ggplot2::geom_hline(data=tmpLimits, ggplot2::aes(yintercept=limitValue, colour=limitColShow, shape=limitColShow), linetype="dashed", show.legend = T))
    xname <- .internalMapping$x
    if(exists("xname")){
      if(is.numeric(.plotData[[xname]])) {
        tmpLimits$xpos <- min(.plotData[[xname]])+(max(.plotData[[xname]])-min(.plotData[[xname]]))*0.382
      } else {
        tmpLimits$xpos <- max(as.numeric(as.factor(.plotData[[xname]])))*0.382
      }
      #### This is a workaround for ggplot-bug. ggplot gives an error if tmpLimits[[xname]] does not exist after the labels are added.
      if(is.null(tmpLimits[[xname]])){
        tmpLimits[[xname]] <- 0.882
        if(all(is.infinite(tmpLimits$xpos)))
        	tmpLimits$xpos <- 0.882
      }
    } else {
      xpos <- 0.882
    }
  ## plot the annotation labels but make no new legend entrys for them.
  addToPlot(ggplot2::geom_label(data=tmpLimits,
                                                   ggplot2::aes(
                                                   	x = xpos,
                                                   	y = limitValue,
                                                    label = labelsAnnotate,
                                                   	colour = limitColShow,
                                                    shape = NULL),
                                                   show.legend = F, check_overlap = T,
                                inherit.aes=FALSE))
  
  #stop("test")
  } else if(plotType == "cumulative_freq" ) {
    isLegendNotShown <- is.null(.internalMapping$groups)
    drawXLimits(tmpLimits, isLegendNotShown, ypos=0.99995)
    #drawXLimits(tmpLimits, isLegendNotShown, ypos=0.99995)
    if(!is.null(.internalMapping$expand)){
      if(.internalMapping$expand == "x"){
        if(!is.null(.internalMapping$x)) {
          min_x <- min(.plotData[[.internalMapping$x]], tmpLimits$limitValue, na.rm=TRUE)
          max_x <- max(.plotData[[.internalMapping$x]], tmpLimits$limitValue, na.rm=TRUE)
        }
        span <- max_x - min_x
        y_pos <- 0.5
        addToPlot(
          ggplot2::geom_point(
            data=data.frame(tmp_y=y_pos, tmp_x=c(min_x-span*0.05,max_x + span*0.05)),
            mapping=ggplot2::aes(x=tmp_x,y=tmp_y),
            colour="#FFFFFF00",
            inherit.aes = FALSE
          ),
          facetNr=1
        )
        
      }
    }
    
    
    #addToPlot(ggplot2::geom_vline(data=tmpLimits, ggplot2::aes(xintercept=limitValue, colour=limitColShow), linetype="dashed", show.legend = isLegendNotShown))
    #addToPlot(ggplot2::geom_label(data=tmpLimits, ggplot2::aes(x = limitValue, y = rep(0.999,length(.internalMapping$labelsAnnotate)), label = labelsAnnotate,colour = limitColShow),show.legend = F))
  } else if(plotType == "histogram" ) {
  	drawXLimits(tmpLimits, isLegendNotShown=TRUE, ypos = 1)
  } else if(plotType == "xyplot") {
    #the cumulative frequency plot draws a legend, if grouping is used. If not, no legend is present. 
    #Therefore it is tested if grouping is present. If not, than draw a new legend.
    isLegendNotShown <- is.null(.internalMapping$groups)
    drawXLimits(tmpLimits, isLegendNotShown)
    drawYLimits(tmpLimits, isLegendNotShown)
  } else if( plotType == "correlationplot") {
  	xname <- .internalMapping$x
  	yname <- .internalMapping$y
  	drawXLimits(tmpLimits)
  	drawYLimits(tmpLimits)
  }
  ##### set colours #####
  tmpVec <- setColorsForLimits(tmpLimits, plotType, .plotData, .internalMapping)
  .internalMapping$tmpLimits <<- tmpLimits
  .internalMapping$tmpVec <<- tmpVec
  # to apply the colors to the limits and the legend, a named list is used to assign colours to the names.
  #browser()
  colourNamedList <- setNames( as.character(tmpVec$colours), as.character(tmpVec$names))
  addToPlot(ggplot2::scale_colour_manual(name = .internalMapping$grouping,
                                         values = colourNamedList,
                                         breaks = tmpVec$names,
                                         labels = tmpVec$printNames))
  ### shape handling
  if(!is.null(.internalMapping$shapeMapping) | !is.null(plot[[1]]$mapping$shape)) {
  	if(is.null(tmpLimits$parsed_conditions)){
  		shapeNamedList <- setNames( rep(32,length(tmpVec$names)), as.character(tmpVec$names))
  	} else {
  		#in case of conditions, limits with dots are possible
  		shapeNamedList <- setNames( rep(16,length(tmpVec$names)), as.character(tmpVec$names))
  	}
  	if(!is.null(.internalMapping$shapeMapping)){
  		#use the shapelist from setAesthetics
  		shapeNamedList <- c(.internalMapping$shapeMapping,shapeNamedList[!names(shapeNamedList) %in% names(.internalMapping$shapeMapping)])
  	}
  	addToPlot(ggplot2::scale_shape_manual(name = .internalMapping$grouping,
  																				values = shapeNamedList,
  																				breaks = tmpVec$names,
  																				labels = tmpVec$printNames))
  } else if(length( plot[[1]]$layers ) > numberOfLayersBeforeLimits) {
  	#remove shape mapping from limits
  	for( i in (numberOfLayersBeforeLimits+1):length( plot[[1]]$layers )){
  	 	if(!is.null(plot[[1]]$layers[[i]]$mapping)){
  	 		if(!is.null(plot[[1]]$layers[[i]]$mapping$shape)){
  	 			plot[[1]]$layers[[i]]$mapping$shape <<- NULL
  	 		}
  	 	}
  	}
  }
  if(length(tmpVec$names)>15){
  	addToPlot(ggplot2::theme(legend.title=ggplot2::element_text(size=5),
  													 legend.text=ggplot2::element_text(size=5),
  													 legend.key.size = grid::unit(6,"pt")))
  	addToPlot(ggplot2::guides(colour=ggplot2::guide_legend(ncol = 1)))#, override.aes = list(size=1, linetype = 'solid'))))
  } else if(length(tmpVec$names)>30){
  	addToPlot(ggplot2::theme(legend.title=ggplot2::element_text(size=4),
  													 legend.text=ggplot2::element_text(size=4),
  													 legend.key.size = grid::unit(4.1,"pt")))
  	addToPlot(ggplot2::guides(colour=ggplot2::guide_legend(ncol = 1)))#, override.aes = list(size=1, linetype = 'solid'))))
  }


},
  drawYLimits = function(allTmpLimits, isLegendNotShown = TRUE, xpos = NULL, facetNr = 1){
  	tmpLimits <- subset(allTmpLimits, name == .internalMapping$y[facetNr] )
  	if(nrow(tmpLimits) > 0){
  		linePlotLimits <- tmpLimits
  		if(!is.null(tmpLimits$parsed_conditions)){
  			conditionedLimits <- sapply(tmpLimits$parsed_conditions, function(x){x$hasConditionForParam(.internalMapping$x[facetNr])})
  			linePlotLimits <- tmpLimits[!(conditionedLimits),]
  			conditionedLimits <- tmpLimits[conditionedLimits,]
  			if(nrow(conditionedLimits)>0){
  				for(i in 1:nrow(conditionedLimits)){
  					thisPlotData <- conditionedLimits$parsed_conditions[i][[1]]$getPlotData(.internalMapping$x[facetNr])
  					plotLabelData <- data.table(limitValue = conditionedLimits$limitValue[i],
  																			labelsAnnotate = conditionedLimits$labelsAnnotate[i],
  																			limitColShow = conditionedLimits$limitColShow[i])
  					if(length(thisPlotData$points)>0){
  						plotLabelData$labelPos <- min(as.numeric(thisPlotData$points), na.rm=T)
  						plotLimitData <- data.table(limitPos=as.numeric(thisPlotData$points),
  																				limitValue = conditionedLimits$limitValue[i],
  																				labelsAnnotate = conditionedLimits$labelsAnnotate[i],
  																				limitColShow = conditionedLimits$limitColShow[i])
  						if(is.numeric(.plotData[[.internalMapping$x[facetNr]]])){
  							tmpPos <- as.numeric(plotLabelData$labelPos)
  							tmpPos <- tmpPos + 0.03*(max(.plotData[[.internalMapping$x[facetNr]]], na.rm=T) - min(.plotData[[.internalMapping$x[facetNr]]], na.rm=T))
  							plotLabelData$labelPos <- tmpPos
  							plotLimitData$limitPos <- as.numeric(plotLimitData$limitPos)
  						}
  						#print(paste(plotLabelData))
  						addToPlot(ggplot2::geom_point(data = plotLimitData, ggplot2::aes(x = limitPos, y = limitValue, colour = limitColShow, shape = limitColShow), show.legend = isLegendNotShown),
  											facetNr = facetNr)
  						
  					}
  					#print(thisPlotData)
  					if(!all(is.na(thisPlotData$range))){
  						#print(thisPlotData$range)
  						for(i_range in 1:(length(thisPlotData$range)/2)){
  							if(is.na(thisPlotData$range[i_range*2-1])){
  								#range from -infty to range[2]
  								plotLabelData$labelPos <- as.numeric(thisPlotData$range[i_range*2])
  								plotLimitData <- data.table(limitPos=as.numeric(thisPlotData$range[i_range*2]),
  																						limitValue = conditionedLimits$limitValue[i],
  																						labelsAnnotate = conditionedLimits$labelsAnnotate[i],
  																						limitColShow = conditionedLimits$limitColShow[i])
  								
  								addToPlot(ggplot2::geom_segment(data = plotLimitData, ggplot2::aes(x = -Inf, xend = limitPos, y = limitValue, yend = limitValue, colour = limitColShow, shape = limitColShow), linetype = "dashed", show.legend = isLegendNotShown),
  													facetNr = facetNr)
  								
  							} else if(is.na(thisPlotData$range[i_range*2])){
  								plotLabelData$labelPos <- as.numeric(thisPlotData$range[i_range*2-1])
  								plotLimitData <- data.table(limitPos=as.numeric(thisPlotData$range[i_range*2-1]),
  																						limitValue = conditionedLimits$limitValue[i],
  																						labelsAnnotate = conditionedLimits$labelsAnnotate[i],
  																						limitColShow = conditionedLimits$limitColShow[i])
  								
  								addToPlot(ggplot2::geom_segment(data = plotLimitData, ggplot2::aes(x = limitPos, xend = Inf, y = limitValue, yend = limitValue, colour = limitColShow, shape = limitColShow), linetype = "dashed", show.legend = isLegendNotShown),
  													facetNr = facetNr
  													)
  								#range from range[1] to +infty
  							} else{
  								plotLabelData$labelPos <- as.numeric(thisPlotData$range[i_range*2-1])
  								plotLimitData <- data.table(limitPos1=as.numeric(thisPlotData$range[i_range*2-1]),
  																						limitPos2=as.numeric(thisPlotData$range[i_range*2]),
  																						limitValue = conditionedLimits$limitValue[i],
  																						labelsAnnotate = conditionedLimits$labelsAnnotate[i],
  																						limitColShow = conditionedLimits$limitColShow[i])
  								if(thisPlotData$range[i_range*2-1] <= thisPlotData$range[i_range*2]){
  									addToPlot(ggplot2::geom_segment(data = plotLimitData, ggplot2::aes(x = limitPos1, xend = limitPos2, y = limitValue, yend = limitValue, colour = limitColShow, shape = limitColShow), linetype = "dashed", show.legend = isLegendNotShown),
  														facetNr = facetNr)
  								} else {
  									addToPlot(ggplot2::geom_segment(data = plotLimitData, ggplot2::aes(x = -Inf, xend = limitPos2, y = limitValue, yend = limitValue, colour = limitColShow, shape = limitColShow), linetype = "dashed", show.legend = isLegendNotShown),
  														facetNr = facetNr)
  									addToPlot(ggplot2::geom_segment(data = plotLimitData, ggplot2::aes(x = limitPos1, xend = Inf, y = limitValue, yend = limitValue, colour = limitColShow, shape = limitColShow), linetype = "dashed", show.legend = isLegendNotShown),
  														facetNr = facetNr)
  								}
  						  }
  						}
  					}
  					#print(plotLabelData)
  					addToPlot(ggplot2::geom_label(data = plotLabelData, ggplot2::aes(x = labelPos, y = limitValue, label = labelsAnnotate, colour = limitColShow, shape=NULL), show.legend = F),
  										facetNr = facetNr)
  				}
  			}
  		}
  		if(nrow(linePlotLimits) > 0){
  			addToPlot(ggplot2::geom_hline(data = linePlotLimits, ggplot2::aes(yintercept = limitValue, colour = limitColShow, shape = limitColShow), linetype = "dashed", show.legend = isLegendNotShown),
  								facetNr = facetNr)
  			if(is.null(xpos)){
  			  xmin <- min(.plotData[[.internalMapping$x[facetNr]]], na.rm=T)
  			  xmax <- max(.plotData[[.internalMapping$x[facetNr]]], na.rm=T)
  			  if(is.numeric(xmin) & is.numeric(xmax)){
  			    xpos <- xmin - (xmax-xmin)*0.05
  			  } else {
  			    xpos <- 1.5
  			  }
  			}
  			linePlotLimits$xpos <- xpos
  			addToPlot(ggplot2::geom_label(data = subset(linePlotLimits,labelsAnnotate!=""),
  																		ggplot2::aes(x = xpos, y = limitValue, label = labelsAnnotate, colour = limitColShow, shape = limitColShow, shape=NULL), show.legend = F),
  								facetNr = facetNr)
  		}
  	}
  	
  },
  drawXLimits = function(allTmpLimits, isLegendNotShown = F, ypos = NULL, facetNr = 1){
	tmpLimits <- subset(allTmpLimits, name == .internalMapping$x[facetNr] )
	if(nrow(tmpLimits) > 0){
		linePlotLimits <- tmpLimits
		if(!is.null(tmpLimits$parsed_conditions)){
			conditionedLimits <- sapply(tmpLimits$parsed_conditions, function(x){x$hasConditionForParam(.internalMapping$y[facetNr])})
			linePlotLimits <- tmpLimits[!(conditionedLimits),]
			conditionedLimits <- tmpLimits[conditionedLimits,]
			if(nrow(conditionedLimits)>0){
				for(i in 1:nrow(conditionedLimits)){
					thisPlotData <- conditionedLimits$parsed_conditions[i][[1]]$getPlotData(.internalMapping$y[facetNr])
					plotLabelData <- data.table(limitValue = conditionedLimits$limitValue[i],
																			labelsAnnotate = conditionedLimits$labelsAnnotate[i],
																			limitColShow = conditionedLimits$limitColShow[i])
					if(length(thisPlotData$points)>0){
						plotLabelData$labelPos <- min(as.numeric(thisPlotData$points), na.rm=T)
						plotLimitData <- data.table(limitPos=as.numeric(thisPlotData$points),
																				limitValue = conditionedLimits$limitValue[i],
																				labelsAnnotate = conditionedLimits$labelsAnnotate[i],
																				limitColShow = conditionedLimits$limitColShow[i])
						if(is.numeric(.plotData[[.internalMapping$x[facetNr]]])){
							tmpPos <- as.numeric(plotLabelData$labelPos)
							tmpPos <- tmpPos + 0.06*(max(.plotData[[.internalMapping$y[facetNr]]], na.rm=T) - min(.plotData[[.internalMapping$y[facetNr]]], na.rm=T))
							plotLabelData$labelPos <- tmpPos
							plotLimitData$limitPos <- as.numeric(plotLimitData$limitPos)
						}
						#print(paste(plotLabelData))
						addToPlot(ggplot2::geom_point(data = plotLimitData, ggplot2::aes(y = limitPos, x = limitValue, colour = limitColShow, shape = limitColShow), show.legend = isLegendNotShown), facetNr=facetNr)
						
					}
					#print(thisPlotData)
					if(!all(is.na(thisPlotData$range))){
						for(i_range in 1:(length(thisPlotData$range)/2)){
							if(is.na(thisPlotData$range[i_range*2-1])){
								#range from -infty to range[2]
								plotLabelData$labelPos <- as.numeric(thisPlotData$range[i_range*2])
								plotLimitData <- data.table(limitPos=as.numeric(thisPlotData$range[i_range*2]),
																						limitValue = conditionedLimits$limitValue[i],
																						labelsAnnotate = conditionedLimits$labelsAnnotate[i],
																						limitColShow = conditionedLimits$limitColShow[i])
								
								addToPlot(ggplot2::geom_segment(data = plotLimitData, ggplot2::aes(y = -Inf, yend = limitPos, x = limitValue, xend = limitValue, colour = limitColShow, shape = limitColShow), linetype = "dashed", show.legend = isLegendNotShown),
													facetNr = facetNr
													)
								
							} else if(is.na(thisPlotData$range[i_range*2])){
								plotLabelData$labelPos <- as.numeric(thisPlotData$range[i_range*2-1])
								plotLimitData <- data.table(limitPos=as.numeric(thisPlotData$range[i_range*2-1]),
																						limitValue = conditionedLimits$limitValue[i],
																						labelsAnnotate = conditionedLimits$labelsAnnotate[i],
																						limitColShow = conditionedLimits$limitColShow[i])
								
								addToPlot(ggplot2::geom_segment(data = plotLimitData, ggplot2::aes(y = limitPos, yend = Inf, x = limitValue, xend = limitValue, colour = limitColShow, shape = limitColShow), linetype = "dashed", show.legend = isLegendNotShown))
								#range from range[1] to +infty
							} else{
								plotLabelData$labelPos <- as.numeric(thisPlotData$range[i_range*2-1])
								plotLimitData <- data.table(limitPos1=as.numeric(thisPlotData$range[i_range*2-1]),
																						limitPos2=as.numeric(thisPlotData$range[i_range*2]),
																						limitValue = conditionedLimits$limitValue[i],
																						labelsAnnotate = conditionedLimits$labelsAnnotate[i],
																						limitColShow = conditionedLimits$limitColShow[i])
								if(thisPlotData$range[i_range*2-1] <= thisPlotData$range[i_range*2]){
									addToPlot(ggplot2::geom_segment(data = plotLimitData, ggplot2::aes(y = limitPos1, yend = limitPos2, x = limitValue, xend = limitValue, colour = limitColShow, shape = limitColShow), linetype = "dashed", show.legend = isLegendNotShown),
														facetNr = facetNr)
								} else {
									addToPlot(ggplot2::geom_segment(data = plotLimitData, ggplot2::aes(y = -Inf, yend = limitPos2, x = limitValue, xend = limitValue, colour = limitColShow, shape = limitColShow), linetype = "dashed", show.legend = isLegendNotShown),
														facetNr = facetNr)
									addToPlot(ggplot2::geom_segment(data = plotLimitData, ggplot2::aes(y = limitPos1, yend = Inf, x = limitValue, xend = limitValue, colour = limitColShow, shape = limitColShow), linetype = "dashed", show.legend = isLegendNotShown),
														facetNr = facetNr)
								}
							}
						}
					}
					addToPlot(ggplot2::geom_label(data = subset(plotLabelData,labelsAnnotate!=""),
																				ggplot2::aes(y = labelPos, x = limitValue, label = labelsAnnotate, colour = limitColShow, shape = limitColShow), show.legend = F, shape=NULL), facetNr=facetNr)
				}
			}
		}
		if(nrow(linePlotLimits) > 0){
			addToPlot(ggplot2::geom_vline(data = linePlotLimits, ggplot2::aes(xintercept = limitValue, colour = limitColShow, shape = limitColShow), linetype = "dashed", show.legend = isLegendNotShown), facetNr=facetNr)
			if(is.null(ypos)){
			  ymin <- min(.plotData[[.internalMapping$y[facetNr]]], na.rm=T)
			  ymax <- max(.plotData[[.internalMapping$y[facetNr]]], na.rm=T)
			  if(is.numeric(ymin) & is.numeric(ymax)){
			    ypos <- ymin - (ymax-ymin)*0.05
			  } else {
			    ypos <- 1.5
			  }
				#ypos <- min(.plotData[[.internalMapping$y[facetNr]]], na.rm=T)
			}
			linePlotLimits$ypos <- ypos
			addToPlot(ggplot2::geom_label(data =  subset(linePlotLimits,labelsAnnotate!=""),
																		ggplot2::aes(y = ypos, x = limitValue, label = labelsAnnotate, colour = limitColShow, shape = limitColShow, shape = NULL), show.legend = F), facetNr=facetNr)
		}
	}
	
})

removeDuplicatedLimits <- function(tmpLimitsRm){
  for( limitName in unique(tmpLimitsRm$name)) {#loop if x and y limits are present
    subNameTmpLimits <- subset(tmpLimitsRm, name != limitName)
    tmpLimitsRm <- subset(tmpLimitsRm, name == limitName)
    for( limitV in levels(as.factor(tmpLimitsRm$limitValue)) ){
      #this loop removes limits with identical values
      tmpNumber <- as.numeric(as.character(limitV))
      if(sum(tmpLimitsRm$limitValue == tmpNumber) > 1) {
        subTmpLimits <- subset(tmpLimitsRm, limitValue == tmpNumber)
        tmpLimitsRm <- subset(tmpLimitsRm, limitValue != tmpNumber)
        subTmpLimits$limitColShow <- as.character(subTmpLimits$limitColShow)
        tmpString <- paste(unique(unlist(strsplit(subTmpLimits$limitColShow,split="_"))),collapse ="_")
        #print(tmpString)
        subTmpLimits$limitColShow[1] <- tmpString
        tmpLimitsRm <- rbind(tmpLimitsRm, subTmpLimits[1,])
        #print(tmpLimits$limitColName)
      }
    }
    tmpLimitsRm <- rbind(tmpLimitsRm, subNameTmpLimits)
  }
  return(tmpLimitsRm)
}

#===============================================================================================
#' wrap text in a plot
#'
#' @author Helena Schmidt, \email{schmidt.external9@infineon.com}
#' @export
wrapText <- function(wrapString, numberOfChars = 30){
  #the wrapText function inserts line breaks after numberOfChar characters. It is used to reduce the size of the labels.
  nSegments <- trunc(nchar(wrapString)/numberOfChars)
  regexIn <- paste0(paste(rep(paste0("(.{",paste0(numberOfChars),"})"),nSegments),collapse=""),"(.*)")
  subText <- paste("\\",seq(1,nSegments+1),"\n",sep="",collapse="")
  return(gsub("\n$","",gsub(regexIn,subText,wrapString)))
}


getRelevantLimits <- function(.internalMapping, limits, data, plotType){
  ########## Input sanitation
  groups <- c(.internalMapping$groups, .internalMapping$facets)
  if(!is.null(.internalMapping$facets)){
  	for(column in .internalMapping$facets){
  		if(column %in% colnames(limits)) {
  			#values of a facet variable that are not in data should be rejected. Unfortunately, %in% works not with factors as expected, so as.character is used
	  		limits <- subset(limits, as.character(limits[[column]]) %in% c(NA, as.character(unique(data[[column]]))))
  		  if(all(is.na(limits[[column]]))){
  		  	limits[[column]] <- NULL
  		  }else if(any(is.na(limits[[column]]))){
  		  	notNaLimits <- limits[!is.na(limits[[column]]),]
  		  	newLimitSet <- data.frame()
  		  	for(i in which(is.na(limits[[column]]))){
  		  		uniqueFields <- unique(data[[column]])
  		  		tmpLimit <- data.table::rbindlist(
  		  		  rep(list(limits[i,]),
  		  		      length(uniqueFields))
  		  		  )
  		  		tmpLimit[[column]] <- uniqueFields
  		  		newLimitSet <- as.data.frame(rbind(newLimitSet,tmpLimit))
  		  	}
  		  	limits <- rbind(notNaLimits, newLimitSet)
  		  }
  		}
  	}
  }
  colsLimitsInGrouping <- colnames(limits)[colnames(limits) %in% groups]
  if(plotType == "boxplot" | plotType == "xyplot-boxplot-overlay") {
    limitVariableName <- .internalMapping$y
  } else if( plotType == "correlationplot" | plotType == "xyplot") {
    limitVariableName <- c(.internalMapping$y, .internalMapping$x)
  } else if(plotType == "cumulative_freq" || plotType == "histogram" ) {
    limitVariableName <- .internalMapping$x
  }
  #print(limitVariableName)
  #print(unique(limits$name))
  currentLimit <- data.frame()
  if(any(limits$name %in% limitVariableName)) {#plot if any limits do exist
    #only use the current data variables to find corresponding limits
    currentLimit <- subset(limits, name %in% limitVariableName)
    # $limitName is used to store the grouping for the printed name in the legend, and also to
    # check later if limits are unique
    colsLimitsInGrouping <- colnames(currentLimit)[colnames(currentLimit) %in% groups]
    if(length(colsLimitsInGrouping)>0){
      currentLimit$limitName <- interaction(currentLimit[colsLimitsInGrouping],sep = ",")
    }else {
      currentLimit$limitName <- ""
    }
  }
  if(!is.null(currentLimit$condition)){
  	if(all(currentLimit$condition %in% c("",NA))){
  		currentLimit$condition <- NULL
  	} else {
  		if(plotType == "boxplot" | plotType == "xyplot-boxplot-overlay") {
  			currentLimit$parsed_conditions <- lapply(currentLimit$condition, function(x) {temboCondition(x, y=.internalMapping$y)})
  		} else if( plotType == "correlationplot" | plotType == "xyplot") {
  			currentLimit$parsed_conditions <- lapply(currentLimit$condition, function(x) {temboCondition(x, x=.internalMapping$x,y=.internalMapping$y)})
  		} else if(plotType == "cumulative_freq" || plotType == "histogram" ) {
  			currentLimit$parsed_conditions <- lapply(currentLimit$condition, function(x) {temboCondition(x, x=.internalMapping$x)})
  		} else {
  			currentLimit$parsed_conditions <- lapply(currentLimit$condition, temboCondition)
  		}
  		currentLimit$limitName <- paste(currentLimit$limitName, unique(sapply(currentLimit$parsed_condition, function(x) {x$getLimitName(groups)})))
  	}
  }
  return(data.table::as.data.table(currentLimit))
}

reformatLimits <- function(currentLimit, .internalMapping){
  tmpLimits <- NULL
  #tmpLimits is used as data variable to plot with ggplot
  #the limtis are splitted to one row for the maximum and one row for the minimum limit
  for(i in 1:nrow(currentLimit)) {
    #tmpdf is the temporary data frame for splitting the limits, it is late rbinded to tmpLimits
    #$limitColName is the column with the internal name, it is the same for min and max because
    # the colour of the line depends on the names.
    #$limitColShow is the name of the limit that gets shown in the legend
    #$limitBorder is either min or max
    tmpdf <- data.table( limitColName = paste(currentLimit$name[i],currentLimit$limit_type[i],currentLimit$limitName[i],sep = "_"),
                         name = currentLimit$name[i],
                         limitColShow = paste(currentLimit$name[i],currentLimit$limit_type[i],"min",currentLimit$limitName[i],sep = "_"),
                         limitBorder = "min",
                         limitValue = currentLimit$min[i]
                        )
    tmpdf$limitColShow <- paste0(tmpdf$limitColShow, " @ " , tembo::format_si()(currentLimit$min[i])[1])
    if("colour" %in% names(currentLimit)) {
      tmpdf$limitColour <- currentLimit$colour[i]
    }
    
    if(!is.null(currentLimit$parsed_conditions)){
    	tmpdf <- cbind(tmpdf, data.table(parsed_conditions=currentLimit$parsed_conditions[i]))
    }
    #if facets are used, columns are needed to plot the lines only in the facet where the limit applies to
    if(!is.null(.internalMapping$facets)) {
      tmpdf[[.internalMapping$facets[1]]] <- currentLimit[[.internalMapping$facets[1]]][i]
      if( length(.internalMapping$facets) == 2 ) {
        tmpdf[[.internalMapping$facets[2]]] <- currentLimit[[.internalMapping$facets[2]]][i]
      }
    }
    tmpLimits <- rbind(tmpLimits,tmpdf)
    #the same as above for the maximum row
    tmpdf <- data.frame( limitColName = paste(currentLimit$name[i],currentLimit$limit_type[i],currentLimit$limitName[i],sep = "_"),
                         name = currentLimit$name[i],
                         limitColShow = paste(currentLimit$name[i],currentLimit$limit_type[i],"max",currentLimit$limitName[i],sep = "_"),
                         limitBorder = "max",
                         limitValue = currentLimit$max[i])
    tmpdf$limitColShow <- paste0(tmpdf$limitColShow, " @ " , tembo::format_si()(currentLimit$max[i])[1])
    if("colour" %in% names(currentLimit)) {
      tmpdf$limitColour <- currentLimit$colour[i]
    }
    if(!is.null(currentLimit$parsed_conditions)){
    	tmpdf <- cbind(tmpdf, data.table(parsed_conditions=currentLimit$parsed_conditions[i]))
    }
    if(!is.null(.internalMapping$facets)) {
      tmpdf[[.internalMapping$facets[1]]] <- currentLimit[[.internalMapping$facets[1]]][i]
      if( length(.internalMapping$facets) == 2 ) {
        tmpdf[[.internalMapping$facets[2]]] <- currentLimit[[.internalMapping$facets[2]]][i]
      }
    }
    tmpLimits <- rbind(tmpLimits,tmpdf)
  }
  tmpLimits <- tmpLimits[with(tmpLimits, order(limitValue)),]
  #stop(colnames(tmpLimits),tmpLimits)
  #print(tmpLimits)
  tmpLimits <- na.omit(tmpLimits)
  if(nrow(tmpLimits) > 0) {
    #limit-values that are duplicated should be removed to sanitize the plot.
    if(!is.null(.internalMapping$facets)) {
      #the facets may exist in data, but it is possible that they are not in limits
      usableFacets <- c()
      if(!is.null(tmpLimits[[.internalMapping$facets[1]]])){
        usableFacets <- c(usableFacets, .internalMapping$facets[1])
      }
      if(!is.null(tmpLimits[[.internalMapping$facets[2]]])){
        usableFacets <- c(usableFacets, .internalMapping$facets[2])
      }
      newTmpLimits <- NULL
      if( length(usableFacets) == 2 & length(unique(tmpLimits$name)) == 2 ) {
        # two facets and also x and y limits
        for( face1 in unique(tmpLimits[[usableFacets[1]]])) {
          #stop(face1)
          subLimits1 <- subset( tmpLimits, tmpLimits[[usableFacets[1]]] == face1)
          #stop(subLimits1)
          for( face2 in unique(subLimits1[[usableFacets[2]]])) {
            subLimits2 <- subset( subLimits1, subLimits1[[usableFacets[2]]] == face2)
            newTmpLimits <- rbind(newTmpLimits, removeDuplicatedLimits(subLimits2))
          }
        }
      } else {
        # one facet or only one limit
        if(!is.null(unique(tmpLimits[[usableFacets[1]]]))) {
          #first facet and it has limits
          for( face1 in unique(tmpLimits[[usableFacets[1]]])) {
            subLimits1 <- subset( tmpLimits, tmpLimits[[usableFacets[1]]] == face1)
            newTmpLimits <- rbind(newTmpLimits, removeDuplicatedLimits(subLimits1))
          }
        } else if(!is.null(unique(tmpLimits[[usableFacets[2]]]))) {
          #if only the second limit has facets
          for( face1 in unique(tmpLimits[[usableFacets[2]]])) {
            subLimits1 <- subset( tmpLimits, tmpLimits[[usableFacets[2]]] == face1)
            newTmpLimits <- rbind(newTmpLimits, removeDuplicatedLimits(subLimits1))
          }
        } else {#no usable facets
          newTmpLimits <- removeDuplicatedLimits(tmpLimits)
        }
      }
      tmpLimits <- newTmpLimits
    } else {
      #if no facets are present, just remove the duplicated limits
      tmpLimits <- removeDuplicatedLimits(tmpLimits)
    }
  } else {
    return(NULL)
  }
  return(tmpLimits)
}

setColorsForLimits <- function(tmpLimits, plotType, .plotData, .internalMapping){
  if(!is.null(.internalMapping$colours) & is.null(.internalMapping$shapes)){
    groupNames <- as.character(unique(.plotData[[.internalMapping$colours]]))
  } else {
    groupNames <- as.character(unique(.plotData$groups))
  }
	colourNames <- c(unique(as.character(tmpLimits$limitColName)), groupNames)
  if(!grepl("overlay", plotType)[1]) {
    tmpVec <- NULL
    colourOffset <- 0
  } else {
    #colourOffset is needed for overlay plots, so colors are not being used twice
  	tmpVec <- .internalMapping$tmpVec
  	#print(tmpVec)
    colourOffset <- length(unique(tmpVec$colours))
  }
  
  if( (length(colourNames) + colourOffset) > 8 ) {
    colourPalette <- scales::hue_pal()(length(colourNames)+colourOffset)[(colourOffset+1):(length(colourNames)+colourOffset)]
    if( (length(colourNames) + colourOffset) > 15 ){
      if (!exists(".Random.seed")) runif(1) #init .Random.seed
      tmpSeed <- .Random.seed
    	set.seed(123) #set a seed to guarantee always the same colour ordering
    	colourPalette <- sample(colourPalette)
    	.Random.seed <- tmpSeed #restore random sedd
    }
  } else {
    cbPalette <- c("#999999", "#E69F00", "#56B4E9", "#009E73", "#F0E442", "#0072B2", "#D55E00", "#CC79A7")
    colourPalette <- cbPalette[(colourOffset+1):(length(colourNames)+colourOffset)]
  }
	
  for(cname in c(sort(groupNames), tmpLimits$limitColShow)) {
    if( !cname %in% tmpVec$names) {
      if( cname %in% colourNames){
        tmpVec$names  <- c(tmpVec$names, cname)
        if(cname %in% groupNames & !is.null(.internalMapping$colourMapping)){
          thisColourName <- .internalMapping$colourMapping[names(.internalMapping$colourMapping) == cname]
          if(length(thisColourName) > 0){
            tmpVec$colours <- c(tmpVec$colours, thisColourName)
          } else {
            tmpVec$colours <- c(tmpVec$colours, colourPalette[cname == colourNames][1])
          }
        }else {
          tmpVec$colours <- c(tmpVec$colours, colourPalette[cname == colourNames][1])
        }
      } else{
        # looks for the limitColName corresponding to the limitColShow entry
        subName <- tmpLimits[tmpLimits$limitColShow == cname,]$limitColName
        if(subName %in% colourNames){
          tmpVec$names  <- c(tmpVec$names, cname)
          tmpVec$colours <- c(tmpVec$colours, colourPalette[subName == colourNames][1])
        }
      }
      if("limitColour" %in% names(tmpLimits)) {
        if(!is.na(tmpLimits[tmpLimits$limitColShow == cname,]$limitColour[1])){
          tmpVec$colours[length(tmpVec$colours)] <- tmpLimits[tmpLimits$limitColShow == cname,]$limitColour[1]
        }
      }
    }
  }
  tmpVec$printNames <- tmpVec$printNames
  #apply the wrapText for each of the names.
  if(length(tmpVec$names)>15){
  	wrapSize <- 50
  } else {
  	wrapSize <- 30
  }
  for(i in 1:length(tmpVec$names)){
    tmpVec$printNames[i] <- wrapText(as.character(tmpVec$names[i]), numberOfChars = wrapSize)
  }
  return(tmpVec)
}