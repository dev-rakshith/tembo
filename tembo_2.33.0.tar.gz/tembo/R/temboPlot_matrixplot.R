#the matrix plot plots scatterplots for all columns given in columnsToPlot
temboPlot$methods(
  plotMatrixplot = function(columnsToPlot,coloring=NULL,limitHandling=NULL){
    if(length(columnsToPlot) ==0){
      return(NULL)
    }
    if(!all(columnsToPlot %in% colnames(data))){
      stop("Not all requested columns are in the data. Please make sure to use the correct columns")
    }
  	if(!is.null(coloring)){
  		if(!coloring %in%colnames(data)){
  			#if coloring is not in dat, ignore coloring
  			coloring <- NULL
  		}
  	}
  	if(!is.null(coloring) & !is.null(limitHandling)){
  		#the coloring variable is needed to define for which columns the limit handling should be done
  		#no grouping is implemented in this function
  		thisAnalysis <- temboAnalysis$new()
  		thisAnalysis$setParam(coloring)
  		data$rownum <<- 1:nrow(data)
  		data$inLimits <<- NA
  		thisAnalysis$addData(data)
  		thisAnalysis$addLimits(limits,evaluateConditions = TRUE)
  		#thisAnalysis$limits$parsed_conditions[[1]]$condition_data
  		for(tmp in thisAnalysis$generateSubsets()){
  			if(nrow(tmp)==0) next
  			onlyLowerLimit <- subset(tmp, is.na(UpperLimit) & !is.na(LowerLimit))
  			onlyUpperLimit <- subset(tmp, !is.na(UpperLimit) & is.na(LowerLimit))
  			bothLimits <- subset(tmp, !is.na(UpperLimit) & !is.na(LowerLimit))
  			if(nrow(onlyLowerLimit)>0){
  				isInLimits <- onlyLowerLimit[[thisAnalysis$parameter]] >= onlyLowerLimit$LowerLimit
  				data$inLimits[onlyLowerLimit$rownum[isInLimits]] <<- "Within limits"
  				data$inLimits[onlyLowerLimit$rownum[!isInLimits]] <<- "Outside limits"
  			}
  			if(nrow(onlyUpperLimit)>0){
  				isInLimits <- onlyUpperLimit[[thisAnalysis$parameter]] <= onlyUpperLimit$UpperLimit
  				data$inLimits[onlyUpperLimit$rownum[isInLimits]] <<- "Within limits"
  				data$inLimits[onlyUpperLimit$rownum[!isInLimits]] <<- "Outside limits"
  			}
  			if(nrow(bothLimits)>0){
  				isInLimits <- bothLimits[[thisAnalysis$parameter]] >= bothLimits$LowerLimit & bothLimits[[thisAnalysis$parameter]] <= bothLimits$UpperLimit
  				data$inLimits[bothLimits$rownum[isInLimits]] <<- "Within limits"
  				data$inLimits[bothLimits$rownum[!isInLimits]] <<- "Outside limits"
  			}
  		}
  		data$inLimits[is.na(data$inLimits)] <<- "Unknown"
  		#typeof(NA_log)
  		limitParameter <- coloring
  		coloring <- "inLimits"
  	}
  	.plotYScaleTransform <<- "linear"
  	.plotXScaleTransform <<- "linear"
    if(length(columnsToPlot)== 1){
      plot[[1]] <<- ggplot2::ggplot(data) + ggplot2::geom_histogram(ggplot2::aes_string(x=columnsToPlot))
      return(NULL)
    }
    .plotData <<- data[,c(columnsToPlot,coloring)]
    plots <- list()
    .internalMapping$gridwidth <<- rep(1,length(columnsToPlot))
    .internalMapping$gridheight <<- rep(1,length(columnsToPlot))
    #do logistic estimation to compensate the first columns and the last row for axis labels
    .internalMapping$gridwidth[1] <<- 1 + 0.3/(1+exp(-0.5*(length(columnsToPlot)-8)))
    .internalMapping$gridheight[length(columnsToPlot)] <<- 1 + 0.5/(1+exp(-0.5*(length(columnsToPlot)-8)))
    .internalMapping$gridlayout <<- matrix()
    countPlots <- 1
    mostLegendEntries <- 0
    usePlotForLegend <- 2
    
    for(i in 1:length(columnsToPlot)){
      layoutRow <- c()
      for(j in 1:i){
        if(j == i){
          #plot histogram
          plot[[countPlots]] <<- ggplot2::ggplot(.plotData) + ggplot2::geom_histogram(ggplot2::aes_string(x=columnsToPlot[i]))
          if(i == 1){
            addToPlot(ggplot2::ylab(columnsToPlot[1]), facetNr=countPlots)
          }
          .internalMapping$x[countPlots] <<- columnsToPlot[j]
          .internalMapping$y[countPlots] <<- ""
        } else {
        	.internalMapping$x[countPlots] <<- columnsToPlot[j]
        	.internalMapping$y[countPlots] <<- columnsToPlot[i]
        	if(is.null(coloring)){
        		plot[[countPlots]] <<- ggplot2::ggplot(.plotData) + ggplot2::geom_point(
        			                       ggplot2::aes_string(x=columnsToPlot[j],y=columnsToPlot[i]),size=0.25)
        	} else {
        		plot[[countPlots]] <<- ggplot2::ggplot(.plotData) + ggplot2::geom_point(
        			                       ggplot2::aes_string(x=columnsToPlot[j],
        			                       										 y=columnsToPlot[i],
        			                       										 colour=coloring),
        			                        size=0.25)
        		addToPlot(ggplot2::theme(legend.position = 'none'), facetNr=countPlots)
        		if(coloring == "inLimits"){
        			colourValues <- c("Outside limits"="purple",
        													"Within limits"="springgreen3",
        													"Unknown"= "gray11")#,
        												#"cyan4", "cyan4")
        			if(columnsToPlot[j] == limitParameter){
        				tmpLimits <- reformatLimits(limits, .internalMapping)
        				tmpLimits$labelsAnnotate <- ""
        				drawXLimits(tmpLimits, facetNr = countPlots)
        				tmpCol <- rep("cyan4", nrow(tmpLimits))
        				names(tmpCol) <- tmpLimits$limitColShow
        				colourValues <- c(colourValues,tmpCol)
        				#names(colourValues)[colourValues=="cyan4"] <- tmpLimits$limitColShow[1:2]
        			} else if(columnsToPlot[i] == limitParameter){
        				tmpLimits <- reformatLimits(limits, .internalMapping)
        				tmpLimits$labelsAnnotate <- ""
        				drawYLimits(tmpLimits, facetNr = countPlots)
        				tmpCol <- rep("cyan4", nrow(tmpLimits))
        				names(tmpCol) <- tmpLimits$limitColShow
        				colourValues <- c(colourValues,tmpCol)
        				#names(colourValues)[colourValues=="cyan4"] <- tmpLimits$limitColShow[1:2]
        			}
        			if(length(colourValues)>mostLegendEntries){
        				mostLegendEntries <- length(colourValues)
        				usePlotForLegend <- countPlots
        				#print(usePlotForLegend)
        			}
        			addToPlot(ggplot2::scale_color_manual(values=colourValues), 
        								facetNr=countPlots)
        			#why is there lazy evaluation of scale_color_manual?
        			ggplot2::ggplot_build(plot[[countPlots]])
        		} else if(is.numeric(.plotData[[coloring]]))
        		{
        			addToPlot(ggplot2::scale_color_gradientn(colours=terrain.colors(7)[1:6]),
        								facetNr=countPlots)
        		} else {
        			colourValues <- makeColours(data.frame(x=unique(.plotData[[coloring]]),y=unique(.plotData[[coloring]])))
        			addToPlot(ggplot2::scale_color_manual(values=colourValues), 
        								facetNr=countPlots)
        			#print(colors)
        		}
        	}
        }
        if(i < length(columnsToPlot)){
          addToPlot(ggplot2::theme(axis.title.x=ggplot2::element_blank()),
          				  facetNr=countPlots)
        } else {
        	addToPlot(ggplot2::xlab(wrapText(columnsToPlot[i],20)))
        }
        if(j > 1){
          addToPlot(ggplot2::theme(axis.title.y=ggplot2::element_blank()),
          					facetNr=countPlots)
        } else {
        	addToPlot(ggplot2::ylab(wrapText(columnsToPlot[j],20)))
        }
        layoutRow <- c(layoutRow,countPlots)
        addToPlot(ggplot2::theme(text = element_text(size=min(c(6,8*(length(columnsToPlot))^(-0.3))))),
        					facetNr=countPlots)
        countPlots <- countPlots + 1
      }
      if(all(is.na(.internalMapping$gridlayout))){
        layoutRow <- c(layoutRow,rep(NA,length(columnsToPlot)-length(layoutRow)))
        .internalMapping$gridlayout <<- matrix(layoutRow,nrow = 1)
      } else {
        layoutRow <- c(layoutRow,rep(NA,length(columnsToPlot)-length(layoutRow)))
        .internalMapping$gridlayout <<- rbind(.internalMapping$gridlayout,layoutRow)
      }
    }
    #plot <<- plots
    .plotYScaleTransform[1:length(plot)] <<- "linear"
    .plotXScaleTransform[1:length(plot)] <<- "linear"
    if(!is.null(coloring)){
    	#Extract the legend grob and fill it in on the right plot pane
    	tmpPlot <- plot[[usePlotForLegend]]
    	tmpPlot <- tmpPlot + theme(legend.position = 'right') + guides(shape=FALSE)
    	tmpGrob <- ggplot2::ggplot_gtable(ggplot2::ggplot_build(tmpPlot)) 
    	leg <- which(sapply(tmpGrob$grobs, function(x) x$name) == "guide-box")
    	print(leg)
    	if(length(leg) > 0){
    		legnd <- tmpGrob$grobs[[leg]] 
    		plot[[length(plot)+1]] <<- legnd
    		colNum <- ncol(.internalMapping$gridlayout)
    		rowNum <- as.vector(which(is.na(.internalMapping$gridlayout[,colNum])))
    		.internalMapping$gridlayout[rowNum,colNum] <<- length(plot)
    	}
    	#legnd
    	#plot[[length(plot)+1]] <<- legnd
    	#colNum <- ncol(.internalMapping$gridlayout)
    	#rowNum <- as.vector(which(is.na(.internalMapping$gridlayout[,colNum])))
    	#.internalMapping$gridlayout[rowNum,colNum] <<- length(plot)
    	
    }
  }
)