temboPlot$methods(
  show = function(showOnJupyter=TRUE){
  	"Shows the plot"
  	autodecideToPlotLegend()
  	if(nrow(data) == 0){
  	  addToPlot(ggplot2::labs(subtitle="no data found"))
  	}
    if(length(plot)==1){
      #print(plot[[1]])
      .pixelAxisMapping <<- showPlot(plot[[1]],mappingData = .internalMapping,showOnJupyter=showOnJupyter)
      .filename <<- reprPlotTmpFile
    } else {
      .pixelAxisMapping <<- showPlot(plot,mappingData = .internalMapping)
      .filename <<- reprPlotTmpFile
    }
  	#traces Identification
  	if(showOnJupyter){
  	  doTracesGeneration <- TRUE
  	  if(exists("TEMBO_INTERNAL")) {
  	    if(!is.null(TEMBO_INTERNAL$schedulerMode)){
  	      if(TEMBO_INTERNAL$schedulerMode) {
  	        doTracesGeneration <- FALSE
  	      }
  	    }
  	  }
  	  if(doTracesGeneration){
  	    if(!is.null(.internalMapping$tracesGenerationProcess)){
  	      .internalMapping$tracesGenerationProcess <<- NULL
  	    }
  	    if(plotType %in% c("xyplot", "correlationplot")) {
  	      .internalMapping$tracesGenerationProcess <<- callr::r_bg(tembo::createTraceImages, args = list(.self, tempdir()))
  	    }
  	  }
  	}
  	.internalMapping$tracesTmpFiles <<- NULL #reset temporary file information for identify traces when replotting
  },
  save = function(filename){
    show(showOnJupyter = FALSE)
    file.copy(.filename, filename)
  },
  writeDebugPlot = function(writePlotFolder, testName){
    folder <- substitute(writePlotFolder)
    tryCatch({
    		if(dir.exists(eval(folder))){
    			file.copy(.filename, paste0(eval(folder), "/", testName, "_", format(Sys.time(), "%Y%m%d-%H%M%S"), ".png"))
    		}
    },
    error = function(e){})#do nothing
  },
  convertPixelToAxis = function(x, y, w, h, xml=TRUE){
    pixels <- c(x,y,w,h)
    facetToZoomIn <- which.max(apply(.pixelAxisMapping, 1, function(tmpRow){
      return(
        (max(0, min(as.numeric(tmpRow[2]), x+w) - max(as.numeric(tmpRow[1]), x))) * #0 if no pixel is in the facet otherwise x amount of pixels
          (max(0, min(as.numeric(tmpRow[4]), y+h) - max(as.numeric(tmpRow[3]), y)))   #0 if no pixel is in the facet
      )
    }))
    x1rel <- (max(.pixelAxisMapping$px1[facetToZoomIn],x) - .pixelAxisMapping$px1[facetToZoomIn])/(.pixelAxisMapping$px2[facetToZoomIn]-.pixelAxisMapping$px1[facetToZoomIn])
    x2rel <- (min(.pixelAxisMapping$px2[facetToZoomIn],x+w) - .pixelAxisMapping$px1[facetToZoomIn])/(.pixelAxisMapping$px2[facetToZoomIn]-.pixelAxisMapping$px1[facetToZoomIn])
    
    y1rel <- 1 - (min(.pixelAxisMapping$py2[facetToZoomIn],y+h) - .pixelAxisMapping$py1[facetToZoomIn])/(.pixelAxisMapping$py2[facetToZoomIn]-.pixelAxisMapping$py1[facetToZoomIn])
    y2rel <- 1 - (max(.pixelAxisMapping$py1[facetToZoomIn],y) - .pixelAxisMapping$py1[facetToZoomIn])/(.pixelAxisMapping$py2[facetToZoomIn]-.pixelAxisMapping$py1[facetToZoomIn])
    
    xmin <- .pixelAxisMapping$ax1[facetToZoomIn]+(.pixelAxisMapping$ax2[facetToZoomIn]-.pixelAxisMapping$ax1[facetToZoomIn])*x1rel
    xmax <- .pixelAxisMapping$ax1[facetToZoomIn]+(.pixelAxisMapping$ax2[facetToZoomIn]-.pixelAxisMapping$ax1[facetToZoomIn])*x2rel
    ymin <- .pixelAxisMapping$ay1[facetToZoomIn]+(.pixelAxisMapping$ay2[facetToZoomIn]-.pixelAxisMapping$ay1[facetToZoomIn])*y1rel
    ymax <- .pixelAxisMapping$ay1[facetToZoomIn]+(.pixelAxisMapping$ay2[facetToZoomIn]-.pixelAxisMapping$ay1[facetToZoomIn])*y2rel
    if(length(plot) == 1 ){  
      if(.plotYScaleTransform == "norm"){
        #in case of a cumulative frequency plot
        ymin <- scales::probability_trans(distribution="norm")$inverse(ymin)
        ymax <- scales::probability_trans(distribution="norm")$inverse(ymax)
      }else if(.plotYScaleTransform == "log10"){
        ymin <- 10^(ymin)
        ymax <- 10^(ymax)      
      }
    } else {
      if(.plotYScaleTransform[[facetToZoomIn]] == "log10"){
        ymin <- 10^(ymin)
        ymax <- 10^(ymax)
      }
    }
    if(.plotXScaleTransform == "log10"){
      xmin <- 10^(xmin)
      xmax <- 10^(xmax)      
    }
    if(xml){
      xml <- paste(
        "<zoom-xmin> ", xmin, "</zoom-xmin>",
        "<zoom-xmax> ", xmax, "</zoom-xmax>",
        "<zoom-ymin> ", ymin, "</zoom-ymin>",
        "<zoom-ymax> ", ymax, "</zoom-ymax>",
        "<zoom-facet-nr> ", facetToZoomIn, "</zoom-facet-nr>"
      )
      return(xml)#foward the xml to the front-end
    }
    else {
      return( list(
        xmin = xmin,
        ymin = ymin,
        xmax = xmax,
        ymax = ymax,
        facetNo = facetToZoomIn
      ))
    }
  }
)

showPlot <- function(currentPlot, mappingData = list(), showOnJupyter=TRUE){
	pixelWidth <- 840
	pixelHeight <- 480
	if(!is.null(mappingData$pixelWidth)){
		pixelWidth <- mappingData$pixelWidth
	}
	if(!is.null(mappingData$pixelHeight)){
		pixelHeight <- mappingData$pixelHeight
	}
	tmpMapping <- list()
  convertggbuildAndGtable <- function(gg, ggg){
    #the native unit is the actual size on the currently open plot device. It is pixels in our case
    heights <- grid::convertHeight(ggg$heights, 'native', valueOnly=TRUE)
    #the unit of a plot panel is 'null', unfortunately, 1null will be converted to 0px.
    #only plot panels do have 1null as size
    #nullHeights <- paste(ggg$heights) == "1null"
    nullHeights <- grepl("null$", paste(ggg$heights))
    #as the zero height is obviously wrong for panels, it is replaced by NA for now
    heights[which(nullHeights)] <- NA_real_
    #the npc unit is a relative position. 1 always means the whole plot canvas.
    totalHeight <- grid::convertHeight(grid::unit(1,"npc"),"native", valueOnly = TRUE)
    # one plotpanel has the height:
    heightOfPanel <- (totalHeight - sum(heights,na.rm=TRUE))/sum(nullHeights)
    allHeights <- heights
    allHeights[is.na(allHeights)] <- heightOfPanel
    # hights are with negtive sign, correct this for now
    allHeights <- -allHeights
    #do the same as above for the widths:
    nullWidths <- paste(ggg$widths) == "1null"
    widths <- grid::convertWidth(ggg$widths, 'native', valueOnly=TRUE)
    widths[which(nullWidths)] <- NA_real_
    totalWidth <- grid::convertWidth(grid::unit(1,"npc"),"native", valueOnly = TRUE)
    widthOfPanel <- (totalWidth - sum(widths,na.rm=TRUE))/sum(nullWidths)
    allWidths <- widths
    allWidths[is.na(allWidths)] <- widthOfPanel
    
    #calculate where the panels start and stop:
    pixelHStarts <- cumsum(allHeights)[which(nullHeights)-1]
    pixelHStops <- cumsum(allHeights)[which(nullHeights)]
    pixelWStarts <- cumsum(allWidths)[which(nullWidths)-1]
    pixelWStops <- cumsum(allWidths)[which(nullWidths)]
    allPixelValues <- data.frame()
    pl <- gg$layout$layout
    facets <- names(pl)[!names(pl) %in% c("PANEL", "ROW", "COL", "SCALE_X", "SCALE_Y")]
    
    
    #make a data frame that maps one panel pixelwise to one panel axis limitwise
    #note that the pixel of the y-axis start on top and increase with lower position,
    #for the y-axis its the other way round, it starts at the bottom and increases with height
    for(i in 1:length(pixelHStarts)){
      for(j in 1:length(pixelWStarts)){
        panelNr <- as.numeric(pl$PANEL[pl$ROW == i & pl$COL == j])
        if(length(panelNr) == 0) next
        if(length(facets) == 1){
          facetName1 <- facets[1]
          facetValue1 <- pl[[facetName1]][panelNr]
          facetName2 <- NA
          facetValue2 <- NA
        } else if(length(facets) == 2){
          facetName1 <- facets[1]
          facetValue1 <- pl[[facetName1]][panelNr]
          facetName2 <- facets[2]
          facetValue2 <- pl[[facetName2]][panelNr]
        } else {
          facetName1 <- NA
          facetValue1 <- NA
          facetName2 <- NA
          facetValue2 <- NA
        }
        allPixelValues <- rbind(allPixelValues,(data.frame(px1=pixelWStarts[j],px2=pixelWStops[j],
                                                           py1=pixelHStarts[i],py2=pixelHStops[i],
                                                           ax1=gg$layout$panel_params[[panelNr]]$x.range[1],
                                                           ax2=gg$layout$panel_params[[panelNr]]$x.range[2],
                                                           ay1=gg$layout$panel_params[[panelNr]]$y.range[1],
                                                           ay2=gg$layout$panel_params[[panelNr]]$y.range[2],
                                                           facetName1=facetName1,
                                                           facetValue1=facetValue1,
                                                           facetName2=facetName2,
                                                           facetValue2=facetValue2,
                                                           stringsAsFactors = FALSE
        )))
      }
    }
    allPixelValues$isXaxisScaleFree <- gg$layout$facet$params$free$x#NULL if not facets, TRUE if true and FALSE if false
    allPixelValues$isYaxisScaleFree <- gg$layout$facet$params$free$y#NULL if not facets, TRUE if true and FALSE if false
    return(allPixelValues)
  }
  
  
  getPanelPositions <- function(g, gridPlotsTogether = FALSE, gridwidth = NULL, gridheight = NULL, gridlayout = NULL){
  	#in a multiplot there are ggplot objects as well as grob-objects allowed. A grob object can be a title or a legend
  	isGgPlot <- sapply(g,ggplot2::is.ggplot)
  	plotList <- which(isGgPlot)
  	#print(isGgPlot)
    if(gridPlotsTogether){
    	if(is.null(gridlayout)){
    		#the gridlayout is used in combination with gridwidth and gridheigt to define the layout of the plot
    		gridwidth <- c(1)
    		gridheight <- 1:sum(isGgPlot)
    		gridlayout <- matrix(1:sum(isGgPlot), nrow=sum(isGgPlot))
    	}
    	if(is.null(gridwidth)){
    		gridwidth <- 1:ncol(gridlayout)
    	}
    	if(is.null(gridheight)){
    		gridheight <- 1:nrow(gridlayout)
    	}
    	#print(nrow(g))
    	ggList <- list()
    	gggList <- list()
      ggList[isGgPlot] <- lapply(g[isGgPlot], ggplot2::ggplot_build) #Builds the plot data itself    
      gggList[isGgPlot] <- lapply(ggList[isGgPlot], ggplot2::ggplot_gtable)
      gggList[!isGgPlot] <- g[!isGgPlot]
      #print(gggList)
      ################ Align plots on a column
      grobNames <- c("axis-l", "axis-r", "ylab-l", "strip-r", "ylab-r", "guide-box")#names of the grobs that need to be aligned
      grobsOnXList <- gggList[[plotList[1]]]$layout$l[gsub("-[0-9]$","",gggList[[plotList[1]]]$layout$name) %in% grobNames]
      for(icol in 1:ncol(gridlayout)){
      	panels <- as.vector(na.omit(gridlayout[,icol]))
      	panels <- panels[panels %in% plotList]#only use panels that are plots
      	maxUnits <- gggList[[panels[1]]]$widths[grobsOnXList]
      	if(length(panels)>1){
      		for(i in 2:length(panels)){
      			maxUnits <- grid::unit.pmax(maxUnits, gggList[[panels[i]]]$widths[grobsOnXList])
      		}
      		for(i in 1:length(panels)){
      			gggList[[panels[i]]]$widths[grobsOnXList] <- maxUnits
      		}
      	}
      }
      ################ Align plots on a row
      grobNames <- c("axis-t", "axis-b", "xlab-t", "subtitle", "xlab-b", "title", "caption")#names of the grobs that need to be aligned
      grobsOnYList <- gggList[[plotList[1]]]$layout$l[gsub("-[0-9]$","",gggList[[plotList[1]]]$layout$name) %in% grobNames]
      #print(gridlayout[,1])	
      for(irow in 1:nrow(gridlayout)){
      	panels <- as.vector(na.omit(gridlayout[irow,]))
      	panels <- panels[panels %in% plotList]#only use panels that are plots
      	maxUnits <- gggList[[panels[1]]]$heights[grobsOnYList]
      	if(length(panels)>1){
      		for(i in 2:length(panels)){
      			maxUnits <- grid::unit.pmax(maxUnits, gggList[[panels[i]]]$heights[grobsOnYList])
      		}
      		for(i in 1:length(panels)){
      			gggList[[panels[i]]]$heights[grobsOnYList] <- maxUnits
      		}
      	}
      }
      #######################print out plot
     	gridExtra::grid.arrange(
      		grobs = gggList,
      		widths = gridwidth,
      		heights = gridheight,
      		layout_matrix = gridlayout)
      pixelAxisMappingTmp <- data.frame()
      totalHeight <- -grid::convertHeight(grid::unit(1,"npc"),"native", valueOnly = TRUE)
      totalWidth <- grid::convertWidth(grid::unit(1,"npc"),"native", valueOnly = TRUE)
      nPlots <- length(g)
      heightSum <- sum(gridheight)
      widthSum <- sum(gridwidth)
      tmpMapping$ggList <<- ggList
      tmpMapping$gggList <<- gggList
      #grDevices::dev.off()
      tmpFile <- tempfile(fileext = ".png")
      
      for(i in 1:nPlots){
      	#print(reprPlotTmpFile)
      	if(!(i %in% plotList)){
      		#in case the list entry is not a plot(but a grob), the corresponding pixel axismapping is NA
      		pixelAxisMappingTmp <- rbind(pixelAxisMappingTmp,data.frame(px1=NA,px2=NA,
      																																py1=NA,py2=NA,
      																																ax1=NA,
      																																ax2=NA,
      																																ay1=NA,
      																																ay2=NA,
      																																facetName1=NA,
      																																facetValue1=NA,
      																																facetName2=NA,
      																																facetValue2=NA))
      		next
      	}
      	gridpos <- which(i == gridlayout, arr.ind=TRUE)#assume each facet is only on one grid element
      	
      	#open the plot device
      	#calculate the pixel positions of a plot with exactly the size of the facet on the plot
      	Cairo::Cairo(  (gridwidth[gridpos[1,'col']]*totalWidth/widthSum)/120, #width
      								 (gridheight[gridpos[1,'row']]*totalHeight/heightSum)/120, #height
      								 tmpFile, #filename
      								 "png", #filetype
      								 12, #pointsize
      								 'white', #background color
      								 "transparent", 
      								 "in", # unit
      								 120 #dpi / resolution
      	)
      	#print(dev.cur())
        pixelAxisMappingTmp <- rbind(pixelAxisMappingTmp,convertggbuildAndGtable(ggList[[i]],gggList[[i]]))
        dev.off()
        #gridpos <- which(i == gridlayout, arr.ind=TRUE)#assume each facet is only on one grid element
        #calculate pixel height position
        startPlotAtPxHeight <- totalHeight*(sum(gridheight[0:(gridpos[1,'row']-1)]))/heightSum
        pixelAxisMappingTmp$py1[i] <- pixelAxisMappingTmp$py1[i] + startPlotAtPxHeight
        pixelAxisMappingTmp$py2[i] <- pixelAxisMappingTmp$py2[i] + startPlotAtPxHeight
        #pixelAxisMappingTmp$py1[i] <- gridheight[gridpos[1,'row']]*pixelAxisMappingTmp$py1[i]/heightSum + startPlotAtPxHeight
        #pixelAxisMappingTmp$py2[i] <- gridheight[gridpos[1,'row']]*pixelAxisMappingTmp$py2[i]/heightSum + startPlotAtPxHeight
        #calculate pixel width position
        startPlotAtPxWidth <- totalWidth*(sum(gridwidth[0:(gridpos[1,'col']-1)]))/widthSum
        pixelAxisMappingTmp$px1[i] <- pixelAxisMappingTmp$px1[i] + startPlotAtPxWidth
        pixelAxisMappingTmp$px2[i] <- pixelAxisMappingTmp$px2[i] + startPlotAtPxWidth
        #pixelAxisMappingTmp$px1[i] <- gridwidth[gridpos[1,'col']]*pixelAxisMappingTmp$px1[i]/widthSum + startPlotAtPxWidth
        #pixelAxisMappingTmp$px2[i] <- gridwidth[gridpos[1,'col']]*pixelAxisMappingTmp$px2[i]/widthSum + startPlotAtPxWidth
      }
      return(pixelAxisMappingTmp)
    } else {
      gg <- ggplot2::ggplot_build(g) #Builds the plot data itself  
      ggg <- ggplot2::ggplot_gtable(gg) #creates als grobs for the plot, which means the positions of each facet etc.
      #tmpMapping$gg <<- gg
      #tmpMapping$ggg <<- ggg
      #grid::grid.newpage()
      #grid::grid.draw(ggg)
      pixelAxisMappingTmp <- convertggbuildAndGtable(gg,ggg)
      return(pixelAxisMappingTmp)
    }
  }
  showExtractedLegend <- function(plots){
  	grobs <- list()
  	if(ggplot2::is.ggplot(plots)){
  		plots <- list(plots)
  	}
  	j <- 1
  	for(i in 1:length(plots)){
  		tmp <- ggplot2::ggplot_gtable(ggplot2::ggplot_build(plots[[i]])) 
  		leg <- which(sapply(tmp$grobs, function(x) x$name) == "guide-box") 
  		if(length(leg) > 0){
  			legend <- tmp$grobs[[leg]] 
  			grobs[[j]] <- legend
  			j <- j + 1
  		}
  	}
  	if(j == 2){
  		grid::grid.newpage()
  		grid::grid.draw(grobs[[1]])
  	} else if(j > 2){
  		#gridExtra::grid.arrange(grobs = grobs, ncol = 1)
  		ml <- gridExtra::arrangeGrob(grobs=grobs, ncol = 1,nrow=j-1)
  		grid::grid.newpage()
  		grid::grid.draw(ml)
  	} else {
  		grid::grid.newpage()
  	}
  }
  # Show plot
  #create a filename for a temporary file for the plot
  reprPlotTmpFile <<- tempfile(fileext = ".png")
  #print(reprPlotTmpFile)
  #open the plot device
  Cairo::Cairo(  pixelWidth/120, #width
                 pixelHeight/120, #height
                 reprPlotTmpFile, #filename
                 "png", #filetype
                 12, #pointsize
                 'white', #background color
                 "transparent", 
                 "in", # unit
                 120 #dpi / resolution
  )
  currentPlotDev <- dev.cur()
  #print the plot to the plot device
  extractLegend <- FALSE
  if(!is.null(mappingData$showOnlyLegend)){
  	if(mappingData$showOnlyLegend){
  		extractLegend <- TRUE
  	}
  }
  if(extractLegend){
  	if(ggplot2::is.ggplot(currentPlot)){
  		currentPlot <-  currentPlot + ggplot2::guides(colour=ggplot2::guide_legend(ncol = NULL))
  	}
  	showExtractedLegend(currentPlot)
  	pixelAxisMapping <- data.frame(px1=NA,px2=NA,
  																 py1=NA,py2=NA,
  																 ax1=NA,
  																 ax2=NA,
  																 ay1=NA,
  																 ay2=NA,
  																 facetName1=NA,
  																 facetValue1=NA,
  																 facetName2=NA,
  																 facetValue2=NA)
  } else {
  	if(ggplot2::is.ggplot(currentPlot)){
  		if(!is.null(mappingData$xUnitString)){
  			currentPlot$labels$x <- paste0(currentPlot$labels$x, mappingData$xUnitString)
  		}
  		if(!is.null(mappingData$yUnitString)){
  			currentPlot$labels$y <- paste0(currentPlot$labels$y, mappingData$yUnitString)
  		}
  		if(!is.null(currentPlot$labels)){
  			if(!is.null(currentPlot$labels$colour)){
  				if(nchar(currentPlot$labels$colour) > 29) {
  					currentPlot<- currentPlot + ggplot2::guides(colour=ggplot2::guide_legend(title=gsub(",","\n",currentPlot$labels$colour)))
  				}
  			}
  		}
  		#currentPlot<- currentPlot + ggplot2::theme(legend.text=ggplot2::element_text(size=7))
  		print(currentPlot)
  		pixelAxisMapping <- getPanelPositions(currentPlot)
  		autoShrinkLegend <- TRUE
  		if(!is.null(mappingData$legendFontSize)){
  			if("auto"!=mappingData$legendFontSize){
  				#if the legend font size is set manually, don't apply auto shrinking
  				autoShrinkLegend <- FALSE
  			}
  		}
  		if(max(pixelAxisMapping$px2)/pixelWidth < 0.6 & autoShrinkLegend){
  			newTextSize <- 7*0.4/(1-max(pixelAxisMapping$px2)/pixelWidth)
  			currentPlot<- currentPlot + ggplot2::theme(legend.title=ggplot2::element_text(size=newTextSize*1.33),
  																								 legend.text=ggplot2::element_text(size=newTextSize),
  																								 legend.key.size = grid::unit(newTextSize*1.1,"pt"))
  			currentPlot<- currentPlot +  guides(colour=ggplot2::guide_legend(ncol = 1, override.aes = list(size=1)), shape = FALSE)
  			#print(newTextSize)
  			#grid::grid.newpage()
  			print(currentPlot)
  			#pixelAxisMapping <- getPanelPositions(currentPlot)
  		}
  	} else {
  		#in case currentPlot is no single ggplot object:
  		#print(length(currentPlot))
  		pixelAxisMapping <- getPanelPositions(currentPlot,
  																					gridPlotsTogether = TRUE,
  																					gridwidth = mappingData$gridwidth,
  																					gridheight = mappingData$gridheight,
  																					gridlayout = mappingData$gridlayout)
  	}
  }
  #close the plot device (and write changes to file)
  dumpOutput <- grDevices::dev.off(which=currentPlotDev)
  #print(reprPlotTmpFile)
  #read the temporary file and send the result to the jupyter front end
  tryCatch(
    if(showOnJupyter) {
      IRdisplay::display_png(readBin(reprPlotTmpFile, raw(), file.info(reprPlotTmpFile)$size))
    },
    warning = function(w) {
    if(grepl("IRdisplay can only be used from the IPython R kernel and R magic", as.character(w)))
    {
      img <- png::readPNG(reprPlotTmpFile)
      plot.new()
      rasterImage(img,0,0,1,1)
      
    }})
  return(pixelAxisMapping)
}
