#
#overlay plots try to make it possible to overlay multiple plots together.
#it copies the old plot object into the new and generates some important variables like "plot" and stuff for limit handling.
#To use this, it is important that after a call "newPlot$includePlotToOverlay(oldPlot)", the data has to be provided to the ggplot functions. Example:
#newPlot <- temboPlot$new()
#newPlot$setData(data.frame(x=1:3,y=1:3))
#newPlot$includePlotToOverlay(oldPlot)
#newPlot$addToPlot(ggplot2::geom_line(data=newPlot$data, ggplot2::aes(x,y)))
temboPlot$methods(
  includePlotToOverlay = function(temboPlotObject){
  	"Includes a plot to overlay, the plot must be of the temboPlot class. This function makes sure that scale informations as well as limits and grouping are preserved for the new plot."
    .internalMapping$overlayedPlot <<- temboPlotObject$copy()
    .internalMapping$labelsAnnotate <<- temboPlotObject$.internalMapping$labelsAnnotate
    .internalMapping$tmpVec <<- temboPlotObject$.internalMapping$tmpVec
    .internalMapping$tmpLimits <<- temboPlotObject$.internalMapping$tmpLimits
    .internalMapping$shapeMapping <<- temboPlotObject$.internalMapping$shapeMapping
    .internalMapping$colourMapping <<- temboPlotObject$.internalMapping$colourMapping
    plot <<- temboPlotObject$plot
    .internalMapping$x <<- temboPlotObject$.internalMapping$x
    .internalMapping$y <<- temboPlotObject$.internalMapping$y
    .plotXScaleTransform <<- temboPlotObject$.plotXScaleTransform
    .plotYScaleTransform <<- temboPlotObject$.plotYScaleTransform
  }
)