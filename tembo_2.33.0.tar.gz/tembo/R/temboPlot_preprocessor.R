temboPlot$methods(
  addPreprocessor = function(fn){
    .preprocessor <<- fn
  })