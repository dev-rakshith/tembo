#after creating a temboPlot object for the spider chart, the setSpiderAesthetics() function is needed.
#Example:
#  exampleSpider <- tembo::temboPlot$new()
#  tmpDf <- as.data.frame(mtcars)
#  tmpDf$name <- rownames(mtcars)
#  exampleSpider$addData(tmpDf)
#  exampleSpider$setSpiderAesthetics("mpg,cyl,disp,qsec,wt","name",normalizeToMax = TRUE)
#  exampleSpider$addSpiderchart()
#  print(exampleSpider)


temboPlot$methods(
  setSpiderAesthetics = function(features, grouping = NULL, normalizeToMax = FALSE) {
    variableList <- unlist(strsplit(gsub(" *, *", ",", features),split=","))
    #print(variableList)
    .plotData <<- data[,variableList]
    if(!is.null(grouping)){
      groups <- splitStrings(grouping)
      if(length(groups) > 1) {
        .plotData$groups <<- customInteraction(data[,groups], sep = "; ")
      } else {
        .plotData$groups <<- as.factor(data[[groups]])
        .plotData <<- .plotData[!duplicated(.plotData$groups),]
      }
    } else {
      .plotData$groups <<- "1"
      .plotData <<- .plotData[!duplicated(.plotData$groups),]
    }
    # Check for negative and positive values mixed:
    for( name in colnames(.plotData)[colnames(.plotData) != "groups"]){
      #print(.plotData[[name]])
      #why is the data a character?
      .plotData[[name]] <<- as.numeric(.plotData[[name]])
      if( any(.plotData[[name]] > 0) & any(.plotData[[name]] < 0)){
        stop(paste("column '",name,"'", "has positive and negative numbers, which is not meaningful in a spider chart."))
      }
    }
    if(normalizeToMax){
      spiderTmp <- data.frame(groups=.plotData[,"groups"])
      for( loopName in colnames(.plotData)[colnames(.plotData) != "groups"]){
        tmpSpiderMaxValue <- .plotData[[loopName]][which.max(abs(.plotData[[loopName]]))]
        tmpValue <- tembo::format_si()(tmpSpiderMaxValue)
        if(nrow(limits)>0){#do unit handling
          if(any(limits$name %in% loopName)) {#do any limits fit the loopName?
            currentLimit <- subset(limits, name == loopName)
            if(!is.null(currentLimit$unit)){
              currentLimit <- subset(currentLimit, !is.na(unit))
              if(nrow(currentLimit) > 0){
                tmpValue <- tembo::format_si(unit=currentLimit$unit[1])(tmpSpiderMaxValue)
                #print(currentLimit$unit[1])
                if(!is.null(currentLimit$scale)){
                  #the scale column exists
                  currentLimit <- subset(currentLimit, !is.na(scale))
                  if(nrow(currentLimit) > 0){
                    tmpValue <- tembo::format_si(unit=currentLimit$unit[1], scale=as.numeric(currentLimit$scale[1]))(tmpSpiderMaxValue)
                  }
                }
              }
            }
          }
        }
        tmpSpiderName <-paste0(loopName," (",tmpValue,")")
        spiderTmp[[tmpSpiderName]] <- abs(.plotData[[loopName]]/max(abs(.plotData[[loopName]])))
      }
      .plotData <<- spiderTmp
      
    }
    .plotYScaleTransform <<- "linear"
    .plotXScaleTransform <<- "linear"
  },
  addSpiderchart = function(font.radar = "sans", 
                            grid.label.size = 5, 
                            axis.label.size = 3,
                            legend.text.size = 10,
                            group.line.width = 0.5,
                            group.point.size=3){
    #ggradar assuems the first column to be the grouping, so it is reordered:
    .plotData <<- .plotData[,c(which(colnames(.plotData)=="groups"),which(colnames(.plotData)!="groups"))]
    #print(.plotData)
    plot[[1]] <<- ggradar::ggradar(.plotData,
                                   font.radar = font.radar,
                                   grid.label.size = grid.label.size,
                                   axis.label.size = axis.label.size,
                                   legend.text.size = legend.text.size,
                                   group.line.width = group.line.width,
                                   group.point.size = group.point.size)
    addToPlot(ggplot2::theme(legend.text=ggplot2::element_text(size=7)))
  }
)