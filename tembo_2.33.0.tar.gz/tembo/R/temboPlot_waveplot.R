

#the waveplots need a specific order.
#first: addWaveformSignal(cname) #cname is the signal name, it is loaded from an fsdb file or the a data column, depending on data format
#second: filterData(t < 1)#filterData filters in case of an waveform only the last added signal
#third: setSignalLabel("label) #label of the last added signal
#fourth: setSignalFacet("facet 1")#facet to which the signal should be added
temboPlot$methods(
  addWaveformSignal = function(cname,dataLakeToken=""){
    if('dummy' %in% colnames(data)){
      if(!cname %in% colnames(data) ){
        stop("Signal with name: ", cname, " does not exist.")
      }
      tmp <- data[[cname]][[1]]
      tmpDf <- data.frame(t=tmp$t,y=tmp$y,dataGroup=cname,stringsAsFactors = FALSE)
      tmpDf$Signals <- cname
    } else if(any(c("waveform_file", "raw_data_link_filename", "raw_data_link_data_lake_id") %in% names(data))) {
      for(i in 1:nrow(data)){
        if(!any(is.na(data$waveform_file[i]),is.na(data$waveform_format[i]),is.null(data$waveform_file))){
          fsdbFileName <- data$waveform_file[i]
          if(data$waveform_format[i] == "fsdb"){
            #stop(dat$waveform_format[i])
            .internalMapping$fsdbIndex <<- getFsdbIndexFromServer(fsdbFileName, .internalMapping$fsdbIndex)
          }
        } else {
          if(!any(is.na(data$raw_data_link_data_lake_id[i]),is.na(data$raw_data_link_type[i]),is.null(data$raw_data_link_data_lake_id))){
            if(! 'raw_data_link_filename' %in% names(data)){
              data$raw_data_link_filename <<- NA
            }
            if(data$raw_data_link_type[i] == "fsdb" & dataLakeToken != "" & is.na(data$raw_data_link_filename[i])){
              #stop(dat$waveform_format[i])
              tmp <- strsplit(data$raw_data_link_data_lake_id[i], "/")
              data$raw_data_link_filename <<- getArtifact(project = tmp[[1]][1],
                                                          artifactID = tmp[[1]][2],
                                                          token = dataLakeToken)
            }
          }
          if(!any(is.na(data$raw_data_link_filename[i]),is.na(data$raw_data_link_type[i]),is.null(data$raw_data_link_filename))){
            fsdbFileName <- data$raw_data_link_filename[i]
            if(data$raw_data_link_type[i] == "fsdb"){
              #stop(dat$waveform_format[i])
              .internalMapping$fsdbIndex <<- getFsdbIndexFromFile(fsdbFileName, .internalMapping$fsdbIndex)
            }
          }
        }
        fsdbIndex <- .internalMapping$fsdbIndex
      }
      tmpSplits <- strsplit(cname, "\\.")
      if(length(tmpSplits[[1]])>1){
        tmpScope <- paste0(tmpSplits[[1]][1:(length(tmpSplits[[1]])-1)], collapse=".")
        allSignals <-fsdbIndex[fsdbIndex$scope==tmpScope & fsdbIndex$name==tmpSplits[[1]][length(tmpSplits[[1]])],]
        signalIndex <- allSignals$index
        fsdbFileName <- allSignals$filename
        fsdbFileOnServer <- allSignals$isOnFsdbServer
      } else if(length(tmpSplits[[1]]) == 1) {
        allSignals <- fsdbIndex[fsdbIndex$name==tmpSplits[[1]][1],]
        signalIndex <- allSignals$index
        fsdbFileName <- allSignals$filename
        fsdbFileOnServer <- allSignals$isOnFsdbServer
        #stop(length(fsdbFileName))
      } else {
        stop("Signal not valid")
      }
      cname <- tmpSplits[[1]][length(tmpSplits[[1]])]
      if(length(signalIndex) == 0){
        stop(paste("no signal found with", cname))
      }
      tmpDf <- data.frame(stringsAsFactors = FALSE)
      #stop(length(signalIndex))
      for(i in 1:length(signalIndex)){
      	#stop(signalIndex[i])
        if(fsdbFileOnServer[i]){
          signal <- loadFSDBDataFromServer(fsdbFileName[i], signalIndex[i])
        } else {
          signal <- loadFSDBDataFromFile(fsdbFileName[i], signalIndex[i])
        }
        tmp <- signal$signal
        if( length(signalIndex) > 1){
          fileRowNumber <- which(dat$waveform_file == fsdbFileName[i])[1]
          signalInFileNumber <- which(signalIndex[fsdbFileName==fsdbFileName[i]]==signalIndex[i])[1]
          if(signalInFileNumber > 1) {
            tmp2Df <- data.frame(t=tmp$t,y=tmp$y,dataGroup=paste0(fileRowNumber, "-", signalInFileNumber, ": ", cname),stringsAsFactors = FALSE)
            tmp2Df$Signals <- paste0(fileRowNumber, "-", signalInFileNumber, ": ", cname)                  
          } else {
            tmp2Df <- data.frame(t=tmp$t,y=tmp$y,dataGroup=paste0(fileRowNumber, ": ", cname), stringsAsFactors = FALSE)
            tmp2Df$Signals <- paste0(fileRowNumber, ": ", cname)
          }
          tmpDf <- rbind(tmpDf, tmp2Df)
        } else {
          tmpDf <- data.frame(t=tmp$t,y=tmp$y,dataGroup=cname, stringsAsFactors = FALSE)                
          tmpDf$Signals <- cname
        }
      }
    }
    if(is.null(.internalMapping$currentSignalNumber)){
      .internalMapping$currentSignalNumber <<- 1
      .internalMapping$currentSignals <<- list()
    } else {
      .internalMapping$currentSignalNumber <<- .internalMapping$currentSignalNumber + 1
    }
    .internalMapping$currentSignals[[.internalMapping$currentSignalNumber]] <<- tmpDf
    .internalMapping[['x']] <<- 't'
    .internalMapping[['y']] <<- 'y'
    
  },
  selectAllSignals = function() {
    "when added signals in a data.frame, this functions tries to autoselect all signals for plotting"
    for(signal in names(data)){
      if(signal == "dummy"){
        next
      }
      addWaveformSignal(signal)
      #currentTemboPlot$setSignalFacet(signal)
    }
  },
  setSignalLabel = function(label){
    .internalMapping$currentSignals[[.internalMapping$currentSignalNumber]]$Signals <<- label
  },
  setSignalFacet = function(label){
    .internalMapping$currentSignals[[.internalMapping$currentSignalNumber]]$facet <<- label
  },
  autoGroupSignals = function(){
    signalGroups <- data.frame(stringsAsFactors = FALSE)
    
    for(signalId in 1:length(.internalMapping$currentSignals)){
      signal <- .internalMapping$currentSignals[[signalId]]$Signals[1]
      if(signal == "dummy"){
        next
      }
      newSignal <- data.frame(name=signal, stringsAsFactors = FALSE)
      if(signal %in% limits$name){
        #print(which(signal %in% currentLimits$name)[1])
        #print(currentLimits$unit[which(signal %in% currentLimits$name)[1]])
        newSignal$unit <- as.character(limits$unit[which(signal == limits$name)[1]])
      } else {
        newSignal$unit <- ""
      }
      newSignal$mean <- mean(.internalMapping$currentSignals[[signalId]]$y)
      newSignal$sd <- sd(.internalMapping$currentSignals[[signalId]]$y)
      #print(newSignal)
      if(nrow(signalGroups)>0){
        newSignal$group <- max(signalGroups$group) + 1
        if(newSignal$unit %in% signalGroups$unit) {
          sds <- newSignal$sd/signalGroups$sd
          similarSds <- (sds < 5 & sds > 0.2) # between 80% similarity of sd
          if(any(similarSds)){
            distances <- abs(signalGroups$mean - newSignal$mean)/newSignal$sd
            if(any(distances[which(similarSds)]<5)) {
              firstGroup <- which(distances[which(similarSds)]<5)[1]
              newSignal$group <- (signalGroups$group[similarSds])[firstGroup]
            }
          }
        }
      } else {
        newSignal$group <- 1
      }
      #.internalMapping$currentSignals[[signalId]]$dataGroup <<- paste(newSignal$group)
      .internalMapping$currentSignals[[signalId]]$facet <<- newSignal$group
      signalGroups <- rbind(signalGroups,newSignal)
    }
    # for(group in unique(signalGroups$group)) {
    #   .plotData$dataGroup[.plotData$Signals %in% signalGroups$name[signalGroups$group==group]] <<- paste(group)
    #   .plotData$facet[.plotData$Signals %in% signalGroups$name[signalGroups$group==group]] <<- group
    # }
    #print(signalGroups)
  },
  plotWaveform = function(removeAxisNames = FALSE){
    .plotData <<- data.frame(stringsAsFactors = FALSE)
    for(i in 1:.internalMapping$currentSignalNumber){
      .plotData <<- rbind(.plotData, .internalMapping$currentSignals[[i]])
    }
    plots <- list()
    #print(unique(newDat$facet))
    for(i in split(.plotData, as.factor(.plotData$facet))){
      #print(unique(i$facet))
      #print(nrow(i))
      tmpPlot <- ggplot2::ggplot(i) + geom_line_reduced(ggplot2::aes(x=t,y=y,group=dataGroup,color=Signals))
      tmpPlot <- tmpPlot + ggplot2::labs(colour = "Signals", x="Time [s]", y="Value") + ggplot2::scale_x_continuous(labels = tembo::format_si(digits=2)) + ggplot2::scale_y_continuous(labels = tembo::format_si())
      if(!removeAxisNames){
        tmpPlot <- tmpPlot + ggplot2::facet_grid(facet~.)
      }else {
        #tmpPlot <- tmpPlot + ggplot2::facet_null()
      }
      plots[[length(plots)+1]] <- tmpPlot
    }
    plot <<- plots
    .plotYScaleTransform <<- "linear"
    .plotXScaleTransform <<- "linear"
    if(length(plots)==1){
      addToPlot(ggplot2::facet_null())
      #	currentPlot <- plots
    } else {
    	.internalMapping$gridwidth <<- c(1)
    	.internalMapping$gridheight <<- rep(1,length(plot))
    	.internalMapping$gridlayout <<- matrix(1:length(plot), nrow=length(plot))
      fixXAxisOnMultiplot()
    }
    if(length(plot) == 1){
    	addToPlot(ggplot2::theme(legend.text=ggplot2::element_text(size=7)))
    }
  },
  fixXAxisOnMultiplot = function(){
    #the following codes makes sure, that all x-axis on the plot show exactly the same range at the same positions:
    ggList <- lapply(plot, ggplot2::ggplot_build) #Builds the plot data itself   
    xrange <- ggList[[1]]$layout$panel_params[[1]]$x.range
    for(i in 2:length(ggList)){
      .plotYScaleTransform[i] <<- "linear"
      .plotXScaleTransform[i] <<- "linear"
      xrangeNew <- ggList[[i]]$layout$panel_ranges[[1]]$x.range
      xrange[1] <- min(xrange, xrangeNew)
      xrange[2] <- max(xrange, xrangeNew)
    }
    for(i in 1:length(ggList)){
      addToPlot(ggplot2::coord_cartesian(xlim=xrange, expand=FALSE),
      					facetNr = i)
      if(i < length(ggList)) {
      	addToPlot(ggplot2::theme(axis.title.x=ggplot2::element_blank(),
                                                 axis.text.x=ggplot2::element_blank(),
                                                 axis.ticks.x=ggplot2::element_blank()),
      						facetNr = i)
      }    
    }
  }
)