#' A Reference Class to represent a bank account.
#' @export temboQuery
#' @exportClass temboQuery
temboQuery <- setRefClass("temboQuery",
                       
  fields = c("must", "must_not", "source"),
  
  methods = list(
               
    initialize = function(source=list()) {
      source<<-source
      must<<-c()
    },
    
    addMatch = function(name, value) {
      temp<-list();
      temp[[name]]<-value;
      must<<-append(must, list(list(match=temp)))
    },
    
    getJSON = function () {
      theQuery<-list(query=list(bool=list(must=must))) #, `_source`=source)
      return(jsonlite::toJSON(theQuery, auto_unbox = TRUE, pretty = TRUE))
    }
    
  )
)


#x<-temboQuery$new(list("Lot","Wafer","X"))
#x$addMatch("Lot", "VE541748")
#x$addMatch("Wafer", "5")
#print(x$getJSON())