############################################################################################
#' Tembo recipe class
#' 
#' \emph{Copyright (c) 2019 Infineon Technologies}
#' @export temboRecipe
#' @exportClass temboRecipe
#' @author Kunze Matthias (IFAG ATV PTP MSF DM), \email{matthias.kunze2@infineon.com}
temboRecipe <- setRefClass("temboRecipe",

  ############################################################################################                          
  # Properties                         
  ############################################################################################
  fields = c("serverBaseURL", "recipe", "parsed"),

  ############################################################################################
  # Methods    
  ############################################################################################
  methods = list(
    
    ############################################################################################
    #' Constructor
    initialize = function(id=NULL, serverBaseURL="https://tembo-dev.intra.infineon.com/TEMBO_Dev") {
    	"initializes the recipe object"
      serverBaseURL<<-serverBaseURL
      
      if (!is.null(id)) {
        # Load existing recipe
        loadRecipe(id)
      } else {
        # create new recipe
        newRecipe()
      }
    },

    ############################################################################################
    newRecipe = function () {
    	"create an empty recipe and store it in the parsed class variable."
      parsed<<-XML::newXMLDoc(node=XML::newXMLNode("Recipe",
                                                   XML::newXMLNode("Name", 
                                                                   XML::newXMLTextNode("Untitled"))))
    },
    
    ############################################################################################
    loadRecipe = function (id) {
    	"load recipe with given id from tembo server"
      response<-httr::GET(paste0(serverBaseURL, '/api/recipe/GetRecipe?recipeId=', id),
                             httr::authenticate("", "", "ntlm"), httr::config(ssl_verifypeer=0L))
      if (response$status_code>299) stop(paste0('Embedded recipe with id "', recipeID, '" could not be loaded\n\nHttp response:\n', httr::content(response, type = "text")))      
      recipe<<-httr::content(response) 
      
      # Flag textual recipe
      recipe$Textual<<-any(unlist(sapply(c('rcodes/requirementCheck.xsl', 'rcodes/create_overview_table.xsl', 'rcodes/create_yield_pareto_table.xsl', 'rcodes/calc_statisticalIndicators.xsl', 'rcodes/dist_comparison.xsl'), grepl, recipe$Recipe)))
    },

    ############################################################################################
    saveRecipe = function (id=NULL, reportId=NULL, reportPageId=NULL, hide=FALSE, queue="") {
      "saves recipe"
      
      # Convert to string
      if (is.logical(hide)) {
        if (hide) hide<-"true"
        else      hide<-"false"
      }
      
      if (!is.null(reportPageId)) {
        # Check for not NA is needed for report template debugging --> there reportPageId is set to NA to avoid storage of report id
        if (!is.na(reportPageId)) {
          XML::addChildren(XML::xmlRoot(parsed), XML::newXMLNode("ReportPageId", XML::newXMLTextNode(reportPageId)))
        }
      }
      
      if (queue=="") {
        queueParam<-''
      } else {
        queueParam<-paste0('&queueName=', xml2::url_escape(queue))
      }
      
      if (is.null(id)) {
        if (is.null(reportId)) {
          response<-httr::POST(paste0(serverBaseURL, '/api/recipe/AddRecipes?hide=', hide, queueParam),
                               body = paste0("['", XML::saveXML(parsed), "']"),
                               httr::content_type("application/json"),
                               httr::authenticate("", "", "ntlm"), httr::config(ssl_verifypeer=0L))
        } else {
          response<-httr::POST(paste0(serverBaseURL, '/api/recipe/AddRecipes?hide=', hide, '&reportId=', reportId, queueParam),
                               body = paste0("['", XML::saveXML(parsed), "']"),
                               httr::content_type("application/json"),
                               httr::authenticate("", "", "ntlm"), httr::config(ssl_verifypeer=0L))
        }
        if (response$status_code>299) stop(paste0('Recipe could not be saved\n\nHttp response:\n', httr::content(response, type = "text")))      
        content<-httr::content(response)      
        
        if (content$Status$IsSuccess==FALSE) stop(content$Status$Message)
        
      } else {
        
        XML::newXMLNode("Id", XML::newXMLTextNode(id), parent = XML::xmlRoot(parsed))
        
        response<-httr::POST(paste0(serverBaseURL, '/api/recipe/UpdateRecipe'),
                             body = paste0("'", XML::saveXML(parsed), "'"),
                             httr::content_type("application/json"),
                             httr::authenticate("", "", "ntlm"), httr::config(ssl_verifypeer=0L))
        if (response$status_code>299) stop(paste0('Recipe could not be saved\n\nHttp response:\n', httr::content(response, type = "text")))      
        content<-httr::content(response)      
        
        if (content$Status$IsSuccess==FALSE) stop(content$Status$Message)
      }
      
      return(content$AddedRecipeIds[[1]])
    },
    
    ############################################################################################
    saveRecipeAsReportAction = function (actionLabel="do something", id=NULL, reportId=NULL, hide=FALSE, queue="REPORTACTION_NOAUTOEXEC") {
      "saves recipe as an action item for the report"
      if(is.null(reportId)){
        stop("You need to provide a reportId when you try to add a recipe as en action item")
      }
      recipeId <- saveRecipe(id=id, reportId=NULL, hide=hide, queue=queue)
      response<-httr::POST(paste0(serverBaseURL, '/api/Report/', reportId,'/Action'),
                           body=paste0('{ "XmlRecipeId": "', recipeId[], '","Label": "',actionLabel,'" }'),
                           httr::content_type("application/json"),
                           httr::authenticate("", "", "ntlm"),
                           httr::config(ssl_verifypeer=0L)
      )
      if (response$status_code>299) stop(paste0('Action item could not be saved\n\nHttp response:\n', httr::content(response, type = "text")))      
      return(recipeId)
    },
    
    ############################################################################################
    addStep = function (template, ...) {
    	"adds a recipe step"
      
      params<-list(...)
      
      ApplyTemplateNode<-XML::newXMLNode("ApplyTemplate", parent=XML::xmlRoot(parsed), attrs=c(href=paste0("rcodes/", template,".xsl"), enabled="true"))        
      
      if (!is.null(params)) {
        for (paramName in names(params)) {
          
          # Remove potentially already existing param nodes with same name
          if(paramName != "table"){
            XML::xpathSApply(parsed, paste0("//ApplyTemplate[last()]/param[name='", paramName,"']"), XML::removeNodes)
          }

          if ("XMLInternalNode" %in% class(params[[paramName]])) {
            # This is a XML node -> copy into document as parameter
            # This is needed for building up recipe steps with data finder usage
            node<-XML::newXMLNode("param", 
                            XML::newXMLNode("name", XML::newXMLTextNode(paramName)),
                            XML::newXMLNode("value", XML::xmlClone(params[[paramName]], recursive = TRUE)), 
                            parent = ApplyTemplateNode)
                            
          } else if ("character" %in% class(params[[paramName]])) {
            # This is a string --> Add value as text node
            node<-XML::newXMLNode("param", 
                            XML::newXMLNode("name", XML::newXMLTextNode(paramName)),
                            XML::newXMLNode("value", XML::newXMLTextNode(params[[paramName]])), 
                            parent = ApplyTemplateNode)
          } else if (is.list(params[[paramName]])) {
            tab<-params[[paramName]]
            for(i in 1:length(tab)){
              xml <- paste0(
                "<row><column>",
                paste0(tab[[i]],collapse="</column><column>"),
                "</column></row>"
              )
              node<-XML::newXMLNode("param", 
                                    XML::newXMLNode("name", "table"),
                                    XML::xmlParse(xml),
                                    parent = ApplyTemplateNode)
            }
            value <- paste(unlist(lapply(tab, function(x) paste(x,collapse="\t"))),collapse="\n")
          } else if (is.na(params[[paramName]])) {
            # Is NA --> omit this one
            
          } else {
            # Not supported class
            stop('Parameter "', paramName, '" of type ', class(params[[paramName]]), ' is not supported.')
          }
        }
      }
    },

    ############################################################################################
    makeGeneric = function (mappingUsed=FALSE) {
      "Make recipe generic"
      # If recipe is already generic, warn and do nothing
      if (grepl('\\$paramname\\$', recipe$Recipe)) {
        warning('Recipe is already generic, nothing changed')
        return()
      }
      
      parsed<<-XML::xmlParse(recipe$Recipe)
      
      ######################################################################################################
      # Find candidates for main parameter
      ######################################################################################################
      main_parameter<-XML::xpathSApply(parsed, 
                                       "//ApplyTemplate/param[name='data']/value |
                                       //ApplyTemplate/param[name='y']/value |
                                       //ApplyTemplate/param[name='param']/value |
                                       //ApplyTemplate/param[name='variable']/value",
                                       XML::xmlValue)
      main_parameter<-unique(main_parameter)
      
      # Error if main parameter can not be clearly identified
      if (length(main_parameter)!=1) stop('Main parameter could not be identified in recipe:\n\n', recipe)
      
      ######################################################################################################
      # Add placeholders
      ######################################################################################################
      
      # Set placeholders for main parameter (depends on whether mapping is selected)
      if (mappingUsed) {
        paramSource<-'commonName'
      } else {
        paramSource<-'payload'
      }
      x<-XML::xpathApply(parsed, '//param[not(name="filter")]/value', function(x) XML::xmlValue(x)<-gsub(paste0('payload.', main_parameter), paste0(paramSource, '.$paramname$'), XML::xmlValue(x)))
      x<-XML::xpathApply(parsed, '//param[not(name="filter")]/value', function(x) XML::xmlValue(x)<-gsub(paste0('commonName.', main_parameter), paste0(paramSource, '.$paramname$'), XML::xmlValue(x)))
      x<-XML::xpathApply(parsed, '//param[not(name="filter")]/value', function(x) XML::xmlValue(x)<-gsub(main_parameter, '$paramname$', XML::xmlValue(x)))
      
      # Set placeholders in query template
      x<-XML::xpathApply(parsed, '//ApplyTemplate[@href=\"rcodes/query.xsl\"]/param[name="index"]/value', function(x) XML::xmlValue(x)<-'$index$')        
      x<-XML::xpathApply(parsed, '//ApplyTemplate[@href=\"rcodes/query.xsl\"]/param[name="filter"]/value', function(x) {
        if (length(XML::getNodeSet(x, 'filters'))>0) XML::removeChildren(x, 'filters')
        XML::xmlValue(x)<-'$filter$'
      })
      x<-XML::xpathApply(parsed, '//ApplyTemplate[@href=\"rcodes/query.xsl\"]/param[name="query"]/value', function(x) XML::xmlValue(x)<-'$query$')
      x<-XML::xpathApply(parsed, '//ApplyTemplate[@href=\"rcodes/query.xsl\"]/param[name="mapping"]/value', function(x) XML::xmlValue(x)<-'$mappingid$')
      
      ######################################################################################################  
      # Add "Add results" step
      ######################################################################################################
      #recipe<-XML::saveXML(parsed)
      #recipe<-gsub('&lt;/Recipe>','&lt;ApplyTemplate href="rcodes/save_results.xsl" enabled="true">
      #  &lt;param>&lt;name>reportPageID&lt;/name>&lt;value>$reportpageid$&lt;/value>&lt;/param>
      #  &lt;/ApplyTemplate>
      #&lt;/Recipe>', recipe)
    
      ######################################################################################################
      # Done...
      ######################################################################################################
      #return(recipe)
    }
  )
)    