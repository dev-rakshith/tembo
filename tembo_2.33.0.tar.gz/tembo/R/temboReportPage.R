############################################################################################
#' Tembo report page class
#' 
#' \emph{Copyright (c) 2019 Infineon Technologies}
#' @export temboReportPage
#' @exportClass temboReportPage
#' @author Kunze Matthias (IFAG ATV PTP MSF DM), \email{matthias.kunze2@infineon.com}
temboReportPage <- setRefClass("temboReportPage",

  ############################################################################################                          
  # Properties                         
  ############################################################################################
  fields = c("id", "reportId", "doc", "newContent", "serverBaseURL", "temboStore", "paramname", "recipeCount", "recipeLimit", "tabContainer", 
             "paramnameChanged", "recipeQueue"),

  ############################################################################################
  # Methods    
  ############################################################################################
  methods = list(
    
    ############################################################################################
    #' Constructor
    initialize = function(id=NULL, reportId=NULL, serverBaseURL="https://tembo-dev.intra.infineon.com/TEMBO_Dev", temboStore=NULL) {
      
      serverBaseURL<<-serverBaseURL
  	  temboStore<<-temboStore
      recipeCount<<-0
      recipeLimit<<-20
      reportId<<-reportId
      recipeQueue<<-''
      
      if (!is.null(id)) {
        id<<-id
        loadPage(id)
      }
  	  
  	  tabContainer<<-c()
  	  paramnameChanged<<-FALSE;
  	  addCommentField("") 
    },

    ############################################################################################
    #' Load page
    #' 
    #' @param html
    loadPage = function (id) {
      if (class(id)!="uninitializedField" && !is.na(id) && !is.null(id)) {
        # Not called within local report development flow
        response<-httr::GET(paste0(serverBaseURL, "/api/Report/", reportId, "/Page/", id, "/Content"),
                            httr::content_type("application/json"), httr::authenticate("", "", "ntlm"),
                            httr::config(ssl_verifypeer=0L))
  
        if (response$status_code>299) stop(paste0('Report page could not be fetched\n\nHttp response:\n', httr::content(response, type = "text")))
        
        doc<<-XML::xmlParse(paste0('<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" "http://www.w3.org/TR/REC-html40/loose.dtd"><html>', 
                                   httr::content(response, "text"), '</html>'), 
                            encoding = "UTF-8")
      }
    },

    ############################################################################################
    #' Save to file
    #' 
    #' @param html
    saveToFile = function (filename) {
      XML::saveXML(doc, file=filename)
    },
    
    ############################################################################################
    #' Update page
    updatePage = function (url) {
      content<-XML::saveXML(doc)
      
      # Report pages are stored as html snippets --> remove html tag and body tag (added by XML::htmlParse)
      content<-sub(".*<html>", '', content)
      content<-sub("</html>.*", '', content)
      content<-sub(".*<body>", '', content)
      content<-sub("</body>.*", '', content)

      if (paramnameChanged) {
        ############################################################################################
        # Parameter name has changed --> use /api/Report/Page endpoint with DB access
        ############################################################################################
        requestBody=list()
        if (is.null(paramname)) {
          requestBody$ResultName="unknown"
        } else {
          requestBody$ResultName=paramname        
        }
        requestBody$Content=content
        response<-httr::PUT(paste0(serverBaseURL, "/api/Report/Page/", id), 
                            body = jsonlite::toJSON(requestBody, auto_unbox = TRUE),
                            httr::content_type("application/json"), httr::authenticate("", "", "ntlm"),
                            httr::config(ssl_verifypeer=0L))
        if (response$status_code>299) stop(paste0('Report page could not be updated\n\nHttp response:\n', httr::content(response, type = "text")))
        
      } else {
        ############################################################################################
        # Parameter name has not changed, use api/Report/{reportId}/Page/{id} endpoint without DB access
        # Do no set ResultName. If set, DB update is done
        ############################################################################################
        requestBody=list()
        requestBody$Content=content
        response<-httr::PUT(paste0(serverBaseURL, "/api/Report/", reportId,"/Page/", id), 
                            body = jsonlite::toJSON(requestBody, auto_unbox = TRUE),
                            httr::content_type("application/json"), httr::authenticate("", "", "ntlm"),
                            httr::config(ssl_verifypeer=0L))
        if (response$status_code>299) stop(paste0('Report page could not be updated\n\nHttp response:\n', httr::content(response, type = "text")))
        
      }
    },

    ############################################################################################
    #' Add page data
    #' 
    #' @param html
    addPageData = function (data, filename="rddf.rds") {

      # Store results to temporary file
      folder<-tempfile()
      dir.create(folder)
      rdsFile=file.path(folder, filename)
      saveRDS(data, file=rdsFile)
      
      if (class(id)!="uninitializedField" && !is.na(id) && !is.null(id)) {
        # Upload only if not called within local report development flow
        response<-httr::POST(paste0(serverBaseURL, "/api/Report/Page/", id, "/Files"),
                     body=list(file=httr::upload_file(rdsFile)),
                     httr::content_type("multipart/form-data"),
                     httr::authenticate("", "", "ntlm"),
                     httr::config(ssl_verifypeer=0L),
                     httr::timeout(60))
        if (response$status_code>299) stop(paste0('Result file could not be attached to report page\n\nHttp response:\n', httr::content(response, type="text")))          
      }
    },
    
    ############################################################################################
    #' Add recipe
    #' 
    #' @param html
    addRecipe = function (thisId, tabName=NULL, textual=NULL) {
      if (recipeCount>recipeLimit) {
        stop('Recipe generation limit reached for this page')
      }
      
      if (is(thisId, 'temboRecipe')) {
        # Method was called with recipe object --> save it first
        if (class(id)=="uninitializedField" | is.na(id) | !is.null(id)) {
          # Called within local report development flow
          thisId<-thisId$saveRecipe(reportId=reportId, hide=TRUE)
        } else {
      	  thisId<-thisId$saveRecipe(reportId=reportId, reportPageId=id, queue=recipeQueue)
        }
      } 
      
      recipe<-tembo::temboRecipe(thisId, serverBaseURL=serverBaseURL)
      
      # Optionally overwrite textual flag
      if (!is.null(textual)) {
        if (textual) {
          recipe$recipe$Textual<-TRUE
        } else {
          recipe$recipe$Textual<-FALSE
        }
      }
      
      if (recipe$recipe$Textual) {
        thisContent<-paste0('<a target="_blank" href="', serverBaseURL, '/recipe/', thisId,'">Open recipe</a><iframe src="', serverBaseURL,'/recipe/', thisId,'/result" width="100%" height="300" frameBorder="0"></iframe>')
      } else {
        thisContent<-paste0('<a target="_blank" href="', serverBaseURL,'/recipe/', thisId,'">',
                           '<img src="', serverBaseURL,'/recipe/', thisId,'/result"></img></a>')
      }
      
      if (is.null(tabName)) {
        newContent<<-paste0(newContent, thisContent)
      } else {
        addTabContent(thisContent, tabName)
      }
      
      recipeCount<<-recipeCount+1
    },
    
    ############################################################################################
    #' Add tab content to global container according to the tabName
    #' 
    addTabContent = function (content, tabName) {
      "Add tab content to global container according to the tabName"
      if (tabName %in% names(tabContainer)) {
        tabContainer[tabName]<<-paste0(tabContainer[tabName], "<br/>", content)
      } else {
        tabContainer[tabName]<<-content
      }
    },
    addCommentField = function(comment) {
      "Adds the content of comment to a Tab called Comments"
      addTabContent(comment, "Comments")
    },
    
    ############################################################################################
    #' Add html code
    #' 
    #' @param html
    addHTML = function (..., tabName=NULL) {
	  "Add html code to given tab container"
      thisContent<-paste0(...)
      thisContent<-gsub('\\n', '<br/>', thisContent)
      
      if (is.null(tabName)) {
        newContent<<-paste0(newContent, thisContent)
      } else {
        addTabContent(thisContent, tabName)
      }
    },
    
    ############################################################################################
    #' Add html code to embed local comment
    #' 
    #' @param html
    addLocalComment = function (id, ..., tabName=NULL) {
      "Add html code to embed local comment in given tab container"
      args<-ifelse(length(list(...)) > 0, paste0(names(list(...)), '="', list(...), '"', collapse=" "), "")
      thisContent<-paste0('<div class="localComment" id="', id, '" ', args, '></div>')
      print(thisContent)
      if (is.null(tabName)) {
        newContent<<-paste0(newContent, thisContent)
      } else {
        addTabContent(thisContent, tabName)
      }
    },
    
    ############################################################################################
    #' Add html code to embed image
    #' 
    #' @param html
    addTemboImage = function (imagePath, datalakeResource=FALSE, tabName=NULL, ...) {
      "Add html code to embed image in given tab container"
      args<-ifelse(length(list(...)) > 0, paste0(names(list(...)), '="', list(...), '"', collapse=" "), "")
      if (datalakeResource) {
        thisContent<-paste0('<br/><img src="', serverBaseURL, "/api/Resource/GetResourceImage/", basename(imagePath), '" ', args, '/><br/>')
      } else {
        thisContent<-paste0('<br/><img src="', serverBaseURL, "/api/Resource", dirname(gsub(temboStore, "", gsub("\\", "/", imagePath, fixed=TRUE))), '" ', args, '/><br/>')
      }
      
      if (is.null(tabName)) {
        newContent<<-paste0(newContent, thisContent)
      } else {
        addTabContent(thisContent, tabName)
      }
    },

    ############################################################################################
    #' Add meta data
    #' 
    #' @param html
    addMetaData = function (name, value) {
      newContent<<-paste0(newContent, '<div class="report_meta_data" id="report_meta_data_', name,'" style="display: none;">', value, "</div>")
    },
    
    ############################################################################################
    #' Add page KPIs
    #' 
    #' @param html
    addKPIs = function (...) {
      "Add KPI(s) to the KPI table of the processing parameter"
      if (class(id)!="uninitializedField" && !is.na(id) && !is.null(id)) {
        # Not called within local report development flow
        
        args<-list(...)
  
        # Upload KPIs individualy, bulk operation is currently broken 
        for (thisName in names(args)) {
          
          # Build request body
          body<-list()
          body$Data<-list()
          body$Data$Name<-thisName
          body$Data$Value<-toString(args[[thisName]])
          body$Data$ValueType<-class(args[[thisName]])
          
          # Put KPIs
          response<-httr::PUT(paste0(serverBaseURL, "/api/Report/Page/", id, "/Result"),
                                 body=jsonlite::toJSON(body, auto_unbox=TRUE),
                                 httr::content_type("application/json"), httr::authenticate("", "", "ntlm"),
                                 httr::config(ssl_verifypeer=0L),
                                 httr::timeout(60))
          
          if (response$status_code>299) stop(paste0('KPI could not be added\n\nHttp response:\n', httr::content(response, type = "text")))      
        }
      }
    },
    
    ############################################################################################
    #' Add KPI editor
    #' 
    #' @param html
    addKpiEditor = function (tabName, ...) {
    "Add html code to embed KPI editor to the given tab container and init KPI-column(s)"
      addHTML('<div id="kpiEditor"></div>', tabName=tabName)
      addKPIs(...)
    },
    
    ############################################################################################
    #' 
    updatePageContent = function (divNode=NA) {

      if (is.na(divNode)) {
        divNode<-XML::xpathApply(doc, "//*[@data-type='code'][1]")[[1]]        
      }
      
      # Remove report startup code
      XML::xpathApply(doc, "//*[@data-type='code-report-startup']", XML::removeNodes)
      
      tabContent<-''
      if (length(tabContainer)) {
        tabDefinition<-''
        iComments <- which(names(tabContainer) == "Comments")
        if(iComments != length(tabContainer)){
          # force the comments tab to the last position
          tabContainer <<- tabContainer[c(setdiff(1:length(tabContainer),iComments),iComments)]
        }
        
        for (i in 1:length(tabContainer)) {
          tabDefinition<-paste0(tabDefinition, '<input id="reportTab', i, '" class="reportTabInput" type="radio" name="reportTabs"', ifelse(i == 1, ' checked=""', ''), '/>\n')
          tabDefinition<-paste0(tabDefinition, '<label for="reportTab', i, '" class="reportTabLabel">', names(tabContainer)[i], '</label>\n\n')
          
          if(names(tabContainer)[i] == "Comments"){
            tabContent<-paste0(tabContent, '<div class="tappedReportComments" id="reportTabContent', i, '">\n')
          } else {
            tabContent<-paste0(tabContent, '<div class="tappedReport" id="reportTabContent', i, '">\n')
          }
          tabContent<-paste0(tabContent, '<div class="resolved-code-block">\n')
          tabContent<-paste0(tabContent, '<p>\n')
          tabContent<-paste0(tabContent, paste0(tabContainer[[i]], '\n'))
          tabContent<-paste0(tabContent, '</p>\n')
          tabContent<-paste0(tabContent, '</div>\n</div>\n')
        }
        
        tabContent<-paste0(tabDefinition, tabContent)
      }
      
      # Add user generated content to page
      newNode<-XML::xmlParse(paste0('<div>', tabContent, '<div class="resolved-code-block">\n', newContent, '</div>\n</div>'), encoding = "UTF-8")
      XML::replaceNodes(divNode, newNode)
    },
    
    ############################################################################################
    #' Evaluate code blocks
    evalCodeBlocks = function (userEnvironment) {
    
      # To track parameter name changes
      originalParamname<-paramname
      
      result<-XML::xpathApply(doc, "//*[@data-type='code']", function(divNode) {
        
        # Replace <br/> tags with \n
        # --> The template editor adds <br/> for newlines
        XML::xpathApply(divNode, 'br', function(node) XML::replaceNodes(node, XML::newXMLTextNode('\n')))
        
        code<-XML::xmlValue(divNode)  # R code to be executed
        newContent<<-''               # Container for content generated in user space via addHTML
        
        out<-evaluate::try_capture_stack(parse(text=code), env = userEnvironment)
  
        if (is(out, "error")) {
          
          # Remove code
          XML::xpathApply(divNode, "* | text()", XML::removeNodes)
          
          # Add error to page
          newNode<-XML::xmlParse(paste0('<div class="error"><hr/><b>Error:</b><br/>', 
                                        htmltools::htmlEscape(out$message),
                                        '<hr/><b>Stack:</b><br/>',
                                        paste(sapply(out$calls, function(x) htmltools::htmlEscape(x)), collapse = '<br/><br/>'),
                                        "<hr/></div>"), encoding = "UTF-8")
          XML::addChildren(divNode, newNode)
          
          #Log error message to Tembo database
          httr::POST(paste0(serverBaseURL, '/api/Report/', reportId, '/Error'),
                     body=jsonlite::toJSON(list("Reason"=htmltools::htmlEscape(out$message), "RootCause"="", "Stack"=paste(sapply(out$calls, function(x) htmltools::htmlEscape(x)), collapse = '<br/><br/>')), auto_unbox = TRUE),
                     httr::content_type("application/json"), httr::authenticate("", "", "ntlm"), httr::config(ssl_verifypeer=0L))
          
          
        } else {
          updatePageContent(divNode)
          
        }
      })
      
      # Track parameter name changes
      paramnameChanged<<-!originalParamname==paramname

    },
    
    ############################################################################################
    #' Save report page to file
    save = function (filename) {  
      
      # Create html content
      updatePageContent()
      html<-XML::saveXML(doc)
      html<-stringr::str_replace_all(html, '\n', 'NEWLINE')
      html<-stringr::str_replace(html, '.*<html>(.*<body>)?', '<!DOCTYPE html>
<html>
  <head><link href="https://tembo.intra.infineon.com/Content/site.css" rel="stylesheet"/></head>
  <body>
')
      html<-stringr::str_replace(html, '(</body>.*)?</html>', '  </body>
</html>')
      html<-stringr::str_replace_all(html, 'NEWLINE', '\n')

      # Save to file      
      fileConn<-file(filename)
      writeLines(html, fileConn)
      close(fileConn)
    }
  )
)