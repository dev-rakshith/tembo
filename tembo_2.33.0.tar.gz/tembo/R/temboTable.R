#' Create a temboTable object
#'
#'
#' \emph{Copyright (c) 2018 Infineon Technologies}
#' @return Returns Tembo html table
#' @examples
#' ### create a tembo table object:
#' currentTemboTable <- temboTable$new()
#' ### add the data to the table:
#' currentTemboTable$addData(data)
#' currentTemboTablee$addLimits(currentLimits) #note that this works even if currentLimits does not exist. The function does test for the existence of the variable. Also the limits are necessary even without limit handling, because they provide the units
#' ### filtering is done similar to filtering in subset:
#' currentTemboTable$filterData(cond_tambient == 25)
#' currentTemboTable$filterLimits(cond_tambient == 145)
#' Rendering the table:
#' currentTemboPlot$show()
#' @family tembo table
#' @author Helena Schmidt \email{schmidt.externel9@@infineon.com}
#' @export temboTable
#' @exportClass temboTable
temboTable <- setRefClass("temboTable",
                         fields = list(data = "data.frame",
                                       limits = "data.table",
                                       header = "vector",
                                       units = "vector",
                                       scales = "vector",
                                       table = "list",#list of table stringss in the object
                                       .internalMapping = "list",#mappings like groups and facets
                                       .filename = "character",
                                       .isRescaled = "logical", #if units per columns are used, the data has to be rescaled according to scaling
                                       .isColumnUnitMode = "logical" #default is columnWideUnits TRUE
                                       ),
                         methods = list(
                           addData = function(expr){
                             subsetExpr <- substitute(expr)
                             tryCatch({
                               data <<- eval(expr)
                               .isRescaled <<- FALSE
                               .isColumnUnitMode <<- TRUE
                             },
                             error = function(e) stop("Your data is missing"))
                           },
                           addHeader = function(expr){
                             subsetExpr <- substitute(expr)
                             tryCatch({
                               header <<- eval(expr)
                             },
                             error = function(e) stop("Your data is missing"))
                           },
                           addLimits = function(expr){
                             subsetExpr <- substitute(expr)
                             tryCatch({
                               limits <<- data.table::as.data.table(eval(expr))
                               if(!is.null(limits$unit)){
                                 subLimits <- subset(limits, !is.na(unit))
                                 subLimits <- subLimits[!duplicated(subLimits$name),]
                                 units <<- subLimits$unit
                                 names(units) <<- subLimits$name
                               }
                               if(!is.null(limits$scale)){
                                 subLimits <- subset(limits, !is.na(scale))
                                 subLimits <- subLimits[!duplicated(subLimits$name),]
                                 scales <<- as.numeric(subLimits$scale)
                                 names(scales) <<- subLimits$name
                               }
                             }, error = function(e) {limits <<- data.table()})
                           },
                           filterData = function(expr){
                             subsetExpr <- substitute(expr)
                             tryCatch({
                                 data <<- data[eval(subsetExpr,data),] 
                             },
                             error = function(e) stop("Your data filtering expression does not work"))
                             
                           },
                           filterLimits = function(expr){
                             subsetExpr <- substitute(expr)
                             tryCatch({
                               if(nrow(limits) > 0){
                                 limits <<- limits[eval(subsetExpr,limits),] 
                               } else {
                                 warning("No limits to filter")
                               }
                             },
                             error = function(e) stop("Your limit filtering expression does not work"))
                           },
                           useUnitRowMode = function(){
                           	.isColumnUnitMode <<- FALSE
                           },
                           useUnitColumnMode = function(){
                           	.isColumnUnitMode <<- TRUE
                           },
                           setColumnsWithUnitsInRowMode = function(columns){
                           	.internalMapping$unitColumns <<- columns
                           },
                           setColumnsWithUnitsInRowMode = function(columns){
                           	.internalMapping$unitColumns <<- columns
                           },
                           setCellHighlighting = function(colName, threshold, color = NULL, cssClass = NULL){
                           	if(is.null(color)){
                           		color <- "yellow"
                           	}
                           	if(is.null(cssClass)){
                           		cssClass <- "tembo-data-highlight"
                           	}
                           	tmpDf <- data.frame(colName = colName, threshold = threshold, color = color, cssClass = cssClass)
                           	if(is.null(.internalMapping$cellHighlight)){
                           		.internalMapping$cellHighlight <<- tmpDf
                           	} else {
                           		.internalMapping$cellHighlight <<- rbind(.internalMapping$cellHighlight,tmpDf)
                           	}
                           	#Default color is set in css
                           }
                         )
)
