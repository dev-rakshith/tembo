temboTable$methods(
  exportData = function(){
    if(!.isRescaled & .isColumnUnitMode){
      tmplist <- recalculateUnitsInTable(data,limits,header, units, scales)
      data <<- tmplist[[1]]
      if(!is.null(tmplist[[2]])){
        header <<- tmplist[[2]]
      }
      .isRescaled <<- TRUE
    } else if(!.isRescaled & !.isColumnUnitMode){
      data <<- recalculateUnitsInTableRowMode(data,limits, units, scales, .internalMapping$unitColumns)
      .isRescaled <<- TRUE
    }
    return(data)
  }
)