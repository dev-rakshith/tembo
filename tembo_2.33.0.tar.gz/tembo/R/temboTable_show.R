temboTable$methods(
  show = function(){
    if(!.isRescaled & .isColumnUnitMode){
      tmplist <- recalculateUnitsInTable(data,limits,header, units, scales)
      data <<- tmplist[[1]]
      if(!is.null(tmplist[[2]])){
        header <<- tmplist[[2]]
      }
      .isRescaled <<- TRUE
    } else if(!.isRescaled & !.isColumnUnitMode){
    	data <<- recalculateUnitsInTableRowMode(data,limits, units, scales, .internalMapping$unitColumns)
    	.isRescaled <<- TRUE
    }
    #print(header)
    renderHeader()
    alignments <- NULL      
    # if currentResultsTypes exists, use it to align numbers right in the table
    if(exists("currentResultsTypes")){
      for(col in names(data)) {
        if(!is.null(currentResultsTypes[[col]])){
          if(currentResultsTypes[[col]] == 'number'){
            alignments <- c(alignments,"<td style=\"text-align:right;\">")
          } else {
            alignments <- c(alignments,"<td>")            
          }
        } else {
          alignments <- c(alignments,"<td>")
        }
      }
    }
    #TODO: add something like hilighting using a threshold to addTableFields
    #tmpData <- format(data, digits = 4) #apply would convert numeric to character before formatting the numbers
    #if(is.null(alignments)){
    #  tmpLines <- apply(tmpData, 1, function(x){paste0("\n", "<tr>\n", addTableFields(x), "\n</tr>")})
    #  table <<- c(table,tmpLines)
    #} else {
    #  tmpLines <- apply(tmpData, 1, function(x){paste0("\n", "<tr>\n", addTableFields(x, dataTypes=alignments), "\n</tr>")})
    #  table <<- c(table,tmpLines)
    #}
    #tmpData <- format(data, digits = 4) #apply would convert numeric to character before formatting the numbers
    tmpData <- split(data, 1:nrow(data))
    if(is.null(alignments)){
      tmpLines <- lapply(tmpData, function(x){paste0("\n", 
      																							 "<tr>\n",
      																							 addTableFields(x, highlighting = .internalMapping$cellHighlight),
      																							 "\n</tr>")})
      table <<- c(table,tmpLines)
    } else {
      tmpLines <- lapply(tmpData, function(x){paste0("\n",
      																							 "<tr>\n", 
      																							 addTableFields(x, 
      																							 							 dataTypes=alignments,
      																							 							 highlighting = .internalMapping$cellHighlight),
      																							 "\n</tr>")})
      table <<- c(table,tmpLines)
    }
    table[[length(table)+1]] <<- paste0("\n", "</table>", "\n", "</body>")
    return(paste(table, collapse = "\n"))
  
  },
  renderHeader = function(){
    currentTableHtml<-"<table class=\"table-condensed\" border=\"1px\" cellpadding=\"3\" cellspacing=\"0\">"
    currentTableHtml<-paste0(currentTableHtml, "\n", "<thead style='background-color:ghostwhite; text-align:left; border:2px solid black;'>")
    
    currentTableHtml<-paste0(currentTableHtml, "\n", "<tr>")
    for(col in names(data)) {
      if(col %in% names(header)) {
        currentTableHtml<-paste0(currentTableHtml, "\n", "<th style='border:2px solid black;'>", header[[col]], "</th>")
      } else {
        currentTableHtml<-paste0(currentTableHtml, "\n", "<th style='border:2px solid black;'>", col, "</th>")
      }
    }
    currentTableHtml<-paste0(currentTableHtml, "\n", "</tr>", "\n", "</thead>")
    currentTableHtml<-paste0(currentTableHtml, "\n", "<tbody style='border:2px solid black;'>")
    table <<- list()
    table[[1]] <<- currentTableHtml
  }
)


recalculateUnitsInTableRowMode <- function(data, limits, units, scales, unitColumns){
	if(is.null(limits) | is.null(data$Name)){
		return(data)
	}
	if(nrow(limits) == 0){ #The unit/scale is taken from data$Name column
		return(data)
	}
	#print(data$Name)
	if(any(data$Name %in% names(units))){
		data$Unit <- unname(units[data$Name])
		data$Unit[is.na(data$Unit)] <- ""
		if(data$Name %in% names(scales)){
			data$Scale <- unname(scales[data$Name])
			data$Scale[is.na(data$Scale)] <- 0
		} else {
			data$Scale <- sapply(split(data,1:nrow(data)),
			                     function(x){
			                       values <- x[,unitColumns]
			                       scales <- seq(-24,24,3)
			                       i <- max(findInterval(log10(abs(values)), scales), na.rm=TRUE)
			                       if(i == 0){
			                         return(0)
			                       }
			                       return(-scales[i])
			                     })
		}
		data$Unit <- paste0(sapply(data$Scale, function(x){gsub("0", "", format_si(scale=x)(0))}), data$Unit)
		for(colname in unitColumns){
			if(colname %in% colnames(data)){
				tmpColumn <- data[[colname]] * 10^(data$Scale)
				data[[colname]] <- NULL
				data[[colname]] <- tmpColumn
			}
		}
		data$Scale <- NULL
	}
	return(data)
}

recalculateUnitsInTable <- function(data, limits, header, units, scales){
	if(is.null(limits)){
		return(list(data,header))
	}
  if(nrow(limits) == 0){
    return(list(data,header))
  }
  
  for(colname in colnames(data)){
    if(colname %in% names(units)){
      currentFormatSi <- tembo::format_si(unit=units[[colname]])
      #print(currentLimit$unit[1])
      if(!colname %in% names(header)) {
        header[[colname]] <- paste0(colname, " [", units[[colname]],"]")
      } else {
        header[[colname]] <- paste0(header[[colname]], " [", units[[colname]],"]")
      }
    } 
    if(colname %in% names(scales)){
      tmpUnitString <- sub("0","",tembo::format_si(unit=units[[colname]], scale=scales[[colname]])(0))
      if(!colname %in% names(header)) {
        header[[colname]] <- paste0(colname, " [", tmpUnitString,"]")
      } else {
        #remove the unscaled and write the scaled unit
        header[[colname]] <- sub(" \\[.*\\]$", "", header[[colname]])
        header[[colname]] <- paste0(header[[colname]], " [", tmpUnitString,"]")
      }
      data[[colname]] <- 10^as.numeric(scales[[colname]])*data[[colname]]
    }
  }
  return(list(data,header))
}


addTableFields <- function(dataRow, dataTypes=NULL, displayedNumberOfDigits = 4, doSiFormatting = FALSE, highlighting = NULL){
  #library(dplyr)
	if(is.null(dataTypes) & !is.null(highlighting)){
		dataTypes = rep("<td>", length(dataRow))
	}
	cnames <- colnames(dataRow)
	if(!is.null(highlighting)){
		for(i in 1:nrow(highlighting)){
			if(!is.null(dataRow[[highlighting$colName[i]]])){
				cNo <- which(cnames == highlighting$colName[i])[1]
				if(abs(dataRow[[highlighting$colName[i]]]) > highlighting$threshold[i]){
					#print(cNo)
					replacement <- paste(" bgcolor=\"",
															 highlighting$color[i],
															 "\" class=\"",
															 highlighting$cssClass[i],"\">")
					dataTypes[cNo] <- gsub(">$", replacement, dataTypes[cNo])
				}
			}
		}
	}
	if(doSiFormatting){
    tmpRow <- c()
    currentFormatSi <-format_si(digits = displayedNumberOfDigits)
    for(colname in cnames){
      if(is.numeric(dataRow[[colname]]) & !is.factor(dataRow[[colname]])){
        tmpRow <- c(tmpRow, htmltools::htmlEscape(currentFormatSi(dataRow[[colname]])))
      } else {
        tmpRow <- c(tmpRow, htmltools::htmlEscape(as.character(dataRow[[colname]])))
      }
    }
    dataRow <- tmpRow
  }else {
    dataRow <- htmltools::htmlEscape(format(dataRow, digits = displayedNumberOfDigits))
  }
  if(is.null(dataTypes) | length(dataTypes) != length(dataRow)){
    currentTableHtml<- paste(paste0("<td>", dataRow, "</td>"),collapse = "\n")
  } else {
    currentTableHtml<-paste(paste0(dataTypes, dataRow, "</td>"),collapse = "\n")
  }
  return(currentTableHtml)
}
