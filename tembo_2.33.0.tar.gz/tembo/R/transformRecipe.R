#' Transform Recipe to R code
#'
#' Transforms a Tembo Recipe into R code
#'
#' \emph{Copyright (c) 2018 Infineon Technologies} 
#' @param recipeID ID of the Tembo Recipe
#' @param temboServer URL of the Tembo server
#' @param templateLocation Storage location, from where the template shall get loaded
#' @param user User name for Tembo server access
#' @param password Password for Tembo server access
#' @examples
#' tembo::transformRecipe("ced070a2-04f3-4158-be4e-9a8f745b94bc")
#' @author Kunze Matthias (IFAG ATV PTP MSF DM), \email{matthias.kunze2@@infineon.com}
#' @export
transformRecipe <- function(recipeID="ced070a2-04f3-4158-be4e-9a8f745b94bc", temboServer="https://tembo.intra.infineon.com", 
                            templateLocation="D:/Git/Tembo/r/templates", user="", password="", doProfiling=FALSE,
                            cacheMode = 'disabled') {
  
  #########################################################
  # Fetch recipe from server
  #########################################################
  response<-httr::GET(paste0(temboServer, '/api/recipe/GetRecipe?recipeId=', recipeID),
                      httr::authenticate(user, password, "ntlm"),
                      httr::config(ssl_verifypeer=0L))
  if (response$status_code>299) stop(paste0('Embedded recipe with id "', recipeID, '" could not be loaded\n\nHttp response:\n', httr::content(response, type = "text")))
  if (is.null(httr::content(response)$Id)) stop(paste0('Recipe with id "', recipeID, '" could not be loaded\n\nHttp response:\n', httr::content(response, type = "text")))
  recipeAPI<-httr::content(response)
  
  # Add recipe owner information at the beginning of the script
  stepCode<-paste0('TEMBO_INTERNAL_UserName<-"', recipeAPI$UpdatedBy,'"\n')
  
  #########################################################
  # Transform recipe into R code
  #########################################################
  recipe<-XML::xmlParse(recipeAPI$Recipe, encoding = "UTF-8")
  
  # Iterate over steps  
  for (template in XML::xpathSApply(recipe, "/Recipe/ApplyTemplate[not(@enabled='false')]")) {
    attributes<-XML::xmlAttrs(template)
    templateName<-attributes[["href"]]
    
    if (doProfiling) {
      stepCode<-paste0(stepCode, '\n')
      stepCode<-paste0(stepCode, '\n# Profiling\n')
      stepCode<-paste0(stepCode, 'TEMBO_INTERNAL$stats$step[[length(TEMBO_INTERNAL$stats$step)+1]]<-list()\n')
      stepCode<-paste0(stepCode, 'TEMBO_INTERNAL$stats$step[[length(TEMBO_INTERNAL$stats$step)]]$template<-"', templateName, '"\n')
      stepCode<-paste0(stepCode, 'TEMBO_INTERNAL$stats$step[[length(TEMBO_INTERNAL$stats$step)]]$start_time<-Sys.time()\n')
      stepCode<-paste0(stepCode, '\n')
    }
      
    stepCode<-paste0(stepCode,
                     '###################################################################################\n',
                     '# Step ', templateName, '\n',
                     '###################################################################################\n',
                     '\n',
                     tembo::applyRTemplate(sub("\\.xsl", "", templateName), paramNodes=XML::xpathSApply(template, "param"), 
                                           templateLocation = templateLocation, cacheMode=cacheMode),
                     '\n')
    
    if (doProfiling) {
      stepCode<-paste0(stepCode, '\n')
      stepCode<-paste0(stepCode, '\n# Profiling\n')
      stepCode<-paste0(stepCode, 'TEMBO_INTERNAL$stats$step[[length(TEMBO_INTERNAL$stats$step)]]$stop_time<-Sys.time()\n')
      stepCode<-paste0(stepCode, 'TEMBO_INTERNAL$stats$step[[length(TEMBO_INTERNAL$stats$step)]]$duration<-as.numeric(TEMBO_INTERNAL$stats$step[[length(TEMBO_INTERNAL$stats$step)]]$stop_time-TEMBO_INTERNAL$stats$step[[length(TEMBO_INTERNAL$stats$step)]]$start_time, units="secs")\n')
      stepCode<-paste0(stepCode, '\n')
    }
  }
  result <- list(stepCode=stepCode, reportId=recipeAPI$ReportId, queueName=recipeAPI$QueueName)
  return(result)
}