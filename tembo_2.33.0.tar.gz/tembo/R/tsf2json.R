############################################################################################
#' tsf2json
#'
#' \emph{Copyright (c) 2020 Infineon Technologies}
#' @family tembo uploader
#' @author Thomas Michenthaler (IFAT DC ATV PTP MSF PDM VER), \email{thomas.michenthaler@infineon.com}
#' @export tsf2json
#' @param tsfFile data that should be uploaded
#' @param metaDataJson json object containing meta data information for upload process
#' @param logId numeric containing the log ID created by the uploader
#' @param dataFolder string containing the path to the folder of the data to be uploaded
#' @param stagingArea string containing the path to the staging area
#' @param temboBaseUrl string containing the Tembo base URL
tsf2json<-function(tsfFile, metaDataJson, logId, dataFolder, stagingArea, temboBaseUrl) {
  tryCatch({
    
    # get TSF data, replace special-characters in parameter names and remove remaining tsf header data starting with '%'
    tsfData<-tembo::eff.read(new("eff"), tsfFile)
    tsfData@colnames<-gsub("[^a-zA-Z0-9_]", "_", tsfData@colnames)
    names(tsfData@data)<-gsub("[^a-zA-Z0-9_]", "_", tsfData@colnames)
    if (is.character(tsfData@data[,1])) {
      tsfData@data<-tsfData@data[!startsWith(tsfData@data[,1], "%"),]
    }
    
    # do scaling
    unitlup<-c("f", "p", "n", "u", "m", "k", "M", "G", "T", "P")
    unitscl<-c(1e-15, 1e-12, 1e-9, 1e-6, 1e-3, 1e3, 1e6, 1e9, 1e12, 1e15)
    scale<-unitscl[match(substr(tsfData@unit, 1, 1), unitlup)]
    unitCols<-!is.na(scale)
    if (!is.null(nrow(tsfData@data[,unitCols]))) {
      tsfData@data[,unitCols] <- t(apply(tsfData@data[,unitCols], 1, function(x) as.numeric(x) * scale[unitCols]))
    } else {
      tsfData@data[,unitCols] <- tsfData@data[,unitCols] * scale[unitCols]
    }
    tsfData@lsl[unitCols]<-as.numeric(tsfData@lsl[unitCols]) * scale[unitCols]
    tsfData@usl[unitCols]<-as.numeric(tsfData@usl[unitCols]) * scale[unitCols]

    # prepare test-insertion strings
    if ("READOUT" %in% names(tsfData@data)) {
      tsfData@data$READOUT<-paste0(tsfData@data$READOUT, ifelse(grepl("_[R]*VGT[[:digit:]]*\\.", tsfFile), "_VGT", ""))
      tsfData@lsl[grep("READOUT", colnames(tsfData@data))]<-tsfData@data$READOUT[1]
      tsfData@usl[grep("READOUT", colnames(tsfData@data))]<-tsfData@data$READOUT[1]
    }
    dat<-tsfData@data

    # limits management
    limitpat<-(is.na(tsfData@lsl)) | (tsfData@lsl=="NA")
    lsl<-head(zoo::na.locf(tsfData@data,na.rm=F), 1)
    lsl[!limitpat]<-tsfData@lsl[!limitpat]
    usl<-head(zoo::na.locf(tsfData@data,na.rm=F), 1)
    usl[!limitpat]<-tsfData@usl[!limitpat]
    scale[is.na(scale)]<-1
    scale<-(-log(scale)/log(10))
    unit<-tsfData@unit
    unit[scale!=0]<-substr(unit[scale!=0], 2, 999)

    # cleanup rows
    if ("READOUT" %in% names(dat)) {
      rmRows<-(is.na(dat$TEMP) | is.na(dat$READOUT))
    } else {
      rmRows<-is.na(dat$TEMP)
    }
    dat<-dat[!rmRows,]

    # load mandatory metaData fields
    response<-httr::GET(paste0(temboBaseUrl, '/api/Application/MandatoryMetadataFields'),
                        httr::content_type("application/json"), httr::authenticate("", "", "ntlm"),
                        httr::config(ssl_verifypeer=0L))
    if (response$status_code!=200) stop(paste0('Could not fetch mandatory metaData fields.\n\nHttp response:\n', httr::content(response, type = "text")))
    mandatoryMetadataFields<-unique(sapply(httr::content(response), function(x) x$FieldName))

    # replace metaData fieldnames with matching metaDataMapping fieldnames
    mandatoryMetadataFields<-replace(
      mandatoryMetadataFields,
      which(mandatoryMetadataFields %in% names(metaDataJson$metaDataMapping)),
      unlist(metaDataJson$metaDataMapping[mandatoryMetadataFields[which(mandatoryMetadataFields %in% names(metaDataJson$metaDataMapping))]],
             use.names=FALSE))
#browser()
    # remove rows with more than the defined number of NAs in the mandatory metaData columns, considering metaDataMapping information
    blankRowMinCols<-ifelse(is.null(metaDataJson$header$blank_row_minimum_columns), 3, metaDataJson$header$blank_row_minimum_columns)
    mandatoryMetadataColumns<-names(dat)[which(names(dat) %in% mandatoryMetadataFields)]
    if (length(mandatoryMetadataColumns) >= blankRowMinCols)
    {
      dat<-dat[which(rowSums(is.na(dat[,mandatoryMetadataColumns])) <= blankRowMinCols),]
    }

    # generate data json
    dataObjects<-list()
    for (row in 1:nrow(dat)) {
      dataObject<-list()

      # metadata
      dataObject$metaData$data_object_type<-"value"
      
      for (mappingName in names(metaDataJson$metaDataMapping)) {
        
        # do not consider metaData fields that are already defined in commonMetaData section
        if (mappingName %in% names(metaDataJson$commonMetaData)) next()
        
        # add mapping values
        if (mappingName == "tester_site") {
          dataObject$metaData$tester_site<-ifelse(is.null(dat[[metaDataJson$metaDataMapping[[mappingName]]]][row]), "999", ifelse(is.na(dat[[metaDataJson$metaDataMapping[[mappingName]]]][row]), "999", toString(dat[[metaDataJson$metaDataMapping[[mappingName]]]][row])))
        } else if (mappingName == "basic_type") {
          dataObject$metaData$basic_type<-substr(dat[[metaDataJson$metaDataMapping[[mappingName]]]][row], 1, stringr::str_length(dat[[metaDataJson$metaDataMapping[[mappingName]]]][row]) - 3)
        } else if (mappingName == "test_insertion") {
          dataObject$metaData$test_insertion<-ifelse(metaDataJson$metaDataMapping[[mappingName]] %in% names(dat), dat[[metaDataJson$metaDataMapping[[mappingName]]]][row], "BX")
        } else if (mappingName == "test_type") {
          dataObject$metaData$test_type<-ifelse(metaDataJson$metaDataMapping$test_insertion %in% names(dat), unlist(strsplit(dat[[metaDataJson$metaDataMapping[[mappingName]]]][row], "_"))[1], "BX")
        } else {
          dataObject$metaData[[mappingName]]<-dat[[metaDataJson$metaDataMapping[[mappingName]]]][row]
        }
      }
      
      # payload
      dataObject$payload<-lapply(dat[row, !is.na(dat[row,])], toString)

      dataObjects[[length(dataObjects) + 1]]<-dataObject
    }
    
    # generate limits json
    for (i in 1:length(limitpat)) {
      dataObject<-list()

      # metadata
      dataObject$metaData$data_object_type<-"limit"
      dataObject$metaData$test_program_build<-"0"
      tnr<-unlist(strsplit(colnames(lsl)[i], "___"))
      dataObject$metaData$test_number<-toString(ifelse(length(tnr) > 1, tnr[2], tnr[1]))
      
      for (mappingName in names(metaDataJson$metaDataMapping)) {
        
        # do not consider metaData fields that are already defined in commonMetaData section
        if (mappingName %in% names(metaDataJson$commonMetaData)) next()
        
        # add mapping values
        if (mappingName == "basic_type") {
          dataObject$metaData$basic_type<-substr(lsl[[metaDataJson$metaDataMapping[[mappingName]]]], 1, stringr::str_length(lsl[[metaDataJson$metaDataMapping[[mappingName]]]]) - 3)
        } else {
          dataObject$metaData[[mappingName]]<-lsl[[metaDataJson$metaDataMapping[[mappingName]]]]
        }
      }
      
      # payload
      dataObject$payload$parameter_name<-colnames(lsl)[i]
      dataObject$payload$lower_limit<-toString(lsl[i])
      dataObject$payload$upper_limit<-toString(usl[i])
      dataObject$payload$unit<-ifelse(is.na(unit[i]), "", unit[i])
      dataObject$payload$scale<-toString(scale[i])

      dataObjects[[length(dataObjects) + 1]]<-dataObject
    }
    
    # prepare json to upload
    jsonResult<-list()
    jsonResult$header<-list(version=metaDataJson$header$version)
    jsonResult$header[["usePreprocessor"]]<-"false"
    jsonResult$header[["LogID"]]<-logId
    jsonResult$commonMetaData<-metaDataJson$commonMetaData
    jsonResult$dataObjects<-dataObjects
    
    # create json in job folder
    projectName<-basename(dirname(dirname(dataFolder)))
    jobFolder<-paste0(stagingArea, "/", projectName, "/job")
    jsonlite::write_json(jsonResult, paste0(jobFolder, "/", tools::file_path_sans_ext(basename(tsfFile)), ".json"), auto_unbox=TRUE, pretty=TRUE)
    
    # move data to processed folder
    file.rename(dataFolder, paste0(stagingArea, "/", projectName, "/processed/", basename(dataFolder)))
    
    # update status (PASS)
    if(!is.null(logId)) {
      body<-list()
      body[["LogID"]]<-logId
      body[["PreProcessorStatus"]]<-"successful"
      body[["Success"]]<-TRUE
      response<-httr::PUT(paste0(temboBaseUrl, '/api/Upload/UpdatePreProcessingStatus'),
                          body=jsonlite::toJSON(body, auto_unbox=TRUE),
                          httr::content_type("application/json"),
                          httr::authenticate("", "", "ntlm"),
                          httr::config(ssl_verifypeer=0L))
      if (response$status_code>299) {
        stop(httr::content(response, type="text"))
      }
    } else {
      print("SUCCESS")
    }
  }, error=function(e) {
    # update status (FAIL)
    if(!is.null(logId)) {
      body<-list()
      body[["LogID"]]<-logId
      body[["PreProcessorStatus"]]<-e$message
      body[["Success"]]<-FALSE
      response<-httr::PUT(paste0(temboBaseUrl, '/api/Upload/UpdatePreProcessingStatus'),
                          body=jsonlite::toJSON(body, auto_unbox = TRUE),
                          httr::content_type("application/json"),
                          httr::authenticate("", "", "ntlm"),
                          httr::config(ssl_verifypeer=0L))
      if (response$status_code>299) {
        stop('Preprocessor status could not be updated:\n', httr::content(response, type = "text"))
      }
    } else {
      stop(e)
    }
  })
}
