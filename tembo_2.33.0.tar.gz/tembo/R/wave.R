# Waveform functions

#' wave_getValue
#' 
#' wave_getValue() gets the Value at specific time and uses linear interpolation if the time is not in the data set.
#' Otherwise, when the time is not within the data set time, the it throws an error
#' 
#' \emph{Copyright (c) 2018 Infineon Technologies} 
#' @param data Waveform data as a date frame with t as numeric time variable and y as value variable.
#' @param time numeric time point for which the value should be returned
#' @examples
#' data <- data.frame(t = (1:1000)*1e-6, y = sin(1:1000))
#' tembo::wave_getValue(data, 100.5e-6)
#' 
#' # Throws en error:
#' tembo::wave_getValue(data, 0)
#' @author Helena Schmidt, \email{schmidt.external9@@infineon.com}
#' @export
wave_getValue <- function(data, time){
	timeIndex <- which(data$t == time)[1]
	if(is.na(timeIndex)){
		if(is.unsorted(data$t)){
			# if time is unsorted, sort data by time
			data <- data[order(data$t), ]
		}
		if( time > max(data$t) | time < min(data$t)){
			stop("time not covered by the data")
		}
		#print(time)
		timeIndex <- which( data$t > time )[1]
		# perform a linear interpolation:
		a <- with(data, (y[timeIndex]-y[timeIndex-1])/(t[timeIndex]-t[timeIndex-1]))
		#print(a)
		return( with(data, a*(time-t[timeIndex-1]) + y[timeIndex-1] ))
	} else {
		return( data$y[timeIndex])
	}
}


# Waveform functions

#' wave_getAverage
#' 
#' wave_getAverage() calculatets the arithmetic mean of a given signal
#' 
#' startTime end stopTime can be set to calculate the mean between the two times. If stopTime < startTime, the function
#' throws an error.
#' If there is no data point explicitly in the data between startTime and stopTime, the mean is calculated as the
#' interpolated value between those two times.
#' \emph{Copyright (c) 2018 Infineon Technologies} 
#' @param data Waveform data as a date frame with t as numeric time variable and y as value variable.
#' @param startTime numeric time point from wheen the average should be calculated, NULL means from beginning
#' @param stopTime numeric time point to when the average should be calculated, NULL means to end
#' @examples
#' data <- data.frame(t = (1:1000)*1e-6, y = sin(1:1000))
#' tembo::wave_getAverage(data, startTime=100.5e-6)
#' tembo::wave_getAverage(data, startTime=100.5e-6, stopTime=200e-6)
#' 
#' # Throws en error:
#' tembo::wave_getAverage(data, startTime=1, stopTime=0)
#' @author Helena Schmidt, \email{schmidt.external9@@infineon.com}
#' @export
wave_getAverage <- function(data, startTime = NULL, stopTime = NULL) {
	if(is.null(startTime)){
		startTime <- min(data$t)
	}
	if(is.null(stopTime)){
		stopTime <- max(data$t)
	}
	if(stopTime < startTime){
		stop("stopTime is smaller than startTime")
	}
	subData <- subset(data, t >= startTime & t <= stopTime)
	if(nrow(subData) == 0){
		return(wave_getValue(data, mean(c(startTime,stopTime))))
	}
	return(mean(subData$y))
}


#' wave_getTriggerTime
#' 
#' wave_getTriggerTime() calculates the time a trigger occured in the data.
#' 
#' startTime end stopTime can be set to calculate the mean between the two times. If stopTime < startTime, the function
#' throws an error.
#' If there is no data point explicitly in the data between startTime and stopTime, the mean is calculated as the
#' interpolated value between those two times.
#' threshold can be set to a numeric value, or a string wich contains a numeric value ending with "\%" can be used, in
#' case of e.g. "90\%" the trigger is calculated to 90\% of the overall span of the
#' data (before applying startTime and/or stopTime).
#' \emph{Copyright (c) 2018 Infineon Technologies} 
#' @param data Waveform data as a date frame with t as numeric time variable and y as value variable.
#' @param threshold Threshold value, if crossed, the trigger times for crossing is calculated
#' @param type Type of the trigger, can be 'rising'(default), 'falling' oder 'either'
#' @param blankTime The time after a threshold crossing no further crossing will be accepted for noise cancellation
#' @param startTime numeric time point from wheen the average should be calculated, NULL means from beginning
#' @param stopTime numeric time point to when the average should be calculated, NULL means to end
#' @examples
#' data <- data.frame(t=(1:1e4)/1000)
#' data$y <- sin(data$t)
#' tembo::wave_getTriggerTime(data)
#' tembo::wave_getTriggerTime(data, type="falling")
#' tembo::wave_getTriggerTime(data, threshold = 0.5,  type="falling")
#' tembo::wave_getTriggerTime(data, threshold = "50%",  type="falling")
#' 
#' # Using blankTime to filter noise:
#' data <- data.frame(t=(1:1e4)/1000)
#' set.seed(500)
#' data$y <- sin(data$t) + runif(1e4) * 0.01
#' tembo::wave_getTriggerTime(data, threshold = 0.1, blankTime = 0.01)
#' tembo::wave_getTriggerTime(data, threshold = 0, type = "falling", blankTime = 0.01)
#' 
#' # Throws en error:
#' tembo::wave_getTriggerTime(data, startTime=1, stopTime=0)
#' tembo::wave_getTriggerTime(data, type="uidtrne")
#' @author Helena Schmidt, \email{schmidt.external9@@infineon.com}
#' @export
wave_getTriggerTime <- function(data, threshold="90%", type="rising", blankTime=2e-10, startTime=NULL, stopTime=NULL) {
	#if threshold is not numeric(default), it calculates the threshold from the data
	#to a percentage of the span of the whole data
	if(!is.numeric(threshold)){ 
		threshold <- (max(data$y)-min(data$y))*as.numeric(gsub("%","",threshold))/100 + min(data$y)
	}
	#print(threshold)
	if(is.unsorted(data$t)){
		# if time is unsorted, sort data by time
		data <- data[order(data$t), ]
	}
	if(is.null(startTime)){
		startTime <- min(data$t)
	}
	if(is.null(stopTime)){
		stopTime <- max(data$t)
	}
	if(stopTime < startTime){
		stop("stopTime is smaller than startTime")
	}
	if(!(type %in% c("rising", "falling", "either"))){
		stop("Wrong type, must be rising or falling")
	}
	subData <- subset(data, t >= startTime & t <= stopTime)
	triggerIndicesRising <- which(diff(subData$y >= threshold)==1) 
		### Beware that triggerIndices have an off-by-one error because of diff(), it points to the datapoint before the trigger was hit
	triggerIndicesFalling <- which(diff(subData$y <= threshold)==1)

	triggerIndices <- c(triggerIndicesRising, triggerIndicesFalling)
	triggerTimes <- (subData$t[triggerIndices+1]-subData$t[triggerIndices])/
		(subData$y[triggerIndices+1]-subData$y[triggerIndices])*
		(threshold-subData$y[triggerIndices])+
		subData$t[triggerIndices]
	triggerData <- data.frame( t = triggerTimes,
														 isRising = c(rep(TRUE, length(triggerIndicesRising)),
														 						 rep(FALSE, length(triggerIndicesFalling)))
	)
	triggerData <- triggerData[order(triggerData$t),]
	if(any(diff(triggerData$t) < blankTime)) {
		counter <- 1
		while( counter < nrow(triggerData)) {
			triggerData <- subset(triggerData,  !(triggerData$t[counter]<t &
																		 t <= (triggerData$t[counter]+blankTime)))
			counter <- counter + 1
		}
	}
	if(type == "rising"){
		triggerData <- subset(triggerData, isRising)
	} else if(type == "falling"){
		triggerData <- subset(triggerData, !isRising)
	}
	return(triggerData$t)
}






#' wave_getConfidenceInterval
#' 
#' wave_getConfidenceInterval() calculates the confidence interval around a reference waveform.
#' 
#' \emph{Copyright (c) 2018 Infineon Technologies} 
#' @param data Waveform data as a date frame with t as numeric time variable and y as value variable.
#' @param ttol Confidence interval tolerance in t direction
#' @param ytol Confidence interval tolerance in y(value) direction
#' @examples
#' waveData <- data.frame(t = seq(0,2*pi,0.01))
#' waveData$y <- sin(waveData$t)
#' confedData <- tembo::wave_getConfidenceInterval(waveData, 0.01, 0.1)
#' ggplot2::ggplot(waveData) + ggplot2::geom_line(ggplot2::aes(t,y)) +
#'   ggplot2::geom_line(data=confedData, ggplot2::aes(t,ymax), colour="violet") +
#'   ggplot2::geom_line(data=confedData, ggplot2::aes(t,ymin), colour="violet")
#'   
#' # with larger time tolerance:
#' confedData <- tembo::wave_getConfidenceInterval(waveData, 1, 0.1)
#' ggplot2::ggplot(waveData) + ggplot2::geom_line(ggplot2::aes(t,y)) +
#'   ggplot2::geom_line(data=confedData, ggplot2::aes(t,ymax), colour="violet") +
#'   ggplot2::geom_line(data=confedData, ggplot2::aes(t,ymin), colour="violet")
#' 
#' # Testing waveforms against the confidence Interval:
#' newWave <- data.frame(t = seq(0,2*pi,0.01))
#' newWave$y <- sin(newWave$t + runif(nrow(newWave))*0.1) + runif(nrow(newWave)) * 0.1
#' min(newWave$y < confedData$ymax) # if 0, at least one value is FALSE
#' min(newWave$y > confedData$ymin) # if 0, at least one value is FALSE
#' ggplot2::ggplot(newWave) + ggplot2::geom_line(ggplot2::aes(t,y)) +
#' 	ggplot2::geom_line(data=confedData, ggplot2::aes(t,ymax), colour="violet") +
#' 	ggplot2::geom_line(data=confedData, ggplot2::aes(t,ymin), colour="violet")
#' 
#' @author Helena Schmidt, \email{schmidt.external9@@infineon.com}
#' @export
wave_getConfidenceInterval <- function(data, ttol = 0.01, ytol = 0.1) {
	if(is.unsorted(data$t)){
		data <- data[order(data$t), ]
	}
	dfData <- wave_getConfidenceIntervalCore(data$t, data$y, ttol,ytol)
	dfData$t <- data$t
	return(dfData)
}

# #wave_getConfidenceInterval in pure R (this is pretty slow, but the fastest pure R code)
# wave_getConfidenceInterval <- function(wave, ttol = 0.01, ytol = 0.1 ) {
# 	if(is.unsorted(wave$t)){
# 		wave <- wave[order(wave$t), ]
# 	}
# 	fnValueCalculation <- function(t){
# 		#subset data:
# 		tmpArray <- wave$y[wave$t <= (t+ttol) & wave$t >= (t-ttol)]
# 		#interpolate data:
# 		if( t-ttol >= min(wave$t)) {
# 			tmpArray <- c(tmpArray, wave_getValue(wave, t-ttol))
# 		}
# 		if( t+ttol<= max(wave$t)){
# 			tmpArray <- c(tmpArray, wave_getValue(wave, t+ttol))
# 		}
# 		return( matrix( c(min(tmpArray) - ytol, max(tmpArray) + ytol), nrow = 1, ncol = 2))
# 	}
# 	confidenceWave <- sapply(wave$t, fnValueCalculation)
# 	confidenceWave <- data.frame(ymax=confidenceWave[1,], ymin=confidenceWave[2,],t=waveData$t)
# 	return(confidenceWave)
# }
