#include <Rcpp.h>

using namespace Rcpp;

//' @export
// [[Rcpp::export]]
SEXP wave_getConfidenceIntervalCore(SEXP t, SEXP y, SEXP ttol, SEXP ytol) {
	Rcpp::NumericVector xt(t);
	Rcpp::NumericVector xy(y);
	Rcpp::NumericVector xttol(ttol);
	Rcpp::NumericVector xytol(ytol);
	double dttol = xttol[0];
	double dytol = xytol[0];
	int n = xt.size();
	Rcpp::NumericVector xymin(n);
	Rcpp::NumericVector xymax(n);
	int iStart = 0;
	int iStop = 0;
	for( int i=0; i < n; i++){
		// left part
		while( iStop < n) {
			if( xt[iStop] <= xt[i]+dttol){
				iStop++;
			} else {
				break;
			}
		}
		// right part
		while( iStart < n) {
			if( xt[iStart] >= xt[i]-dttol){
				break;
			} else {
				iStart++;
			}
		}
		
		double min = xy[iStart];
		double max = xy[iStart];
		
		// Interpolate start point:
		int k;
		if( (xt[i]-dttol) > xt[0]) {
			double tmp = xt[i]-dttol;
			//int k;
			for( k = i; k >= 0; k--){
				if(xt[k] < tmp ){
					break;
				}
			}
			double a = (xy[k+1]-xy[k])/(xt[k+1]-xt[k]);
			tmp = a*(tmp-xt[k]) + xy[k];
			if(tmp < min) min = tmp;
			if(tmp > max) max = tmp;
		}
		// Interpolate end point:
		if( (xt[i]+dttol) < xt[n-1]){
			double tmp = xt[i]+dttol;
			for( k = i; k < n; k++){
				if(xt[k] > tmp ){
					break;
				}
			}
			double a = (xy[k]-xy[k-1])/(xt[k]-xt[k-1]);
			tmp = a*(tmp-xt[k-1]) + xy[k-1];
			if(tmp < min) min = tmp;
			if(tmp > max) max = tmp;
		}
		
		// extract minima and maxima
		for( int j = iStart; j < iStop; j++){
			if( xy[j] < min){
				min = xy[j];
			} else
				if( xy[j] > max){
					max = xy[j];
				}
		}
		xymin[i] = min - dytol;
		xymax[i] = max + dytol;
	}
	return Rcpp::DataFrame::create( Named("ymin") = xymin,
																	Named("ymax") = xymax);
}
