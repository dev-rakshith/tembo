library(testthat)
library(tembo)

test_check("tembo")
