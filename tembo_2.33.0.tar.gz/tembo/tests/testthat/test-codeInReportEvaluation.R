context("Programmatic Recipe generation")

test_that("Testing recipe generation", {

  ################################################################
  # Create currentQuery object
  # Will be used in user space
  ################################################################
  recipeStepSource<-'<ApplyTemplate href="rcodes/query.xsl" enabled="true">
      <param>
        <name>d</name>
        <value />
      </param>
      <param>
        <name>mapping</name>
        <value />
      </param>
      <param>
        <name>index</name>
        <value>integrationtest</value>
      </param>
      <param>
        <name>field</name>
        <value>payload.D1_LIN1 metaData.cond_tambient metaData.cond_load</value>
      </param>
      <param>
        <name>filter</name>
        <value>
          <filters>
            <filter>
              <field>metaData.dut_id</field>
              <name>DUT Id</name>
              <filterType>MultiSelect</filterType>
              <filterOperator />
              <filterUnit />
              <filterValues>
                <filterValue>DUT1</filterValue>
              </filterValues>
            </filter>
            <filter>
              <field>metaData.user_email_address</field>
              <name>Email Address</name>
              <filterType>MultiSelect</filterType>
              <filterOperator />
              <filterUnit />
              <filterValues>
                <filterValue>manjunatha.rao@infineon.com</filterValue>
              </filterValues>
            </filter>
            <filter>
              <field>metaData.test_name</field>
              <name>Test Name</name>
              <filterType>MultiSelect</filterType>
              <filterOperator />
              <filterUnit />
              <filterValues>
                <filterValue>D1_LIN1</filterValue>
              </filterValues>
            </filter>
          </filters>
        </value>
      </param>
      <param>
        <name>query</name>
        <value>{      "query":{      "bool": {      "must" : [            ]      }      }      }</value>
      </param>
    </ApplyTemplate>'
  
  currentQuery<-tembo::temboData(index="integrationtest", user='x', 
                        password='***', baseUrl='https://esdev10api.vih.infineon.com:9200/',
                        recipeStepSource=recipeStepSource)
  currentQuery$addTermsQuery("metaData.user_email_address", c("manjunatha.rao@infineon.com"))
  currentQuery$addTermsQuery("metaData.test_name", c("D1_LIN1"))
  currentQuery$addTermsQuery("metaData.dut_id", c("DUT1"))

  ################################################################
  # Create currentPage object
  # Will be used in user space
  ################################################################
  currentPage<-tembo::temboReportPage()
  
  currentPage$doc<-XML::xmlParse('<html><h1>Parameter $paramname$</h1>

<h2>Metadata</h2>

<h2>Plots</h2>

<pre class="template-code-block" style="padding: 10px; background-color: LightGray">
conditions=c("cond_tambient", "cond_VS")

# Loop over available conditions
for (condition in conditions) {

	currentPage$addHTML("&lt;h3>", condition, "&lt;/h3>")
	
	# Create plot recipe for this condition
	recipe&lt;-tembo::temboRecipe()
	recipe$addStep(currentQuery, params=c(field=paste(c(paste0("payload.", currentPage$paramname), paste0("metaData.", conditions), \'metaData.dut_id\'), collapse=" ")))	
	recipe$addStep("xyplot", params=c(x=condition, y=currentPage$paramname))
	
	currentPage$addHTML("&lt;h4>Hallo&lt;/h4>")
}
</pre>
</html>', encoding = "ISO-8859-1")
  
  currentPage$paramname<-"D1_LIN1"
  
  ################################################################
  # Evaluate embedded R code blocks in current context and
  # replace with results
  # Here also recipes might get created
  ################################################################
  currentPage$evalCodeBlocks(environment())
  
  # Test
  expect_equal(XML::toString.XMLNode(currentPage$doc), "<?xml version=\"1.0\" encoding=\"ISO-8859-1\"?>\n<html>\n  <h1>Parameter $paramname$</h1>\n  <h2>Metadata</h2>\n  <h2>Plots</h2>\n  <div class=\"resolved-code-block\">\n    <h3>cond_tambient</h3>\n    <h4>Hallo</h4>\n    <h3>cond_VS</h3>\n    <h4>Hallo</h4>\n  </div>\n</html>\n ")
  
})