context("Get Average of Waveform")

test_that("Testing averaging", {
  data <- data.frame(t = (1:1000)*1e-6, y = sin(1:1000))
  expect_equal(wave_getAverage(data, startTime=100.5e-6), 0.001045712)
  expect_equal(wave_getAverage(data, stopTime=500e-6), 0.002980591)
  expect_equal(wave_getAverage(data), 0.0008139696)
  #return value if average goes only over one value
  expect_equal(wave_getAverage(data, startTime=500e-6, stopTime=500e-6), data$y[500])
  #average value if there is no value in the data between the timepoints
  expect_equal(wave_getAverage(data, startTime=500.1e-6, stopTime=500.9e-6), -0.7321218, tolerance = 1e-6)
})

test_that("Test error handling", {
	data <- data.frame(t = (1:1000)*1e-6, y = sin(1:1000))
	# expect error if out stopTime ist smaller than startTime:
	expect_error(wave_getAverage(data, startTime=1, stopTime=0))
	# expect error if out of range
	expect_error(wave_getAverage(data, startTime=-2, stopTime=-1))
})