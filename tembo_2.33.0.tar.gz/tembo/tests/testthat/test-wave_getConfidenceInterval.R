context("Confidence Intervall calculation")

test_that("Testing confidence intervall calculation", {
	matlabData <- read.csv("./data/wave_confidenceIntervals001.csv", header = F)
	colnames(matlabData) <- c("xmin", "xmax", "ymin", "ymax")
	waveData <- data.frame(t = seq(0,2*pi,0.001))
	waveData$y <- sin(waveData$t)
	confedData <- wave_getConfidenceInterval(waveData, 0.01, 0.1)
															 
	expect_equal(confedData$ymin, matlabData$ymin)
	expect_equal(confedData$ymax, matlabData$ymax)

	# in this case, most of the datapoints are interpolated
	matlabData <- read.csv("./data/wave_confidenceIntervals01.csv", header = F)
	colnames(matlabData) <- c("xmin", "xmax", "ymin", "ymax")
	waveData <- data.frame(t = seq(0,2*pi,0.01))
	waveData$y <- sin(waveData$t)
	confedData <- wave_getConfidenceInterval(waveData, 0.01, 0.1)
	
	expect_equal(confedData$ymin, matlabData$ymin)
	expect_equal(confedData$ymax, matlabData$ymax)
	
	# more saturation
	matlabData <- read.csv("./data/wave_confidenceIntervals01b.csv", header = F)
	colnames(matlabData) <- c("xmin", "xmax", "ymin", "ymax")
	waveData <- data.frame(t = seq(0,2*pi,0.01))
	waveData$y <- sin(waveData$t)
	confedData <- wave_getConfidenceInterval(waveData, 1, 0.1)
	
	expect_equal(confedData$ymin, matlabData$ymin)
	expect_equal(confedData$ymax, matlabData$ymax)
	
	# test unordered data:
	waveData$t <- sample(waveData$t)
	waveData$y <- sin(waveData$t)
	confedData <- wave_getConfidenceInterval(waveData, 1, 0.1)
	expect_equal(confedData$ymin, matlabData$ymin)
	expect_equal(confedData$ymax, matlabData$ymax)
})
