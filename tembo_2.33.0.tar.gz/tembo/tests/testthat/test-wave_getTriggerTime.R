context("Get Trigger Time of Waveform")

test_that("Testing trigger time", {
	data <- data.frame(t=(1:1e4)/1000)
	data$y <- sin(data$t)
	expect_equal(tembo::wave_getTriggerTime(data),
							 c(0.9272954,7.2104807), tolerance = 1e-6)
	#test explicit rising
	expect_equal(tembo::wave_getTriggerTime(data, type="rising"),
							 c(0.9272954,7.2104807), tolerance = 1e-6)
	expect_equal(tembo::wave_getTriggerTime(data, type="falling"),
							 c(2.214297,8.497483), tolerance = 1e-6)
	expect_equal(tembo::wave_getTriggerTime(data, type="either"),
							 c(0.9272954,2.214297,7.2104807,8.497483), tolerance = 1e-6)
	data$y <- data$y + 1 #changing values by a constant should not change the trigger time
	expect_equal(tembo::wave_getTriggerTime(data, type="rising"),
							 c(0.9272954,7.2104807), tolerance = 1e-6)
	data$y <- data$y * 5 - 10 #changing values by a constant should not change the trigger time
	expect_equal(tembo::wave_getTriggerTime(data, type="rising"),
							 c(0.9272954,7.2104807), tolerance = 1e-6)
	#test trigger time for explicit numeric threshold
	data$y <- sin(data$t)
	#print(tembo::wave_getTriggerTime(data, threshold = 0.5,  type="falling"))
	expect_equal(tembo::wave_getTriggerTime(data, threshold = 0.5,  type="falling"),
							 c(2.617994, 8.901179), tolerance = 1e-6)
	#test trigger time for explicit numeric threshold
	expect_equal(tembo::wave_getTriggerTime(data, threshold = "50%",  type="falling"),
							 c(3.141593, 9.424778), tolerance = 1e-6)
	#test trigger time when no trigger is in the time window
	expect_equal(length(tembo::wave_getTriggerTime(data, startTime = 2, stopTime = 5)),0)
	expect_equal(length(tembo::wave_getTriggerTime(data, threshold = 0.9, startTime = 2, stopTime = 5)),0)
	expect_equal(length(tembo::wave_getTriggerTime(data, threshold = 0.9, startTime = -10, stopTime = -1)),0)
})

test_that("Test error handling", {
	data <- data.frame(t=(1:1e4)/1000)
	data$y <- sin(data$t)
	# expect error if out stopTime ist smaller than startTime:
	expect_error(wave_getTriggerTime(data, startTime=1, stopTime=0))
	# expect error if wrong trigger type
	expect_error(wave_getTriggerTime(data, type="uidtrne"))
	#expect_error(wave_getTriggerTime(data, startTime=-1, stopTime=0))
})


test_that("Testing trigger time for unsorted input", {
	data <- data.frame(t=(1:1e4)/1000)
	set.seed(500)
	data$t <- sample(data$t)
	data$y <- sin(data$t)
	expect_equal(tembo::wave_getTriggerTime(data),
							 c(0.9272954,7.2104807), tolerance = 1e-6)
})



test_that("Testing trigger time with blank time", {
	data <- data.frame(t=(1:1e4)/1000)
	set.seed(500)
	data$y <- sin(data$t) + runif(1e4) * 0.01
	expect_equal(tembo::wave_getTriggerTime(data, threshold = 0.1, blankTime = 0.01),
							 c(0.09521512, 6.37667981), tolerance = 1e-6)
	expect_equal(tembo::wave_getTriggerTime(data, threshold = 0, type = "falling", blankTime = 0.01),
							 c(3.144718, 9.429208), tolerance = 1e-6)
})