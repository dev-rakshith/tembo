context("Value Aproximation")

test_that("Testing value approximation", {
  data <- data.frame(t = (1:1000)*1e-6, y = sin(1:1000))
  expect_equal(wave_getValue(data, 100.5e-6), -0.02716993)
  expect_equal(wave_getValue(data, 500e-6), data$y[500])
  # expect error if out of range:
  expect_error(wave_getValue(data, 0))
  expect_error(wave_getValue(data, 1))
})

test_that("Testing value approximation for unordered data", {
	data <- data.frame(t = (1:1000)*1e-6)
	set.seed(500)
	data$t <- sample(data$t)
	data$y <- sin(data$t*1e6)
	expect_equal(wave_getValue(data, 100.5e-6), -0.02716993)
})
